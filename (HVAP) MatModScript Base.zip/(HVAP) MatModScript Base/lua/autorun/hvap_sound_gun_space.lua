---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################----###################################################----###################################################-- Aircraft Gun Audio
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################-- Spacecraft Guns
-------------------------------------------------------

sound.Add( -- gun bowcaster fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.bowcaster.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/bowcaster/fire_close_1.wav",
			"hvap/gun/lg/bowcaster/fire_close_2.wav",
			"hvap/gun/lg/bowcaster/fire_close_3.wav",
			"hvap/gun/lg/bowcaster/fire_close_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun bowcaster fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.bowcaster.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/bowcaster/fire_far_1.wav",
			"hvap/gun/lg/bowcaster/fire_far_2.wav",
			"hvap/gun/lg/bowcaster/fire_far_3.wav",
			"hvap/gun/lg/bowcaster/fire_far_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun ca87 fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ca87.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/ca87/fire_near_1.wav",
			"hvap/gun/lg/ca87/fire_near_2.wav",
			"hvap/gun/lg/ca87/fire_near_3.wav",
			"hvap/gun/lg/ca87/fire_near_4.wav",
			"hvap/gun/lg/ca87/fire_near_5.wav",
			"hvap/gun/lg/ca87/fire_near_6.wav",
			"hvap/gun/lg/ca87/fire_near_7.wav",
			"hvap/gun/lg/ca87/fire_near_8.wav",
			"hvap/gun/lg/ca87/fire_near_9.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun ca87 fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ca87.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/ca87/fire_far_1.wav",
			"hvap/gun/lg/ca87/fire_far_2.wav",
			"hvap/gun/lg/ca87/fire_far_3.wav",
			"hvap/gun/lg/ca87/fire_far_4.wav",
			"hvap/gun/lg/ca87/fire_far_5.wav",
			"hvap/gun/lg/ca87/fire_far_6.wav",
			"hvap/gun/lg/ca87/fire_far_7.wav",
			"hvap/gun/lg/ca87/fire_far_8.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun df9t fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.df9t.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/df9t/fire_near_1.wav",
			"hvap/gun/lg/df9t/fire_near_2.wav",
			"hvap/gun/lg/df9t/fire_near_3.wav",
			"hvap/gun/lg/df9t/fire_near_4.wav",
			"hvap/gun/lg/df9t/fire_near_5.wav",
			"hvap/gun/lg/df9t/fire_near_6.wav",
			"hvap/gun/lg/df9t/fire_near_7.wav",
			"hvap/gun/lg/df9t/fire_near_8.wav",
			"hvap/gun/lg/df9t/fire_near_9.wav",
			"hvap/gun/lg/df9t/fire_near_10.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun df9t fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.df9t.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/df9t/fire_far_1.wav",
			"hvap/gun/lg/df9t/fire_far_2.wav",
			"hvap/gun/lg/df9t/fire_far_3.wav",
			"hvap/gun/lg/df9t/fire_far_4.wav",
			"hvap/gun/lg/df9t/fire_far_5.wav",
			"hvap/gun/lg/df9t/fire_far_6.wav",
			"hvap/gun/lg/df9t/fire_far_7.wav",
			"hvap/gun/lg/df9t/fire_far_8.wav",
			"hvap/gun/lg/df9t/fire_far_9.wav",
			"hvap/gun/lg/df9t/fire_far_10.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun dlt20 fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.dlt20.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/dlt20/fire_close_1.wav",
			"hvap/gun/lg/dlt20/fire_close_2.wav",
			"hvap/gun/lg/dlt20/fire_close_3.wav",
			"hvap/gun/lg/dlt20/fire_close_4.wav",
			"hvap/gun/lg/dlt20/fire_close_5.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun dlt20 fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.dlt20.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/dlt20/fire_far_1.wav",
			"hvap/gun/lg/dlt20/fire_far_2.wav",
			"hvap/gun/lg/dlt20/fire_far_3.wav",
			"hvap/gun/lg/dlt20/fire_far_4.wav",
			"hvap/gun/lg/dlt20/fire_far_5.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun ioncannon fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ioncannon.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/ioncannon/fire_near_1.wav",
			"hvap/gun/lg/ioncannon/fire_near_2.wav",
			"hvap/gun/lg/ioncannon/fire_near_3.wav",
			"hvap/gun/lg/ioncannon/fire_near_4.wav",
			"hvap/gun/lg/ioncannon/fire_near_5.wav",
			"hvap/gun/lg/ioncannon/fire_near_6.wav",
			"hvap/gun/lg/ioncannon/fire_near_7.wav",
			"hvap/gun/lg/ioncannon/fire_near_8.wav",
			"hvap/gun/lg/ioncannon/fire_near_9.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun ioncannon fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ioncannon.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/ioncannon/fire_far_1.wav",
			"hvap/gun/lg/ioncannon/fire_far_2.wav",
			"hvap/gun/lg/ioncannon/fire_far_3.wav",
			"hvap/gun/lg/ioncannon/fire_far_4.wav",
			"hvap/gun/lg/ioncannon/fire_far_5.wav",
			"hvap/gun/lg/ioncannon/fire_far_6.wav",
			"hvap/gun/lg/ioncannon/fire_far_7.wav",
			"hvap/gun/lg/ioncannon/fire_far_8.wav",
			"hvap/gun/lg/ioncannon/fire_far_9.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun ioncannon bass close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ioncannon.Bass.Close",
    level = 130,
    sound = {
			"hvap/gun/lg/ioncannon/bass_near_1.wav",
			"hvap/gun/lg/ioncannon/bass_near_2.wav",
			"hvap/gun/lg/ioncannon/bass_near_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun ioncannon bass far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ioncannon.Bass.Far",
    level = 160,
    sound = {
			"hvap/gun/lg/ioncannon/bass_far_1.wav",
			"hvap/gun/lg/ioncannon/bass_far_2.wav",
			"hvap/gun/lg/ioncannon/bass_far_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun kx9 fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.kx9.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/kx9/fire_near_1.wav",
			"hvap/gun/lg/kx9/fire_near_2.wav",
			"hvap/gun/lg/kx9/fire_near_3.wav",
			"hvap/gun/lg/kx9/fire_near_4.wav",
			"hvap/gun/lg/kx9/fire_near_5.wav",
			"hvap/gun/lg/kx9/fire_near_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun kx9 fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.kx9.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/kx9/fire_far_1.wav",
			"hvap/gun/lg/kx9/fire_far_2.wav",
			"hvap/gun/lg/kx9/fire_far_3.wav",
			"hvap/gun/lg/kx9/fire_far_4.wav",
			"hvap/gun/lg/kx9/fire_far_5.wav",
			"hvap/gun/lg/kx9/fire_far_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun ls1 fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ls1.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/ls1/fire_near_1.wav",
			"hvap/gun/lg/ls1/fire_near_2.wav",
			"hvap/gun/lg/ls1/fire_near_3.wav",
			"hvap/gun/lg/ls1/fire_near_4.wav",
			"hvap/gun/lg/ls1/fire_near_5.wav",
			"hvap/gun/lg/ls1/fire_near_6.wav",
			"hvap/gun/lg/ls1/fire_near_7.wav",
			"hvap/gun/lg/ls1/fire_near_8.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun ls1 fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ls1.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/ls1/fire_far_1.wav",
			"hvap/gun/lg/ls1/fire_far_2.wav",
			"hvap/gun/lg/ls1/fire_far_3.wav",
			"hvap/gun/lg/ls1/fire_far_4.wav",
			"hvap/gun/lg/ls1/fire_far_5.wav",
			"hvap/gun/lg/ls1/fire_far_6.wav",
			"hvap/gun/lg/ls1/fire_far_7.wav",
			"hvap/gun/lg/ls1/fire_far_8.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun ls1 stop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ls1.Stop",
    level = 100,
    sound = {
			"hvap/gun/lg/ls1/stop_1.wav",
			"hvap/gun/lg/ls1/stop_2.wav",
			"hvap/gun/lg/ls1/stop_3.wav",
			"hvap/gun/lg/ls1/stop_4.wav",
			"hvap/gun/lg/ls1/stop_5.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun t21 fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.t21.Fire.Close",
    level = 120,
    sound = {
			"hvap/gun/lg/t21/fire_near_1.wav",
			"hvap/gun/lg/t21/fire_near_2.wav",
			"hvap/gun/lg/t21/fire_near_3.wav",
			"hvap/gun/lg/t21/fire_near_4.wav",
			"hvap/gun/lg/t21/fire_near_5.wav",
			"hvap/gun/lg/t21/fire_near_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun t21 fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.t21.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/t21/fire_far_1.wav",
			"hvap/gun/lg/t21/fire_far_2.wav",
			"hvap/gun/lg/t21/fire_far_3.wav",
			"hvap/gun/lg/t21/fire_far_4.wav",
			"hvap/gun/lg/t21/fire_far_5.wav",
			"hvap/gun/lg/t21/fire_far_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------


sound.Add( -- gun turbolaser fire close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.turbolaser.Fire.Close",
    level = 120,
    sound = "hvap/gun/lg/turbolaser/fire_near.wav",

    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun turbolaser fire far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.turbolaser.Fire.Far",
    level = 150,
    sound = {
			"hvap/gun/lg/turbolaser/fire_far_1.wav",
			"hvap/gun/lg/turbolaser/fire_far_2.wav",
			"hvap/gun/lg/turbolaser/fire_far_3.wav",
			"hvap/gun/lg/turbolaser/fire_far_4.wav",
			"hvap/gun/lg/turbolaser/fire_far_5.wav",
			"hvap/gun/lg/turbolaser/fire_far_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun turbolaser bass close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.turbolaser.Bass.Close",
    level = 130,
    sound = "hvap/gun/lg/turbolaser/bass_close.wav",

    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------




