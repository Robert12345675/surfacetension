
-------------------------------------------------------
--###################################################-- Vehicle
-------------------------------------------------------

sound.Add( -- spacecraft collide
{
    channel = CHAN_AUTO,
    name = "HVAP.Spacecraft.Collide",
    level = 100,
    sound = 	{
		"hvap/impact/space_impact_1.wav",
		"hvap/impact/space_impact_2.wav",
		"hvap/impact/space_impact_3.wav",
		"hvap/impact/space_impact_4.wav",
		"hvap/impact/space_impact_5.wav",
		"hvap/impact/space_impact_6.wav",
		"hvap/impact/space_impact_7.wav",
		"hvap/impact/space_impact_8.wav",
		"hvap/impact/space_impact_9.wav",
		"hvap/impact/space_impact_10.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------
--###################################################-- Weapon Jam/Overheat
-------------------------------------------------------

sound.Add( -- lasergun overheat near
{
    channel = CHAN_AUTO,
    name = "HVAP.LaserGun.Overheat.Near",
    level = 80,
    sound = "hvap/gun/jam/lg/overheat_near.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- lasergun overheated
{
    channel = CHAN_AUTO,
    name = "HVAP.LaserGun.Overheated",
    level = 80,
    sound = 	{
		"hvap/gun/jam/lg/overheated_1.wav",
		"hvap/gun/jam/lg/overheated_2.wav",
		"hvap/gun/jam/lg/overheated_3.wav",
		"hvap/gun/jam/lg/overheated_4.wav",
		"hvap/gun/jam/lg/overheated_5.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- lasergun jam finish
{
    channel = CHAN_AUTO,
    name = "HVAP.LaserGun.Overheat.Finish",
    level = 80,
    sound = 	{
		"hvap/gun/jam/lg/overheat_finish_1.wav",
		"hvap/gun/jam/lg/overheat_finish_2.wav",
		"hvap/gun/jam/lg/overheat_finish_3.wav",
		"hvap/gun/jam/lg/overheat_finish_4.wav",
		"hvap/gun/jam/lg/overheat_finish_5.wav"
		},
    volume = 1.0,
	pitch = 100
})
