-------------------------------------------------------
--###################################################-- Misc
-------------------------------------------------------

sound.Add( -- explode space
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Space",
    level = 110,
    sound = 	{
		"hvap/explode/space_explode_1.wav",
		"hvap/explode/space_explode_2.wav",
		"hvap/explode/space_explode_3.wav",
		"hvap/explode/space_explode_4.wav",
		"hvap/explode/space_explode_5.wav",
		"hvap/explode/space_explode_6.wav",
		"hvap/explode/space_explode_7.wav",
		"hvap/explode/space_explode_8.wav",
		"hvap/explode/space_explode_9.wav",
		"hvap/explode/space_explode_10.wav",
		"hvap/explode/space_explode_11.wav",
		"hvap/explode/space_explode_12.wav",
		"hvap/explode/space_explode_13.wav",
		"hvap/explode/space_explode_14.wav",
		"hvap/explode/space_explode_15.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})
