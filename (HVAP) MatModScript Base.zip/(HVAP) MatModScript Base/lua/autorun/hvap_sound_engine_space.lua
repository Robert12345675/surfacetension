---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################----###################################################----###################################################-- Engine Audio
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################-- awing
-------------------------------------------------------

sound.Add( -- engine awing engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.awing.Engine.Near",
    level = 105,
    sound = "hvap/engine/awing/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine awing engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.awing.Engine.Far",
    level = 120,
    sound = "hvap/engine/awing/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine awing rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.awing.Rotor.Near",
    level = 116,
    sound = "hvap/engine/awing/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine awing rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.awing.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/awing/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- falcon
-------------------------------------------------------

sound.Add( -- engine falcon cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.falcon.Cockpit",
    level = 75,
    sound = "hvap/engine/falcon/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine falcon engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.falcon.Engine.Near",
    level = 105,
    sound = "hvap/engine/falcon/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine falcon engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.falcon.Engine.Far",
    level = 120,
    sound = "hvap/engine/falcon/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine falcon rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.falcon.Rotor.Near",
    level = 116,
    sound = "hvap/engine/falcon/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine falcon rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.falcon.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/falcon/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine falcon turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.falcon.Turbine",
    level = 120,--far
    sound = "hvap/engine/falcon/turbine.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- slave
-------------------------------------------------------

sound.Add( -- engine slave cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.slave.Cockpit",
    level = 75,
    sound = "hvap/engine/slave/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine slave engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.slave.Engine.Near",
    level = 105,
    sound = "hvap/engine/slave/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine slave engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.slave.Engine.Far",
    level = 120,
    sound = "hvap/engine/slave/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine slave rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.slave.Rotor.Near",
    level = 116,
    sound = "hvap/engine/slave/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine slave rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.slave.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/slave/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine slave turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.slave.Turbine",
    level = 120,--far
    sound = "hvap/engine/slave/turbine.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- snowspeeder
-------------------------------------------------------

sound.Add( -- engine snowspeeder cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.snowspeeder.Cockpit",
    level = 75,
    sound = "hvap/engine/snowspeeder/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine snowspeeder engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.snowspeeder.Engine.Near",
    level = 105,
    sound = "hvap/engine/snowspeeder/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine snowspeeder engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.snowspeeder.Engine.Far",
    level = 120,
    sound = "hvap/engine/snowspeeder/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine snowspeeder rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.snowspeeder.Rotor.Near",
    level = 116,
    sound = "hvap/engine/snowspeeder/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine snowspeeder rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.snowspeeder.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/snowspeeder/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- tie
-------------------------------------------------------

sound.Add( -- engine tie cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tie.Cockpit",
    level = 75,
    sound = "hvap/engine/tie/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine tie engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tie.Engine.Near",
    level = 105,
    sound = "hvap/engine/tie/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine tie engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tie.Engine.Far",
    level = 120,
    sound = "hvap/engine/tie/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine tie rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tie.Rotor.Near",
    level = 116,
    sound = "hvap/engine/tie/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine tie rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tie.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/tie/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine tie turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tie.Turbine",
    level = 120,--far
    sound = "hvap/engine/tie/turbine.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- tieinterceptor
-------------------------------------------------------

sound.Add( -- engine tieinterceptor rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tieinterceptor.Rotor.Near",
    level = 116,
    sound = "hvap/engine/tieinterceptor/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine tieinterceptor rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.tieinterceptor.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/tieinterceptor/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- xwing
-------------------------------------------------------

sound.Add( -- engine xwing cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.xwing.Cockpit",
    level = 75,
    sound = "hvap/engine/xwing/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine xwing engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.xwing.Engine.Near",
    level = 105,
    sound = "hvap/engine/xwing/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine xwing engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.xwing.Engine.Far",
    level = 120,
    sound = "hvap/engine/xwing/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine xwing rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.xwing.Rotor.Near",
    level = 116,
    sound = "hvap/engine/xwing/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine xwing rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.xwing.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/xwing/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine xwing turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.xwing.Turbine",
    level = 120,--far
    sound = "hvap/engine/xwing/turbine.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- ywing
-------------------------------------------------------

sound.Add( -- engine ywing engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.ywing.Engine.Near",
    level = 105,
    sound = "hvap/engine/ywing/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ywing engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.ywing.Engine.Far",
    level = 120,
    sound = "hvap/engine/ywing/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ywing rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.ywing.Rotor.Near",
    level = 116,
    sound = "hvap/engine/ywing/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ywing rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.ywing.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/ywing/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- shared
-------------------------------------------------------

sound.Add( -- engine space start 1
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Space.Start.1",
    level = 90,
    sound = "hvap/engine/shared/start_1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine space start 2
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Space.Start.2",
    level = 90,
    sound = "hvap/engine/shared/start_2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine space start 3
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Space.Start.3",
    level = 90,
    sound = "hvap/engine/shared/start_3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine space stop 1
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Space.Stop.1",
    level = 90,
    sound = "hvap/engine/shared/stop_1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine space stop 2
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Space.Stop.2",
    level = 90,
    sound = "hvap/engine/shared/stop_2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine space foils
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Space.Foils",
    level = 100,
    sound = "hvap/engine/shared/sfoils.wav",
    volume = 1.0,
	pitch = 100
})











