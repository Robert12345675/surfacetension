-------------------------------------------------------
--###################################################-- Misc
-------------------------------------------------------

sound.Add( -- fly large
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Fly.Large",
    level = 90,
    sound =	"hvap/bullet/large_fly_loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Explode
-------------------------------------------------------
sound.Add( -- explode small
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Explode.Small",
    level = 130,
    sound = 	{
		"hvap/bullet/explode/small_1.wav",
		"hvap/bullet/explode/small_2.wav",
		"hvap/bullet/explode/small_3.wav",
		"hvap/bullet/explode/small_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- explode medium
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Explode.Medium",
    level = 145,
    sound = 	{
		"hvap/bullet/explode/medium_1.wav",
		"hvap/bullet/explode/medium_2.wav",
		"hvap/bullet/explode/medium_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- explode large near
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Explode.Large.Near",
    level = 130,
    sound = 	{
		"hvap/bullet/explode/large_1.wav",
		"hvap/bullet/explode/large_2.wav",
		"hvap/bullet/explode/large_3.wav",
		"hvap/bullet/explode/large_4.wav",
		"hvap/bullet/explode/large_5.wav",
		"hvap/bullet/explode/large_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- explode large close
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Explode.Large.Close",
    level = 140,
    sound = 	{
		"hvap/bullet/explode/large_close_1.wav",
		"hvap/bullet/explode/large_close_2.wav",
		"hvap/bullet/explode/large_close_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- explode large far
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Explode.Large.Far",
    level = 150,
    sound = 	{
		"hvap/bullet/explode/large_far_1.wav",
		"hvap/bullet/explode/large_far_2.wav",
		"hvap/bullet/explode/large_far_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- explode flak close
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Explode.Flak.Near",
    level = 135,
    sound = 	{
		"hvap/bullet/explode/flak_1.wav",
		"hvap/bullet/explode/flak_2.wav",
		"hvap/bullet/explode/flak_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- explode flak far
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Explode.Flak.Far",
    level = 145,
    sound = 	{
		"hvap/bullet/explode/flak_far_1.wav",
		"hvap/bullet/explode/flak_far_2.wav",
		"hvap/bullet/explode/flak_far_3.wav",
		"hvap/bullet/explode/flak_far_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Impacts
-------------------------------------------------------

sound.Add( -- impact concrete
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Concrete",
    level = 90,
    sound = 	{
		"hvap/bullet/impact/concrete_1.wav",
		"hvap/bullet/impact/concrete_2.wav",
		"hvap/bullet/impact/concrete_3.wav",
		"hvap/bullet/impact/concrete_4.wav",
		"hvap/bullet/impact/concrete_5.wav",
		"hvap/bullet/impact/concrete_6.wav",
		"hvap/bullet/impact/concrete_7.wav",
		"hvap/bullet/impact/concrete_8.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact dirt
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Dirt",
    level = 80,
    sound = 	{
		"hvap/bullet/impact/dirt_1.wav",
		"hvap/bullet/impact/dirt_2.wav",
		"hvap/bullet/impact/dirt_3.wav",
		"hvap/bullet/impact/dirt_4.wav",
		"hvap/bullet/impact/dirt_5.wav",
		"hvap/bullet/impact/dirt_6.wav",
		"hvap/bullet/impact/dirt_7.wav",
		"hvap/bullet/impact/dirt_8.wav",
		"hvap/bullet/impact/dirt_9.wav",
		"hvap/bullet/impact/dirt_10.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact flesh
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Flesh",
    level = 90,
    sound = 	{
		"hvap/bullet/impact/flesh_1.wav",
		"hvap/bullet/impact/flesh_2.wav",
		"hvap/bullet/impact/flesh_3.wav",
		"hvap/bullet/impact/flesh_4.wav",
		"hvap/bullet/impact/flesh_5.wav",
		"hvap/bullet/impact/flesh_6.wav",
		"hvap/bullet/impact/flesh_7.wav",
		"hvap/bullet/impact/flesh_8.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact glass
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Glass",
    level = 90,
    sound = 	{
		"hvap/bullet/impact/glass_1.wav",
		"hvap/bullet/impact/glass_2.wav",
		"hvap/bullet/impact/glass_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact metal
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Metal",
    level = 90,
    sound = 	{
		"hvap/bullet/impact/metal_1.wav",
		"hvap/bullet/impact/metal_2.wav",
		"hvap/bullet/impact/metal_3.wav",
		"hvap/bullet/impact/metal_4.wav",
		"hvap/bullet/impact/metal_5.wav",
		"hvap/bullet/impact/metal_6.wav",
		"hvap/bullet/impact/metal_7.wav",
		"hvap/bullet/impact/metal_8.wav",
		"hvap/bullet/impact/metal_9.wav",
		"hvap/bullet/impact/metal_10.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact sand
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Sand",
    level = 80,
    sound = 	{
		"hvap/bullet/impact/sand_1.wav",
		"hvap/bullet/impact/sand_2.wav",
		"hvap/bullet/impact/sand_3.wav",
		"hvap/bullet/impact/sand_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact snow
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Snow",
    level = 90,
    sound = 	{
		"hvap/bullet/impact/snow_1.wav",
		"hvap/bullet/impact/snow_2.wav",
		"hvap/bullet/impact/snow_3.wav",
		"hvap/bullet/impact/snow_4.wav",
		"hvap/bullet/impact/snow_5.wav",
		"hvap/bullet/impact/snow_6.wav",
		"hvap/bullet/impact/snow_7.wav",
		"hvap/bullet/impact/snow_8.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact water
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Water",
    level = 85,
    sound = 	{
		"hvap/bullet/impact/water_1.wav",
		"hvap/bullet/impact/water_2.wav",
		"hvap/bullet/impact/water_3.wav",
		"hvap/bullet/impact/water_4.wav",
		"hvap/bullet/impact/water_5.wav",
		"hvap/bullet/impact/water_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact wood
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Wood",
    level = 85,
    sound = 	{
		"hvap/bullet/impact/wood_1.wav",
		"hvap/bullet/impact/wood_2.wav",
		"hvap/bullet/impact/wood_3.wav",
		"hvap/bullet/impact/wood_4.wav",
		"hvap/bullet/impact/wood_5.wav",
		"hvap/bullet/impact/wood_6.wav",
		"hvap/bullet/impact/wood_7.wav",
		"hvap/bullet/impact/wood_8.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Impacts Tank Large
-------------------------------------------------------

sound.Add( -- impact large ap
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Large.AP",
    level = 110,
    sound = 	{
		"hvap/bullet/impact/large/ap_1.wav",
		"hvap/bullet/impact/large/ap_2.wav",
		"hvap/bullet/impact/large/ap_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact large aphe
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Large.APHE",
    level = 110,
    sound = 	{
		"hvap/bullet/impact/large/aphe_1.wav",
		"hvap/bullet/impact/large/aphe_2.wav",
		"hvap/bullet/impact/large/aphe_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact large he
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Large.HE",
    level = 110,
    sound = 	{
		"hvap/bullet/impact/large/he_1.wav",
		"hvap/bullet/impact/large/he_2.wav",
		"hvap/bullet/impact/large/he_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact large heat
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Large.HEAT",
    level = 110,
    sound = 	{
		"hvap/bullet/impact/large/heat_1.wav",
		"hvap/bullet/impact/large/heat_2.wav",
		"hvap/bullet/impact/large/heat_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact large water
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Large.Water",
    level = 100,
    sound = 	{
		"hvap/bullet/impact/large/water_1.wav",
		"hvap/bullet/impact/large/water_2.wav",
		"hvap/bullet/impact/large/water_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Impacts Tank Medium
-------------------------------------------------------

sound.Add( -- impact medium ap
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Medium.AP",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/medium/ap_1.wav",
		"hvap/bullet/impact/medium/ap_2.wav",
		"hvap/bullet/impact/medium/ap_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact medium aphe
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Medium.APHE",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/medium/aphe_1.wav",
		"hvap/bullet/impact/medium/aphe_2.wav",
		"hvap/bullet/impact/medium/aphe_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact medium he
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Medium.HE",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/medium/he_1.wav",
		"hvap/bullet/impact/medium/he_2.wav",
		"hvap/bullet/impact/medium/he_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact medium heat
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Medium.HEAT",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/medium/heat_1.wav",
		"hvap/bullet/impact/medium/heat_2.wav",
		"hvap/bullet/impact/medium/heat_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Impacts Tank Small
-------------------------------------------------------

sound.Add( -- impact small ap
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Small.AP",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/small/ap_1.wav",
		"hvap/bullet/impact/small/ap_2.wav",
		"hvap/bullet/impact/small/ap_3.wav",
		"hvap/bullet/impact/small/ap_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact small aphe
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Small.APHE",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/small/aphe_1.wav",
		"hvap/bullet/impact/small/aphe_2.wav",
		"hvap/bullet/impact/small/aphe_3.wav",
		"hvap/bullet/impact/small/aphe_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact small he
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Small.HE",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/small/he_1.wav",
		"hvap/bullet/impact/small/he_2.wav",
		"hvap/bullet/impact/small/he_3.wav",
		"hvap/bullet/impact/small/he_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- impact small heat
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Small.HEAT",
    level = 105,
    sound = 	{
		"hvap/bullet/impact/small/heat_1.wav",
		"hvap/bullet/impact/small/heat_2.wav",
		"hvap/bullet/impact/small/heat_3.wav",
		"hvap/bullet/impact/small/heat_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Impacts Aircraft
-------------------------------------------------------

sound.Add( -- impact aircraft
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Impact.Aircraft",
    level = 110,
    sound = 	{
		"hvap/bullet/impact/aircraft/air_impact_1.wav",
		"hvap/bullet/impact/aircraft/air_impact_2.wav",
		"hvap/bullet/impact/aircraft/air_impact_3.wav",
		"hvap/bullet/impact/aircraft/air_impact_4.wav",
		"hvap/bullet/impact/aircraft/air_impact_5.wav",
		"hvap/bullet/impact/aircraft/air_impact_6.wav",
		"hvap/bullet/impact/aircraft/air_impact_7.wav",
		"hvap/bullet/impact/aircraft/air_impact_8.wav",
		"hvap/bullet/impact/aircraft/air_impact_9.wav",
		"hvap/bullet/impact/aircraft/air_impact_10.wav"
		},
    volume = 0.9,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Miss
-------------------------------------------------------

sound.Add( -- miss small
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Miss.Small",
    level = 80,
    sound = 	{
		"hvap/bullet/miss/small_1.wav",
		"hvap/bullet/miss/small_2.wav",
		"hvap/bullet/miss/small_3.wav",
		"hvap/bullet/miss/small_4.wav",
		"hvap/bullet/miss/small_5.wav",
		"hvap/bullet/miss/small_6.wav",
		"hvap/bullet/miss/small_7.wav",
		"hvap/bullet/miss/small_8.wav",
		"hvap/bullet/miss/small_9.wav",
		"hvap/bullet/miss/small_10.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- miss large
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Miss.Large",
    level = 80,
    sound = 	{
		"hvap/bullet/miss/large_1.wav",
		"hvap/bullet/miss/large_2.wav",
		"hvap/bullet/miss/large_3.wav",
		"hvap/bullet/miss/large_4.wav",
		"hvap/bullet/miss/large_5.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Ricochet/Bounce
-------------------------------------------------------

sound.Add( -- large ricochet
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Large.Ricochet",
    level = 110,
    sound = 	{
		"hvap/bullet/ricochet/large/ricochet_1.wav",
		"hvap/bullet/ricochet/large/ricochet_2.wav",
		"hvap/bullet/ricochet/large/ricochet_3.wav",
		"hvap/bullet/ricochet/large/ricochet_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- small ricochet
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Small.Ricochet",
    level = 90,
    sound = 	{
		"hvap/bullet/ricochet/small/ricochet_1.wav",
		"hvap/bullet/ricochet/small/ricochet_2.wav",
		"hvap/bullet/ricochet/small/ricochet_3.wav",
		"hvap/bullet/ricochet/small/ricochet_4.wav",
		"hvap/bullet/ricochet/small/ricochet_5.wav",
		"hvap/bullet/ricochet/small/ricochet_6.wav",
		"hvap/bullet/ricochet/small/ricochet_7.wav",
		"hvap/bullet/ricochet/small/ricochet_8.wav",
		"hvap/bullet/ricochet/small/ricochet_9.wav",
		"hvap/bullet/ricochet/small/ricochet_10.wav",
		"hvap/bullet/ricochet/small/ricochet_11.wav",
		"hvap/bullet/ricochet/small/ricochet_12.wav"
		},
    volume = 0.9,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Penetrate
-------------------------------------------------------

sound.Add( -- large penetrate
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Large.Penetrate",
    level = 110,
    sound = 	{
		"hvap/bullet/penetrate/large_1.wav",
		"hvap/bullet/penetrate/large_2.wav",
		"hvap/bullet/penetrate/large_3.wav",
		"hvap/bullet/penetrate/large_4.wav",
		"hvap/bullet/penetrate/large_5.wav",
		"hvap/bullet/penetrate/large_6.wav",
		"hvap/bullet/penetrate/large_7.wav",
		"hvap/bullet/penetrate/large_8.wav",
		"hvap/bullet/penetrate/large_9.wav",
		"hvap/bullet/penetrate/large_10.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- medium penetrate
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Medium.Penetrate",
    level = 105,
    sound = 	{
		"hvap/bullet/penetrate/medium_1.wav",
		"hvap/bullet/penetrate/medium_2.wav",
		"hvap/bullet/penetrate/medium_3.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- small penetrate
{
    channel = CHAN_AUTO,
    name = "HVAP.Bullet.Small.Penetrate",
    level = 100,
    sound = 	{
		"hvap/bullet/penetrate/small_1.wav",
		"hvap/bullet/penetrate/small_2.wav",
		"hvap/bullet/penetrate/small_3.wav",
		"hvap/bullet/penetrate/small_4.wav",
		"hvap/bullet/penetrate/small_5.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Bombs
-------------------------------------------------------

sound.Add( -- bomb drop
{
    channel = CHAN_AUTO,
    name = "HVAP.Bomb.Drop",
    level = 80,
    sound = "hvap/secondary/bomb/drop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- bomb whistle
{
    channel = CHAN_AUTO,
    name = "HVAP.Bomb.Whistle",
    level = 130,
    sound = "hvap/secondary/bomb/whistle.wav",
    volume = 0.9,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Rockets
-------------------------------------------------------

sound.Add( -- rocket atgm
{
    channel = CHAN_AUTO,
    name = "HVAP.Rocket.ATGM",
    level = 120,
    sound = 	{
		"hvap/secondary/rocket/atgm_1.wav",
		"hvap/secondary/rocket/atgm_2.wav",
		"hvap/secondary/rocket/atgm_3.wav",
		"hvap/secondary/rocket/atgm_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- rocket hvar
{
    channel = CHAN_AUTO,
    name = "HVAP.Rocket.HVAR",
    level = 120,
    sound = 	{
		"hvap/secondary/rocket/hvar_1.wav",
		"hvap/secondary/rocket/hvar_2.wav",
		"hvap/secondary/rocket/hvar_3.wav",
		"hvap/secondary/rocket/hvar_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- rocket hydra
{
    channel = CHAN_AUTO,
    name = "HVAP.Rocket.Hydra",
    level = 120,
    sound = 	{
		"hvap/secondary/rocket/hydra_1.wav",
		"hvap/secondary/rocket/hydra_2.wav",
		"hvap/secondary/rocket/hydra_3.wav",
		"hvap/secondary/rocket/hydra_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- rocket missile
{
    channel = CHAN_AUTO,
    name = "HVAP.Rocket.Missile",
    level = 120,
    sound = 	{
		"hvap/secondary/rocket/missile_1.wav",
		"hvap/secondary/rocket/missile_2.wav",
		"hvap/secondary/rocket/missile_3.wav",
		"hvap/secondary/rocket/missile_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- rocket rocket
{
    channel = CHAN_AUTO,
    name = "HVAP.Rocket.Rocket",
    level = 120,
    sound = 	{
		"hvap/secondary/rocket/rocket_1.wav",
		"hvap/secondary/rocket/rocket_2.wav",
		"hvap/secondary/rocket/rocket_3.wav",
		"hvap/secondary/rocket/rocket_4.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- rocket werfer
{
    channel = CHAN_AUTO,
    name = "HVAP.Rocket.Werfer",
    level = 120,
    sound = 	{
		"hvap/secondary/rocket/werfer_1.wav",
		"hvap/secondary/rocket/werfer_2.wav",
		"hvap/secondary/rocket/werfer_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- rocket fly
{
    channel = CHAN_AUTO,
    name = "HVAP.Rocket.Fly",
    level = 95,
    sound = "hvap/secondary/rocket/fly_loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Explosions
-------------------------------------------------------

sound.Add( -- explode ammo close
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Ammo.Close",
    level = 90,
    sound = 	{
		"hvap/explode/ammo_close_1.wav",
		"hvap/explode/ammo_close_2.wav",
		"hvap/explode/ammo_close_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- explode ammo near
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Ammo.Near",
    level = 110,
    sound = 	{
		"hvap/explode/ammo_near_1.wav",
		"hvap/explode/ammo_near_2.wav",
		"hvap/explode/ammo_near_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- explode ammo far
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Ammo.Far",
    level = 130,
    sound = 	{
		"hvap/explode/ammo_far_1.wav",
		"hvap/explode/ammo_far_2.wav",
		"hvap/explode/ammo_far_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- explode ammo distant
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Ammo.Distant",
    level = 150,
    sound = 	{
		"hvap/explode/ammo_distant_1.wav",
		"hvap/explode/ammo_distant_2.wav",
		"hvap/explode/ammo_distant_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- explode explosion close
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Explosion.Close",
    level = 90,
    sound = 	{
		"hvap/explode/explosion_close_1.wav",
		"hvap/explode/explosion_close_2.wav",
		"hvap/explode/explosion_close_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- explode explosion near
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Explosion.Near",
    level = 120,
    sound = 	{
		"hvap/explode/explosion_near_1.wav",
		"hvap/explode/explosion_near_2.wav",
		"hvap/explode/explosion_near_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- explode explosion far
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Explosion.Far",
    level = 140,
    sound = 	{
		"hvap/explode/explosion_far_1.wav",
		"hvap/explode/explosion_far_2.wav",
		"hvap/explode/explosion_far_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- explode water
{
    channel = CHAN_AUTO,
    name = "HVAP.Explode.Water",
    level = 125,
    sound = 	{
		"hvap/explode/water_1.wav",
		"hvap/explode/water_2.wav",
		"hvap/explode/water_3.wav",
		"hvap/explode/water_4.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})
