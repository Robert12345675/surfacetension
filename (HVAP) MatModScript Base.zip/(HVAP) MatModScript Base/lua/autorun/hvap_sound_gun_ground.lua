---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################----###################################################----###################################################-- Weapon Audio
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################-- Gun Misc
-------------------------------------------------------

sound.Add( -- gun misc blankfire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Misc.BlankFire",
    level = 80,
    sound = "hvap/gun/misc/blank.wav",
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- gun misc nosecondary
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Misc.NoSecondary",
    level = 80,
    sound = "hvap/gun/misc/no_secondary.wav",
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------
--###################################################-- 20flak38
-------------------------------------------------------

sound.Add( -- gun 20flak38 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.20flak38.Far",
    level = 125,
    sound = 	{
		"hvap/gun/cnn/20flak38/1.wav",
		"hvap/gun/cnn/20flak38/2.wav",
		"hvap/gun/cnn/20flak38/3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 20flak38 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.20flak38.Fire",
    level = 125,
    sound = 	{
		"hvap/gun/cnn/20flak38/fire_1.wav",
		"hvap/gun/cnn/20flak38/fire_2.wav",
		"hvap/gun/cnn/20flak38/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 37flak36
-------------------------------------------------------

sound.Add( -- gun 36flak36 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.37flak36.Far",
    level = 125,
    sound = 	{
		"hvap/gun/cnn/37flak36/1.wav",
		"hvap/gun/cnn/37flak36/2.wav",
		"hvap/gun/cnn/37flak36/3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 36flak36 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.37flak36.Fire",
    level = 125,
    sound = 	{
		"hvap/gun/cnn/37flak36/fire_1.wav",
		"hvap/gun/cnn/37flak36/fire_2.wav",
		"hvap/gun/cnn/37flak36/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 40m2
-------------------------------------------------------

sound.Add( -- gun 40m2 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.40m2.Distant",
    level = 160,
    sound = "hvap/gun/cnn/40m2/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 40m2 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.40m2.Far",
    level = 145,
    sound = "hvap/gun/cnn/40m2/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 40m2 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.40m2.Close",
    level = 130,
    sound = "hvap/gun/cnn/40m2/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 40m2 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.40m2.Near",
    level = 115,
    sound = "hvap/gun/cnn/40m2/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 40m2 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.40m2.Fire",
    level = 100,
    sound = "hvap/gun/cnn/40m2/fire_1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 50kwk
-------------------------------------------------------

sound.Add( -- gun 50kwk distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.50kwk.Distant",
    level = 160,
    sound = "hvap/gun/cnn/50kwk/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 50kwk far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.50kwk.Far",
    level = 145,
    sound = "hvap/gun/cnn/50kwk/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 50kwk close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.50kwk.Close",
    level = 130,
    sound = "hvap/gun/cnn/50kwk/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 50kwk near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.50kwk.Near",
    level = 115,
    sound = "hvap/gun/cnn/50kwk/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 50kwk fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.50kwk.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/50kwk/fire_1.wav",
		"hvap/gun/cnn/50kwk/fire_2.wav",
		"hvap/gun/cnn/50kwk/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 75kwk
-------------------------------------------------------

sound.Add( -- gun 75kwk distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75kwk.Distant",
    level = 160,
    sound = "hvap/gun/cnn/75kwk/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75kwk far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75kwk.Far",
    level = 145,
    sound = "hvap/gun/cnn/75kwk/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75kwk close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75kwk.Close",
    level = 130,
    sound = "hvap/gun/cnn/75kwk/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75kwk near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75kwk.Near",
    level = 115,
    sound = "hvap/gun/cnn/75kwk/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75kwk fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75kwk.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/75kwk/fire_1.wav",
		"hvap/gun/cnn/75kwk/fire_2.wav",
		"hvap/gun/cnn/75kwk/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 75m3
-------------------------------------------------------

sound.Add( -- gun 75m3 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75m3.Distant",
    level = 160,
    sound = "hvap/gun/cnn/75m3/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75m3 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75m3.Far",
    level = 145,
    sound = "hvap/gun/cnn/75m3/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75m3 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75m3.Close",
    level = 130,
    sound = "hvap/gun/cnn/75m3/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75m3 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75m3.Near",
    level = 115,
    sound = "hvap/gun/cnn/75m3/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 75m3 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.75m3.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/75m3/fire_1.wav",
		"hvap/gun/cnn/75m3/fire_2.wav",
		"hvap/gun/cnn/75m3/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 76m1
-------------------------------------------------------

sound.Add( -- gun 76m1 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76m1.Distant",
    level = 160,
    sound = "hvap/gun/cnn/76m1/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76m1 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76m1.Far",
    level = 145,
    sound = "hvap/gun/cnn/76m1/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76m1 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76m1.Close",
    level = 130,
    sound = "hvap/gun/cnn/76m1/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76m1 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76m1.Near",
    level = 115,
    sound = "hvap/gun/cnn/76m1/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76m1 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76m1.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/76m1/fire_1.wav",
		"hvap/gun/cnn/76m1/fire_2.wav",
		"hvap/gun/cnn/76m1/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 76zis5
-------------------------------------------------------

sound.Add( -- gun 76zis5 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76zis5.Distant",
    level = 160,
    sound = "hvap/gun/cnn/76zis5/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76zis5 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76zis5.Far",
    level = 145,
    sound = "hvap/gun/cnn/76zis5/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76zis5 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76zis5.Close",
    level = 130,
    sound = "hvap/gun/cnn/76zis5/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76zis5 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76zis5.Near",
    level = 115,
    sound = "hvap/gun/cnn/76zis5/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 76zis5 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.76zis5.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/76zis5/fire_1.wav",
		"hvap/gun/cnn/76zis5/fire_2.wav",
		"hvap/gun/cnn/76zis5/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 85d5t
-------------------------------------------------------

sound.Add( -- gun 85d5t distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.85d5t.Distant",
    level = 160,
    sound = "hvap/gun/cnn/85d5t/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 85d5t far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.85d5t.Far",
    level = 145,
    sound = "hvap/gun/cnn/85d5t/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 85d5t close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.85d5t.Close",
    level = 130,
    sound = "hvap/gun/cnn/85d5t/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 85d5t near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.85d5t.Near",
    level = 115,
    sound = "hvap/gun/cnn/85d5t/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 85d5t fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.85d5t.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/85d5t/fire_1.wav",
		"hvap/gun/cnn/85d5t/fire_2.wav",
		"hvap/gun/cnn/85d5t/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 88flak
-------------------------------------------------------

sound.Add( -- gun 88flak close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88flak.Close",
    level = 130,
    sound = 	{
		"hvap/gun/cnn/88flak/2_1.wav",
		"hvap/gun/cnn/88flak/2_2.wav",
		"hvap/gun/cnn/88flak/2_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 88flak near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88flak.Near",
    level = 115,
    sound = 	{
		"hvap/gun/cnn/88flak/1_1.wav",
		"hvap/gun/cnn/88flak/1_2.wav",
		"hvap/gun/cnn/88flak/1_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 88flak fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88flak.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/88flak/fire_1.wav",
		"hvap/gun/cnn/88flak/fire_2.wav",
		"hvap/gun/cnn/88flak/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 88pak
-------------------------------------------------------

sound.Add( -- gun 88pak distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88pak.Distant",
    level = 160,
    sound = "hvap/gun/cnn/88pak/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 88pak far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88pak.Far",
    level = 145,
    sound = "hvap/gun/cnn/88pak/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 88pak close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88pak.Close",
    level = 130,
    sound = "hvap/gun/cnn/88pak/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 88pak near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88pak.Near",
    level = 115,
    sound = "hvap/gun/cnn/88pak/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 88pak fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.88pak.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/88pak/fire_1.wav",
		"hvap/gun/cnn/88pak/fire_2.wav",
		"hvap/gun/cnn/88pak/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 90m3
-------------------------------------------------------

sound.Add( -- gun 90m3 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.90m3.Distant",
    level = 160,
    sound = "hvap/gun/cnn/90m3/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 90m3 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.90m3.Far",
    level = 145,
    sound = "hvap/gun/cnn/90m3/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 90m3 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.90m3.Close",
    level = 130,
    sound = "hvap/gun/cnn/90m3/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 90m3 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.90m3.Near",
    level = 115,
    sound = "hvap/gun/cnn/90m3/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 90m3 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.90m3.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/90m3/fire_1.wav",
		"hvap/gun/cnn/90m3/fire_2.wav",
		"hvap/gun/cnn/90m3/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 100d10t
-------------------------------------------------------

sound.Add( -- gun 100d10t distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.100d10t.Distant",
    level = 160,
    sound = "hvap/gun/cnn/100d10t/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 100d10t far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.100d10t.Far",
    level = 145,
    sound = "hvap/gun/cnn/100d10t/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 100d10t close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.100d10t.Close",
    level = 130,
    sound = "hvap/gun/cnn/100d10t/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 100d10t near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.100d10t.Near",
    level = 115,
    sound = "hvap/gun/cnn/100d10t/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 100d10t fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.100d10t.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/100d10t/fire_1.wav",
		"hvap/gun/cnn/100d10t/fire_2.wav",
		"hvap/gun/cnn/100d10t/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 105kwk36
-------------------------------------------------------

sound.Add( -- gun 105kwk36 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.105kwk36.Distant",
    level = 160,
    sound = "hvap/gun/cnn/105kwk36/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 105kwk36 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.105kwk36.Far",
    level = 145,
    sound = "hvap/gun/cnn/105kwk36/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 105kwk36 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.105kwk36.Close",
    level = 130,
    sound = "hvap/gun/cnn/105kwk36/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 105kwk36 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.105kwk36.Near",
    level = 115,
    sound = "hvap/gun/cnn/105kwk36/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 105kwk36 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.105kwk36.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/105kwk36/fire_1.wav",
		"hvap/gun/cnn/105kwk36/fire_2.wav",
		"hvap/gun/cnn/105kwk36/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 122d25t
-------------------------------------------------------

sound.Add( -- gun 122d25t distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.122D25T.Distant",
    level = 160,
    sound = "hvap/gun/cnn/122d25t/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 122d25t far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.122D25T.Far",
    level = 145,
    sound = "hvap/gun/cnn/122d25t/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 122d25t close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.122D25T.Close",
    level = 130,
    sound = "hvap/gun/cnn/122d25t/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 122d25t near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.122D25T.Near",
    level = 115,
    sound = "hvap/gun/cnn/122d25t/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 122d25t fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.122D25T.Fire",
    level = 100,
    sound = "hvap/gun/cnn/122d25t/fire_1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 128pak44
-------------------------------------------------------

sound.Add( -- gun 128pak44 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.128pak44.Distant",
    level = 160,
    sound = "hvap/gun/cnn/128pak44/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 128pak44 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.128pak44.Far",
    level = 145,
    sound = "hvap/gun/cnn/128pak44/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 128pak44 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.128pak44.Close",
    level = 130,
    sound = "hvap/gun/cnn/128pak44/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 128pak44 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.128pak44.Near",
    level = 115,
    sound = "hvap/gun/cnn/128pak44/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 128pak44 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.128pak44.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/128pak44/fire_1.wav",
		"hvap/gun/cnn/128pak44/fire_2.wav",
		"hvap/gun/cnn/128pak44/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- 152m10
-------------------------------------------------------

sound.Add( -- gun 152m10 distant
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.152m10.Distant",
    level = 160,
    sound = "hvap/gun/cnn/152m10/4.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 152m10 far
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.152m10.Far",
    level = 145,
    sound = "hvap/gun/cnn/152m10/3.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 152m10 close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.152m10.Close",
    level = 130,
    sound = "hvap/gun/cnn/152m10/2.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 152m10 near
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.152m10.Near",
    level = 115,
    sound = "hvap/gun/cnn/152m10/1.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun 152m10 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.152m10.Fire",
    level = 100,
    sound = 	{
		"hvap/gun/cnn/152m10/fire_1.wav",
		"hvap/gun/cnn/152m10/fire_2.wav",
		"hvap/gun/cnn/152m10/fire_3.wav",
		},
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- besa
-------------------------------------------------------

sound.Add( -- gun besa fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/besa/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun besa fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/besa/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun besa close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/besa/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun besa close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/besa/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun besa near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/besa/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun besa near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/besa/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun besa far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/besa/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun besa far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BESA.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/besa/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- dp28
-------------------------------------------------------

sound.Add( -- gun dp28 fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/dp28/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dp28 fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/dp28/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dp28 close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/dp28/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dp28 close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/dp28/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dp28 near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/dp28/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dp28 near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/dp28/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dp28 far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/dp28/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dp28 far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DP28.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/dp28/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- dshk
-------------------------------------------------------

sound.Add( -- gun dshk fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/dshk/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dshk fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/dshk/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dshk close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/dshk/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dshk close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/dshk/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dshk near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/dshk/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dshk near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/dshk/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dshk far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/dshk/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun dshk far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.DShK.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/dshk/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- kpv
-------------------------------------------------------

sound.Add( -- gun kpv fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/kpv/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun kpv fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/kpv/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun kpv close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/kpv/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun kpv close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/kpv/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun kpv near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/kpv/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun kpv near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/kpv/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun kpv far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/kpv/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun kpv far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.KPV.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/kpv/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- mg34
-------------------------------------------------------

sound.Add( -- gun mg34 fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/mg34/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg34 fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/mg34/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg34 close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/mg34/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg34 close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/mg34/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg34 near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/mg34/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg34 near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/mg34/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg34 far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/mg34/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg34 far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG34.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/mg34/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- mg42
-------------------------------------------------------

sound.Add( -- gun mg42 fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/mg42/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg42 fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/mg42/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg42 close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/mg42/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg42 close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/mg42/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg42 near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/mg42/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg42 near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/mg42/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg42 far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/mg42/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mg42 far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG42.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/mg42/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- mk103
-------------------------------------------------------

sound.Add( -- gun mk103 fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/mk103/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mk103 fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/mk103/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mk103 close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/mk103/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mk103 close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/mk103/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mk103 near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/mk103/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mk103 near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/mk103/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mk103 far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/mk103/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun mk103 far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/mk103/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- oerlicon
-------------------------------------------------------

sound.Add( -- gun oerlicon fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/oerlicon/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun oerlicon fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/oerlicon/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun oerlicon close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/oerlicon/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun oerlicon close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/oerlicon/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun oerlicon near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/oerlicon/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun oerlicon near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/oerlicon/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun oerlicon far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/oerlicon/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun oerlicon far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Oerlicon.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/oerlicon/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- sg43
-------------------------------------------------------

sound.Add( -- gun sg43 fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/sg43/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun sg43 fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/sg43/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun sg43 close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/sg43/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun sg43 close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/sg43/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun sg43 near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/sg43/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun sg43 near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/sg43/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun sg43 far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/sg43/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun sg43 far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.SG43.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/sg43/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- tnsh
-------------------------------------------------------

sound.Add( -- gun tnsh fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/tnsh/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun tnsh fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/tnsh/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun tnsh close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/tnsh/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun tnsh close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/tnsh/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun tnsh near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/tnsh/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun tnsh near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/tnsh/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun tnsh far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/tnsh/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun tnsh far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.TNSh.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/tnsh/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

-------------------------------------------------------
--###################################################-- vickers
-------------------------------------------------------

sound.Add( -- gun vickers fire loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Fire.Loop",
    level = 100,
    sound = "hvap/gun/tank_mg/vickers/1_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun vickers fire end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Fire.End",
    level = 100,
    sound = "hvap/gun/tank_mg/vickers/1_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun vickers close loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Close.Loop",
    level = 115,
    sound = "hvap/gun/tank_mg/vickers/2_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun vickers close end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Close.End",
    level = 115,
    sound = "hvap/gun/tank_mg/vickers/2_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun vickers near loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Near.Loop",
    level = 130,
    sound = "hvap/gun/tank_mg/vickers/3_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun vickers near end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Near.End",
    level = 130,
    sound = "hvap/gun/tank_mg/vickers/3_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun vickers far loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Far.Loop",
    level = 145,
    sound = "hvap/gun/tank_mg/vickers/4_loop.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})

sound.Add( -- gun vickers far end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Vickers.Far.End",
    level = 145,
    sound = "hvap/gun/tank_mg/vickers/4_end.wav",
    volume = 1.0,
	pitch = { 90, 110 },
})
