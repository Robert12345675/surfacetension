
-------------------------------------------------------
--###################################################-- Countermeasure
-------------------------------------------------------

sound.Add( -- cm flares small
{
    channel = CHAN_AUTO,
    name = "HVAP.CM.Flares.Small",
    level = 90,
    sound = "hvap/countermeasure/flares_small.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- cm flares large
{
    channel = CHAN_AUTO,
    name = "HVAP.CM.Flares.Large",
    level = 90,
    sound = "hvap/countermeasure/flares_large.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- cm graphite
{
    channel = CHAN_AUTO,
    name = "HVAP.CM.Graphite",
    level = 90,
    sound = 	{
		"hvap/countermeasure/graphite_1.wav",
		"hvap/countermeasure/graphite_2.wav",
		"hvap/countermeasure/graphite_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- cm smoke
{
    channel = CHAN_AUTO,
    name = "HVAP.CM.Smoke",
    level = 90,
    sound = 	{
		"hvap/countermeasure/smoke_1.wav",
		"hvap/countermeasure/smoke_2.wav",
		"hvap/countermeasure/smoke_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- cm ready
{
    channel = CHAN_AUTO,
    name = "HVAP.CM.Ready",
    level = 80,
    sound = "hvap/countermeasure/ready.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Hatch
-------------------------------------------------------

sound.Add( -- hatch start
{
    channel = CHAN_AUTO,
    name = "HVAP.Hatch.Start",
    level = 80,
    sound = "hvap/secondary/bomb/hatch_start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- hatch loop
{
    channel = CHAN_AUTO,
    name = "HVAP.Hatch.Loop",
    level = 80,
    sound = "hvap/secondary/bomb/hatch_loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- hatch stop
{
    channel = CHAN_AUTO,
    name = "HVAP.Hatch.Stop",
    level = 80,
    sound = "hvap/secondary/bomb/hatch_stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Reloads
-------------------------------------------------------

sound.Add( -- reload small
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Small",
    level = 80,
    sound = "hvap/gun/reload/gunner_reload_1.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload medium
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Medium",
    level = 80,
    sound = "hvap/gun/reload/gunner_reload_2.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload large
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Large",
    level = 80,
    sound = "hvap/gun/reload/gunner_reload_3.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload multi
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Multi",
    level = 80,
    sound = "hvap/gun/reload/gunner_reload_multi.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload belt
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Belt",
    level = 80,
    sound = "hvap/gun/reload/modern_gun.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload autocannon
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.AutoCannon",
    level = 80,
    sound = 	{
		"hvap/gun/reload/autoloader_1.wav",
		"hvap/gun/reload/autoloader_2.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload cannon
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Cannon",
    level = 80,
    sound = 	{
		"hvap/gun/reload/reload_1.wav",
		"hvap/gun/reload/reload_2.wav",
		"hvap/gun/reload/reload_3.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload shelldrop large
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.ShellDrop.Large",
    level = 80,
    sound = 	{
		"hvap/gun/reload/shell_drop_large_1.wav",
		"hvap/gun/reload/shell_drop_large_2.wav",
		"hvap/gun/reload/shell_drop_large_3.wav",
		"hvap/gun/reload/shell_drop_large_4.wav",
		"hvap/gun/reload/shell_drop_large_5.wav",
		"hvap/gun/reload/shell_drop_large_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload shelldrop small
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.ShellDrop.Small",
    level = 80,
    sound = 	{
		"hvap/gun/reload/shell_drop_small_1.wav",
		"hvap/gun/reload/shell_drop_small_2.wav",
		"hvap/gun/reload/shell_drop_small_3.wav",
		"hvap/gun/reload/shell_drop_small_4.wav",
		"hvap/gun/reload/shell_drop_small_5.wav",
		"hvap/gun/reload/shell_drop_small_6.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload secondary
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Secondary",
    level = 80,
    sound = "hvap/secondary/reload/reload.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload modern
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Modern",
    level = 80,
    sound = "hvap/secondary/reload/modern.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload cm
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.CM",
    level = 80,
    sound = "hvap/secondary/countermeasure/reload.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- reload cm
{
    channel = CHAN_AUTO,
    name = "HVAP.Reload.Pickup",
    level = 80,
    sound = "items/ammo_pickup.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Alarms
-------------------------------------------------------

sound.Add( -- alarm 25
{
    channel = CHAN_AUTO,
    name = "HVAP.Alarm.25",
    level = 80,
    sound = "hvap/alarm/25.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- alarm 50
{
    channel = CHAN_AUTO,
    name = "HVAP.Alarm.50",
    level = 80,
    sound = "hvap/alarm/50.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- alarm 75
{
    channel = CHAN_AUTO,
    name = "HVAP.Alarm.75",
    level = 80,
    sound = "hvap/alarm/75.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- alarm damaged
{
    channel = CHAN_AUTO,
    name = "HVAP.Alarm.Damaged",
    level = 80,
    sound = "hvap/alarm/damaged.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- alarm missile
{
    channel = CHAN_AUTO,
    name = "HVAP.Alarm.Missile",
    level = 80,
    sound = "hvap/alarm/rocket_warning.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Misc Cockpit
-------------------------------------------------------

sound.Add( -- switch clang
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.Clang",
    level = 80,
    sound = "hvap/misc/switch_1.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch click
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.Click",
    level = 80,
    sound = "hvap/misc/switch_2.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch beepclick
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.BeepClick",
    level = 80,
    sound = "hvap/misc/switch_3.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch boopclick
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.BoopClick",
    level = 80,
    sound = "hvap/misc/switch_4.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch beepflick
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.BeepFlick",
    level = 80,
    sound = "hvap/misc/switch_5.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch zoom
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.Zoom",
    level = 80,
    sound = "hvap/misc/zoom.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch select_1
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.Select_1",
    level = 80,
    sound = "hvap/misc/select_1.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch select_2
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.Select_2",
    level = 80,
    sound = "hvap/misc/select_2.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch select_3
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.Select_3",
    level = 80,
    sound = "hvap/misc/select_3.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch flir in_1
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.FLIR.In_1",
    level = 80,
    sound = "hvap/misc/flir_in_1.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch flir in_2
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.FLIR.In_2",
    level = 80,
    sound = "hvap/misc/flir_in_2.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch flir out_1
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.FLIR.Out_1",
    level = 80,
    sound = "hvap/misc/flir_out_1.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- switch flir out_2
{
    channel = CHAN_AUTO,
    name = "HVAP.Switch.FLIR.Out_2",
    level = 80,
    sound = "hvap/misc/flir_out_2.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Misc
-------------------------------------------------------

sound.Add( -- misc fpe
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.FPE",
    level = 80,
    sound = "hvap/misc/fireextinguisher.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- misc cable on
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.Cable.On",
    level = 80,
    sound = "hvap/misc/cable_on.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- misc cable off
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.Cable.Off",
    level = 80,
    sound = "hvap/misc/cable_off.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- misc jammer start
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.Jammer.Start",
    level = 80,
    sound = "hvap/misc/jammer_start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- misc jammer loop
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.Jammer.Loop",
    level = 80,
    sound = "hvap/misc/jammer_loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- misc jammer stop
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.Jammer.Stop",
    level = 80,
    sound = "hvap/misc/jammer_stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- misc repair large
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.Repair.Large",
    level = 80,
    sound = "hvap/misc/repair_1.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- misc repair small
{
    channel = CHAN_AUTO,
    name = "HVAP.Misc.Repair.Small",
    level = 80,
    sound = "hvap/misc/repair_2.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- Vehicle
-------------------------------------------------------

sound.Add( -- vehicle collide
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Collide",
    level = 100,
    sound = 	{
		"hvap/impact/impact_1.wav",
		"hvap/impact/impact_2.wav",
		"hvap/impact/impact_3.wav",
		"hvap/impact/impact_4.wav",
		"hvap/impact/impact_5.wav",
		"hvap/impact/impact_6.wav",
		"hvap/impact/impact_7.wav",
		"hvap/impact/impact_8.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- vehicle burn
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Burn",
    level = 85,
    sound = 	{
		"hvap/tank/burn_1.wav",
		"hvap/tank/burn_2.wav",
		"hvap/tank/burn_3.wav"		
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- vehicle lever
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Lever",
    level = 80,
    sound = 	{
		"hvap/tank/fx/lever_1.wav",
		"hvap/tank/fx/lever_2.wav",
		"hvap/tank/fx/lever_3.wav",
		"hvap/tank/fx/lever_4.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- vehicle rattle
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Rattle",
    level = 80,
    sound = 	{
		"hvap/tank/fx/rattle_1.wav",
		"hvap/tank/fx/rattle_2.wav",
		"hvap/tank/fx/rattle_3.wav",
		"hvap/tank/fx/rattle_4.wav",
		"hvap/tank/fx/rattle_5.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- vehicle turret clank
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Clank",
    level = 80,
    sound = 	{
		"hvap/tank/fx/turret_klank_01.wav",
		"hvap/tank/fx/turret_klank_02.wav",
		"hvap/tank/fx/turret_klank_03.wav",
		"hvap/tank/fx/turret_klank_04.wav",
		"hvap/tank/fx/turret_klank_05.wav",
		"hvap/tank/fx/turret_klank_06.wav",
		"hvap/tank/fx/turret_klank_07.wav",
		"hvap/tank/fx/turret_klank_08.wav",
		"hvap/tank/fx/turret_klank_09.wav",
		"hvap/tank/fx/turret_klank_10.wav",
		"hvap/tank/fx/turret_klank_11.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

sound.Add( -- vehicle interior idle
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Interior.Idle",
    level = 80,
    sound = "hvap/engine/shared/tank_interior.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Turrets
-------------------------------------------------------

sound.Add( -- vehicle turret traverse hydraulic
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Traverse.Hydraulic",
    level = 80,
    sound = "hvap/tank/turret/turn_1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle turret traverse crank
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Traverse.Crank",
    level = 80,
    sound = "hvap/tank/turret/turn_2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle turret traverse electric
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Traverse.Electric",
    level = 80,
    sound = "hvap/tank/turret/turn_3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle turret elevate hydraulic
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Elevate.Hydraulic",
    level = 80,
    sound = "hvap/tank/turret/elevate_1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle turret elevate crank
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Elevate.Crank",
    level = 80,
    sound = "hvap/tank/turret/elevate_2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle turret elevate electric
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Elevate.Electric",
    level = 80,
    sound = "hvap/tank/turret/elevate_3.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- vehicle turret traverse ship
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Traverse.Ship",
    level = 80,
    sound = "hvap/ship/turret/turn.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle turret elevate ship
{
    channel = CHAN_AUTO,
    name = "HVAP.Vehicle.Turret.Elevate.Ship",
    level = 80,
    sound = "hvap/ship/turret/elevate.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Weapon Jam/Overheat
-------------------------------------------------------

sound.Add( -- gun jam belt
{
    channel = CHAN_AUTO,
    name = "HVAP.Gun.Jam.Belt",
    level = 80,
    sound = "hvap/gun/jam/belt_jam.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- gun jam click end
{
    channel = CHAN_AUTO,
    name = "HVAP.Gun.Jam.Click.End",
    level = 80,
    sound = "hvap/gun/jam/overheat_click_end.wav",
    volume = 1.0,
	pitch = 1--
})

sound.Add( -- gun jam click loop
{
    channel = CHAN_AUTO,
    name = "HVAP.Gun.Jam.Click.Loop",
    level = 80,
    sound = "hvap/gun/jam/overheat_click_loop.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- gun jam start
{
    channel = CHAN_AUTO,
    name = "HVAP.Gun.Jam.Start",
    level = 80,
    sound = "hvap/gun/jam/overheated.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- gun jam finish
{
    channel = CHAN_AUTO,
    name = "HVAP.Gun.Jam.Finish",
    level = 80,
    sound = "hvap/gun/jam/overheat_finish.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- gun jam ready
{
    channel = CHAN_AUTO,
    name = "HVAP.Gun.Jam.Ready",
    level = 80,
    sound = "hvap/misc/gun_ready.wav",
    volume = 1.0,
	pitch = 100
})
