
include "hvap/aircraft.lua"

CreateClientConVar("hvap_cl_air_sensitivity", 1, true, true)
CreateClientConVar("hvap_cl_air_mouse", 1, true, true)

CreateClientConVar("hvap_cl_air_autolevel", 1, true, true)

CreateClientConVar("hvap_cl_air_incthr", 0, true, true)
CreateClientConVar("hvap_cl_air_throttle_sensitivity", 5, true, true)
CreateClientConVar("hvap_cl_air_throttle_sensitivity_p", 5, true, true)

CreateClientConVar("hvap_cl_air_mouse_swap", 1, true, true)
CreateClientConVar("hvap_cl_air_mouse_invert_pitch", 0, true, true)
CreateClientConVar("hvap_cl_air_mouse_invert_yawroll", 0, true, true)
CreateClientConVar("hvap_cl_air_smoothview", 0, true, true)
CreateClientConVar("hvap_cl_air_shakeview", 0, true, true)
CreateClientConVar("hvap_cl_air_smoothkeyboard", 1, true, true)
CreateClientConVar("hvap_cl_air_volume", 1, true, true)
CreateClientConVar("hvap_cl_air_spawneffect", 0, true, true)
CreateClientConVar("hvap_cl_air_esmokeeffect", 1, true, true)
CreateClientConVar("hvap_cl_air_eheateffect", 1, true, true)
CreateClientConVar("hvap_cl_air_gsmokeeffect", 1, true, true)
CreateClientConVar("hvap_cl_air_bulleteffect", 1, true, true)

if not game.SinglePlayer() then
	CreateClientConVar("hvap_air_startspeed", 4, true)
	CreateClientConVar("hvap_air_waterdamage", 1, true)	
	CreateClientConVar("hvap_air_damagemul", 1, true)
	CreateClientConVar("hvap_air_speedmul", 1, true)
	CreateClientConVar("hvap_air_fhealthmul", 1, true)
	CreateClientConVar("hvap_air_ehealthmul", 1, true)
	CreateClientConVar("hvap_air_rhealthmul", 1, true)
	CreateClientConVar("hvap_noplydmg", 0, true)
	CreateClientConVar("hvap_kickdeath", 1, true)
	CreateClientConVar("hvap_thirdperson_enabled", 1, true)	
	CreateClientConVar("hvap_fuel_enabled", 1, true)	
	CreateClientConVar("hvap_consumption_mult", 1, true)
	CreateClientConVar("hvap_tracers", 1, true)
	CreateClientConVar("hvap_viewmode_ir", 1, true)
	CreateClientConVar("hvap_viewmode_nv", 1, true)
	CreateClientConVar("hvap_nospawnordinance", 0, true)
	
	local function onchange( name, oldval, val )
		if LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then
			net.Start("hvap_admin_setting")
				net.WriteString(name)
				net.WriteFloat(val)
			net.SendToServer()
		end
	end 
	cvars.AddChangeCallback("hvap_air_startspeed",onchange)
	cvars.AddChangeCallback("hvap_air_waterdamage",onchange)	
	cvars.AddChangeCallback("hvap_air_speedmul",onchange)
	cvars.AddChangeCallback("hvap_air_damagemul",onchange)
	cvars.AddChangeCallback("hvap_air_fhealthmul",onchange)
	cvars.AddChangeCallback("hvap_air_ehealthmul",onchange)
	cvars.AddChangeCallback("hvap_air_rhealthmul",onchange)
	cvars.AddChangeCallback("hvap_noplydmg",onchange)
	cvars.AddChangeCallback("hvap_kickdeath",onchange)
	cvars.AddChangeCallback("hvap_thirdperson_enabled",onchange)
	cvars.AddChangeCallback("hvap_arcade_enabled",onchange)
	cvars.AddChangeCallback("hvap_fuel_enabled",onchange)
	cvars.AddChangeCallback("hvap_consumption_mult",onchange)
	cvars.AddChangeCallback("hvap_tracers",onchange)
	cvars.AddChangeCallback("hvap_viewmode_ir",onchange)
	cvars.AddChangeCallback("hvap_viewmode_nv",onchange)
	cvars.AddChangeCallback("hvap_nospawnordinance",onchange)

end

hvap.hook("ShouldDrawLocalPlayer", "hvap_air_showplayerthirdperson", function()
	local pl = LocalPlayer()
	if !IsValid(pl) or !pl:InVehicle() then return false end
	local v = pl:GetVehicle()
	if IsValid(v) and IsValid(v:GetNWEntity("hvap_aircraft")) then
		return v:GetThirdPersonMode()
	end
end)

hvap.hook("ContextMenuOpen", "hvap_air_cl_context_disable", function()
	local pl = LocalPlayer()
	if !IsValid(pl) or !pl:InVehicle() then return true end
	local v = pl:GetVehicle()
	if IsValid(v) and IsValid(v:GetNWEntity("hvap_aircraft")) then
		return false
	end
end)

hvap.hook("SpawnMenuOpen", "hvap_air_cl_spawnmenu_disable", function()
	local pl = LocalPlayer()
	if !IsValid(pl) or !pl:InVehicle() then return true end
	local v = pl:GetVehicle()
	if IsValid(v) and IsValid(v:GetNWEntity("hvap_aircraft")) then
		return false
	end
end)

surface.CreateFont("hvap_heli_big", {
	font = "monospace",
	size = 32
})

surface.CreateFont("hvap_heli_small", {
	font = "monospace",
	size = 22
})

hvap.hook("CalcView", "hvap_air_calcview", function( ply, pos, ang, fov )

	ply.hvap = ply.hvap or {}
	ply.hvap.air = ply.hvap.air or {}

	local aircraft = ply.hvap.air.vehicle --ply:GetVehicle():GetNWEntity("hvap_aircraft")
	if !IsValid(aircraft) then
		local v=ply:GetVehicle()
		if IsValid(v) and IsValid(v:GetNWEntity("hvap_aircraft")) then
			aircraft = ply:GetVehicle():GetNWEntity("hvap_aircraft")
			aircraft.viewPos = {
				origin = ply.hvap.air.lastView.origin - pos,
				angles = ply.hvap.air.lastView.angles - ang,
				fov = fov
			}
			aircraft:onEnter(ply)
		else
			ply.hvap.air.vehicle = nil
			ply.hvap.air.lastView = {origin=pos, angles=ang, fov=fov}
			return
		end
	end
	
	local i = ply:GetNWInt("hvap_passenger_id")
	if ply.hvap.air.vehicle and GetViewEntity() == ply and aircraft.Seats then
		return aircraft:CreateViewCalc(i, ply, pos, ang, fov)
	end

end)

hvap.hook("RenderScreenspaceEffects", "hvap_air_weaponcam",function()
	local ply=LocalPlayer()
	if !IsValid(ply) then return end
	local v=ply:GetVehicle()
	if !IsValid(v) then return end
	local e=v:GetNWEntity("hvap_aircraft")
	if IsValid(e) then
		e:CreateScreenSpaceEffects(ply:GetNWInt("hvap_passenger_id"),ply)
	end
end)

hvap.hook("HUDPaint", "hvap_air_weaponhud", function()
	local ply=LocalPlayer()
	if !IsValid(ply) then return end
	local v=ply:GetVehicle()
	if !IsValid(v) then return end
	local e=v:GetNWEntity("hvap_aircraft")
	if IsValid(e) then
		e:CreateHUDPaint(ply:GetNWInt("hvap_passenger_id"),ply)
	end
end)

hvap.hook("CreateMove", "hvap_cl_air_mouseinput", function(md)
	local ply=LocalPlayer()
	if !IsValid(ply) then return end
	local v=ply:GetVehicle()
	if !IsValid(v) then return end
	local e=v:GetNWEntity("hvap_aircraft")
	if IsValid(e) then
		e:MovePlayerView(ply:GetNWInt("hvap_passenger_id"),ply,md)
	end
end)
-- menu
hvap.addMenuPanel(hvap.menu.tab, hvap.menu.category, hvap.menu.aircraft, function(panel, info)

	panel:AddControl("Label", {Text = "Client Settings"})
	
	local presetParams = {
		Label = "Presets",
		MenuButton = 1,
		Folder = "hvap",
		Options = {
			mouse = {
				hvap_cl_air_mouse = "1",
				hvap_cl_air_incthr = "0",
				hvap_cl_air_autolevel = "1",
				hvap_cl_air_mouse_swap ="1",
				hvap_cl_air_mouse_invert_pitch = "0",
				hvap_cl_air_mouse_invert_yawroll = "0",
				
				hvap_cl_air_key_Exit = KEY_E,
				hvap_cl_air_key_Start = KEY_I,
				
				hvap_cl_air_key_Throttle_Inc = KEY_W,
				hvap_cl_air_key_Throttle_Dec = KEY_S,
				
				hvap_cl_air_key_Yaw_Inc = KEY_A,
				hvap_cl_air_key_Yaw_Dec = KEY_D,
				hvap_cl_air_key_Pitch_Inc = KEY_UP,
				hvap_cl_air_key_Pitch_Dec = KEY_DOWN,
				hvap_cl_air_key_Roll_Inc = KEY_LEFT,
				hvap_cl_air_key_Roll_Dec = KEY_RIGHT,
				
				hvap_cl_air_key_FreeView = KEY_SPACE,
				
				hvap_cl_air_key_Zoom = KEY_LSHIFT,
				hvap_cl_air_key_RenderMode = MOUSE_MIDDLE,
				hvap_cl_air_key_Doors = KEY_LCONTROL,
				
				hvap_cl_air_key_FirstFire = MOUSE_LEFT,
				hvap_cl_air_key_SecondFire = MOUSE_RIGHT, 
				hvap_cl_air_key_NextWeapon = KEY_R,
				
				hvap_cl_air_key_FirstMenu = KEY_Q,
				hvap_cl_air_key_SecondMenu = KEY_C,
				
				hvap_cl_air_key_Function1 = KEY_B,
				hvap_cl_air_key_Function2 = KEY_O,
				hvap_cl_air_key_Function3 = KEY_P,
				
				hvap_cl_air_key_Bail = KEY_J,
				
				hvap_cl_air_key_Hover = KEY_H,
				hvap_cl_air_key_Gear = KEY_G,
				
				hvap_cl_air_key_Left = KEY_A,
				hvap_cl_air_key_Right = KEY_D,
				
--				hvap_cl_air_key_Scroll_Up = MOUSE_WHEEL_UP,
--				hvap_cl_air_key_Scroll_Down = MOUSE_WHEEL_DOWN		
			},
		},
		CVars = {
			"hvap_cl_air_sensitivity",
			"hvap_cl_air_usejoystick",
			"hvap_cl_air_mouse",
			"hvap_cl_air_incthr",
			"hvap_cl_air_autolevel",
			"hvap_cl_air_throttle_sensitivity",
			"hvap_cl_air_throttle_sensitivityP",
			"hvap_cl_air_mouse_swap",
			"hvap_cl_air_mouse_invert_pitch",
			"hvap_cl_air_mouse_invert_yawroll",
		}
	}	
	for category, controls in pairs(hvap.aircraft.controls) do
		for i, t in pairs(controls) do
			if !t[3] then
				table.insert(presetParams.CVars, "hvap_cl_air_key_" .. i)
			else
				table.insert(presetParams.CVars, "hvap_cl_air_key_" .. i .. "_Inc")
				table.insert(presetParams.CVars, "hvap_cl_air_key_" .. i .. "_Dec")
			end
		end
	end
	panel:AddControl("ComboBox", presetParams)

	for i, controls in pairs(hvap.aircraft.controls) do
		panel:AddControl("Label", {Text = controls.name})
		for name, t in pairs(controls.list) do
			if !t[3] then
				local k = vgui.Create("hvapkeyboard::key", panel)
				k:setLabel(name)
				k:setKey(t[2])
				k.runCommand="hvap_cl_air_key_"..name
				panel:AddPanel(k)
			else
				local f = vgui.Create("hvapkeyboard::key", panel)
				f:setLabel(name .. " +")
				f:setKey(t[2])
				f.runCommand = "hvap_cl_air_key_"..name.."_Inc"
				panel:AddPanel(f)
				local k = vgui.Create("hvapkeyboard::key", panel)
				k:setLabel(name .. " -")
				k:setKey(t[3])
				k.runCommand = "hvap_cl_air_key_"..name.."_Dec"
				panel:AddPanel(k)
			end
		end
	end

	panel:AddControl("Slider", {
		Label="Volume",
		Type="float",
		Min=0.256,
		Max=1,
		Command="hvap_cl_air_volume",
	})
	
	panel:CheckBox("Dynamic View Angle","hvap_cl_air_smoothview")
	
	panel:CheckBox("Dynamic View Position","hvap_cl_air_shakeview")

	panel:AddControl("Label", {Text = ""})

	panel:CheckBox("Auto Level Helicopter","hvap_cl_air_autolevel")
	
	panel:CheckBox("Incremental Throttle (Helicopter)","hvap_cl_air_incthr")
	if info["hvap_cl_air_incthr"]=="1" then
		panel:AddControl("Slider", {
			Label = "Throttle Sensitivity",
			Type = "float",
			Min = 1,
			Max = 25,
			Command = "hvap_cl_air_throttle_sensitivity",
		})
		panel:AddControl("Label", {Text = ""})
	end	
	

	panel:AddControl("Slider", {
		Label = "Throttle Sensitivity (Planes)",
		Type = "float",
		Min = 1,
		Max = 25,
		Command = "hvap_cl_air_throttle_sensitivity_p",
	})
	
	panel:CheckBox("Use Mouse","hvap_cl_air_mouse")
	if info["hvap_cl_air_mouse"]=="1" then
		panel:CheckBox(" - Invert Pitch","hvap_cl_air_mouse_invert_pitch")
		panel:CheckBox(" - Invert Yaw/Roll","hvap_cl_air_mouse_invert_yawroll")
		panel:CheckBox(" - Swap Yaw/Roll","hvap_cl_air_mouse_swap")
		panel:AddControl("Label", {Text = ""})
		panel:AddControl("Slider", {
			Label = "Mouse Sensitivity",
			Type = "float",
			Min = 0.5,
			Max = 1.9,
			Command = "hvap_cl_air_sensitivity",
		})
	end

	panel:AddControl("Button", {
		Label = "Joystick Configuration",
		Command = "joyconfig"
	})
	
	panel:AddControl("Label", {Text = ""})
	panel:AddControl("Label", {Text = "Client Performance Settings"})
	
	panel:CheckBox("Enable Spawn Effects","hvap_cl_air_spawneffect")	
	panel:CheckBox("Enable Engine Smoke Effects","hvap_cl_air_esmokeeffect")	
	panel:CheckBox("Enable Engine Heat Effects","hvap_cl_air_eheateffect")	
	panel:CheckBox("Enable Fancy Muzzle Effects","hvap_cl_air_gsmokeeffect")	
	panel:CheckBox("Enable Fancy Effects","hvap_cl_air_bulleteffect")	
	
	panel:AddControl("Label", {Text = ""})
	panel:AddControl("Label", {Text = "Admin Settings"})
	
	panel:CheckBox("Enable Third Person","hvap_thirdperson_enabled")		
	panel:CheckBox("Enable Tracers","hvap_tracers")
	panel:CheckBox("Enable Infra Red","hvap_viewmode_ir")
	panel:CheckBox("Enable Night Vision","hvap_viewmode_nv")
	panel:CheckBox("Enable Fuel Consumption","hvap_fuel_enabled")	
	panel:CheckBox("Disable Spawning With Secondary Ordinance","hvap_nospawnordinance")	
	panel:CheckBox("Disable Passenger Damage","hvap_noplydmg")	
	panel:CheckBox("Kick Passengers From Dead Aircraft","hvap_kickdeath")		
	
	panel:AddControl("Slider", {-- start speed
		Label="Start Speed",
		Type="Untitled",
		Min=1,
		Max=10,
		Command="hvap_air_startspeed",
	})
	panel:AddControl("Label", {Text = ""})		

	panel:AddControl("Slider", {-- start speed
		Label="Speed Multiplier",
		Type="Untitled",
		Min=1,
		Max=5,
		Command="hvap_air_speedmul",
	})
	panel:AddControl("Label", {Text = ""})	
	
	panel:AddControl("Slider", {-- fuel consumption
		Label="Fuel Consumption",
		Type="Untitled",
		Min=0.01,
		Max=10,
		Command="hvap_consumption_mult",
	})
	panel:AddControl("Label", {Text = ""})			
	
	panel:AddControl("Slider", {-- damage multiplier
		Label="Weapon Damage Multiplier",
		Type="Untitled",
		Min=0.1,
		Max=10,
		Command="hvap_air_damagemul",
	})	
	panel:AddControl("Label", {Text = ""})			
	
	panel:AddControl("Slider", {-- health multiplier
		Label="Fuselage Health Multiplier",
		Type="Untitled",
		Min=0,
		Max=10,
		Command="hvap_air_fhealthmul",
	})		
	panel:AddControl("Label", {Text = "(0 means unbreakable everything)"})	
	panel:AddControl("Label", {Text = ""})		
	
	panel:AddControl("Slider", {-- engine health multiplier
		Label="Engine Health Multiplier",
		Type="Untitled",
		Min=0,
		Max=10,
		Command="hvap_air_ehealthmul",
	})	
	panel:AddControl("Label", {Text = "(0 means unbreakable engines)"})	
	panel:AddControl("Label", {Text = ""})	
	
	panel:AddControl("Slider", {-- rotor health multiplier
		Label="Rotor Health Multiplier",
		Type="Untitled",
		Min=0,
		Max=10,
		Command="hvap_air_rhealthmul",
	})			
	panel:AddControl("Label", {Text = "(0 means unbreakable rotors)"})	
	panel:AddControl("Label", {Text = ""})		
	
	panel:AddControl("Slider", {
		Label="Water Damage",
		Type="Untitled",
		Min=0,
		Max=5,
		Command="hvap_air_waterdamage",
	})	
	panel:AddControl("Label", {Text = "(0 means no water damage)"})	
	panel:AddControl("Label", {Text = ""})		
end,
	"hvap_cl_air_mouse",
	"hvap_cl_air_incthr",
	"hvap_cl_air_showdevhelp"
)
