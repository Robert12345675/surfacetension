-------------------------------------------------------
--###################################################-- Hetzer
-------------------------------------------------------

sound.Add( -- engine hetzer start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.Start",
    level = 80,
    sound = "hvap/engine/hetzer/start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine hetzer stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.Stop",
    level = 80,
    sound = "hvap/engine/hetzer/stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine hetzer rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.Rev",
    level = 115,
    sound = {
		"hvap/engine/hetzer/rev_1.wav",
		"hvap/engine/hetzer/rev_2.wav",
		"hvap/engine/hetzer/rev_3.wav",
		"hvap/engine/hetzer/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine hetzer external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.External.Idle",
    level = 110,
    sound = "hvap/engine/hetzer/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hetzer external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.External.Low",
    level = 110,
    sound = "hvap/engine/hetzer/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hetzer external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.External.Medium",
    level = 110,
    sound = "hvap/engine/hetzer/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hetzer external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.External.High",
    level = 110,
    sound = "hvap/engine/hetzer/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine hetzer internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.Internal.Idle",
    level = 110,
    sound = "hvap/engine/hetzer/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hetzer internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.Internal.Low",
    level = 110,
    sound = "hvap/engine/hetzer/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hetzer internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.Internal.Medium",
    level = 110,
    sound = "hvap/engine/hetzer/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hetzer internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Hetzer.Internal.High",
    level = 110,
    sound = "hvap/engine/hetzer/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- M4A1
-------------------------------------------------------

sound.Add( -- engine m4a1 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.Start",
    level = 80,
    sound = "hvap/engine/m4a1/start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine m4a1 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.Stop",
    level = 80,
    sound = "hvap/engine/m4a1/stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine m4a1 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.Rev",
    level = 115,
    sound = {
		"hvap/engine/m4a1/rev_1.wav",
		"hvap/engine/m4a1/rev_2.wav",
		"hvap/engine/m4a1/rev_3.wav",
		"hvap/engine/m4a1/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine m4a1 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.External.Idle",
    level = 110,
    sound = "hvap/engine/m4a1/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a1 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.External.Low",
    level = 110,
    sound = "hvap/engine/m4a1/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a1 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.External.Medium",
    level = 110,
    sound = "hvap/engine/m4a1/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a1 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.External.High",
    level = 110,
    sound = "hvap/engine/m4a1/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine m4a1 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.Internal.Idle",
    level = 110,
    sound = "hvap/engine/m4a1/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a1 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.Internal.Low",
    level = 110,
    sound = "hvap/engine/m4a1/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a1 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.Internal.Medium",
    level = 110,
    sound = "hvap/engine/m4a1/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a1 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A1.Internal.High",
    level = 110,
    sound = "hvap/engine/m4a1/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- M4A3
-------------------------------------------------------

sound.Add( -- engine m4a3 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.Rev",
    level = 115,
    sound = {
		"hvap/engine/m4a3/rev_1.wav",
		"hvap/engine/m4a3/rev_2.wav",
		"hvap/engine/m4a3/rev_3.wav",
		"hvap/engine/m4a3/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine m4a3 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.External.Idle",
    level = 110,
    sound = "hvap/engine/m4a3/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a3 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.External.Low",
    level = 110,
    sound = "hvap/engine/m4a3/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a3 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.External.Medium",
    level = 110,
    sound = "hvap/engine/m4a3/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a3 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.External.High",
    level = 110,
    sound = "hvap/engine/m4a3/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine m4a3 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.Internal.Idle",
    level = 110,
    sound = "hvap/engine/m4a3/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a3 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.Internal.Low",
    level = 110,
    sound = "hvap/engine/m4a3/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a3 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.Internal.Medium",
    level = 110,
    sound = "hvap/engine/m4a3/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m4a3 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M4A3.Internal.High",
    level = 110,
    sound = "hvap/engine/m4a3/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- M5A
-------------------------------------------------------

sound.Add( -- engine m5a rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.Rev",
    level = 115,
    sound = {
		"hvap/engine/m5a/rev_1.wav",
		"hvap/engine/m5a/rev_2.wav",
		"hvap/engine/m5a/rev_3.wav",
		"hvap/engine/m5a/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine m5a external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.External.Idle",
    level = 110,
    sound = "hvap/engine/m5a/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m5a external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.External.Low",
    level = 110,
    sound = "hvap/engine/m5a/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m5a external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.External.Medium",
    level = 110,
    sound = "hvap/engine/m5a/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m5a external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.External.High",
    level = 110,
    sound = "hvap/engine/m5a/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine m5a internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.Internal.Idle",
    level = 110,
    sound = "hvap/engine/m5a/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m5a internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.Internal.Low",
    level = 110,
    sound = "hvap/engine/m5a/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m5a internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.Internal.Medium",
    level = 110,
    sound = "hvap/engine/m5a/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m5a internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M5A.Internal.High",
    level = 110,
    sound = "hvap/engine/m5a/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- M16
-------------------------------------------------------

sound.Add( -- engine m16 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.Rev",
    level = 115,
    sound = {
		"hvap/engine/m16/rev_1.wav",
		"hvap/engine/m16/rev_2.wav",
		"hvap/engine/m16/rev_3.wav",
		"hvap/engine/m16/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine m16 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.External.Idle",
    level = 110,
    sound = "hvap/engine/m16/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m16 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.External.Low",
    level = 110,
    sound = "hvap/engine/m16/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m16 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.External.Medium",
    level = 110,
    sound = "hvap/engine/m16/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m16 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.External.High",
    level = 110,
    sound = "hvap/engine/m16/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine m16 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.Internal.Idle",
    level = 110,
    sound = "hvap/engine/m16/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m16 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.Internal.Low",
    level = 110,
    sound = "hvap/engine/m16/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m16 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.Internal.Medium",
    level = 110,
    sound = "hvap/engine/m16/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m16 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M16.Internal.High",
    level = 110,
    sound = "hvap/engine/m16/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- M18
-------------------------------------------------------

sound.Add( -- engine m18 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.Start",
    level = 80,
    sound = "hvap/engine/m18/start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine m18 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.Stop",
    level = 80,
    sound = "hvap/engine/m18/stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine m18 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.Rev",
    level = 115,
    sound = {
		"hvap/engine/m18/rev_1.wav",
		"hvap/engine/m18/rev_2.wav",
		"hvap/engine/m18/rev_3.wav",
		"hvap/engine/m18/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine m18 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.External.Idle",
    level = 110,
    sound = "hvap/engine/m18/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m18 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.External.Low",
    level = 110,
    sound = "hvap/engine/m18/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m18 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.External.Medium",
    level = 110,
    sound = "hvap/engine/m18/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m18 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.External.High",
    level = 110,
    sound = "hvap/engine/m18/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine m18 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.Internal.Idle",
    level = 110,
    sound = "hvap/engine/m18/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m18 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.Internal.Low",
    level = 110,
    sound = "hvap/engine/m18/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m18 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.Internal.Medium",
    level = 110,
    sound = "hvap/engine/m18/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m18 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M18.Internal.High",
    level = 110,
    sound = "hvap/engine/m18/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- M24
-------------------------------------------------------

sound.Add( -- engine m24 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.Rev",
    level = 115,
    sound = {
		"hvap/engine/m24/rev_1.wav",
		"hvap/engine/m24/rev_2.wav",
		"hvap/engine/m24/rev_3.wav",
		"hvap/engine/m24/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine m24 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.External.Idle",
    level = 110,
    sound = "hvap/engine/m24/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m24 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.External.Low",
    level = 110,
    sound = "hvap/engine/m24/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m24 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.External.Medium",
    level = 110,
    sound = "hvap/engine/m24/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m24 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.External.High",
    level = 110,
    sound = "hvap/engine/m24/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine m24 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.Internal.Idle",
    level = 110,
    sound = "hvap/engine/m24/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m24 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.Internal.Low",
    level = 110,
    sound = "hvap/engine/m24/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m24 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.Internal.Medium",
    level = 110,
    sound = "hvap/engine/m24/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine m24 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.M24.Internal.High",
    level = 110,
    sound = "hvap/engine/m24/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Maus
-------------------------------------------------------

sound.Add( -- engine maus rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.Rev",
    level = 115,
    sound = {
		"hvap/engine/maus/rev_1.wav",
		"hvap/engine/maus/rev_2.wav",
		"hvap/engine/maus/rev_3.wav",
		"hvap/engine/maus/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine maus external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.External.Idle",
    level = 110,
    sound = "hvap/engine/maus/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine maus external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.External.Low",
    level = 110,
    sound = "hvap/engine/maus/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine maus external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.External.Medium",
    level = 110,
    sound = "hvap/engine/maus/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine maus external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.External.High",
    level = 110,
    sound = "hvap/engine/maus/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine maus internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.Internal.Idle",
    level = 110,
    sound = "hvap/engine/maus/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine maus internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.Internal.Low",
    level = 110,
    sound = "hvap/engine/maus/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine maus internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.Internal.Medium",
    level = 110,
    sound = "hvap/engine/maus/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine maus internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Maus.Internal.High",
    level = 110,
    sound = "hvap/engine/maus/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- PT76
-------------------------------------------------------

sound.Add( -- engine pt76 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.PT76.Rev",
    level = 115,
    sound = {
		"hvap/engine/pt76/rev_1.wav",
		"hvap/engine/pt76/rev_2.wav",
		"hvap/engine/pt76/rev_3.wav",
		"hvap/engine/pt76/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine pt76 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.PT76.External.Idle",
    level = 110,
    sound = "hvap/engine/pt76/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pt76 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.PT76.External.Low",
    level = 110,
    sound = "hvap/engine/pt76/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pt76 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.PT76.External.Medium",
    level = 110,
    sound = "hvap/engine/pt76/external/3.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine pt76 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.PT76.Internal.Idle",
    level = 110,
    sound = "hvap/engine/pt76/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pt76 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.PT76.Internal.Low",
    level = 110,
    sound = "hvap/engine/pt76/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pt76 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.PT76.Internal.Medium",
    level = 110,
    sound = "hvap/engine/pt76/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Pz3
-------------------------------------------------------

sound.Add( -- engine pz3 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.Start",
    level = 80,
    sound = "hvap/engine/pz3/start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine pz3 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.Stop",
    level = 80,
    sound = "hvap/engine/pz3/stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine pz3 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.Rev",
    level = 115,
    sound = {
		"hvap/engine/pz3/rev_1.wav",
		"hvap/engine/pz3/rev_2.wav",
		"hvap/engine/pz3/rev_3.wav",
		"hvap/engine/pz3/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine pz3 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.External.Idle",
    level = 110,
    sound = "hvap/engine/pz3/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz3 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.External.Low",
    level = 110,
    sound = "hvap/engine/pz3/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz3 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.External.Medium",
    level = 110,
    sound = "hvap/engine/pz3/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz3 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.External.High",
    level = 110,
    sound = "hvap/engine/pz3/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine pz3 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.Internal.Idle",
    level = 110,
    sound = "hvap/engine/pz3/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz3 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.Internal.Low",
    level = 110,
    sound = "hvap/engine/pz3/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz3 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.Internal.Medium",
    level = 110,
    sound = "hvap/engine/pz3/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz3 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz3.Internal.High",
    level = 110,
    sound = "hvap/engine/pz3/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Pz4
-------------------------------------------------------

sound.Add( -- engine pz4 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.Rev",
    level = 115,
    sound = {
		"hvap/engine/pz4/rev_1.wav",
		"hvap/engine/pz4/rev_2.wav",
		"hvap/engine/pz4/rev_3.wav",
		"hvap/engine/pz4/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine pz4 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.External.Idle",
    level = 110,
    sound = "hvap/engine/pz4/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz4 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.External.Low",
    level = 110,
    sound = "hvap/engine/pz4/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz4 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.External.Medium",
    level = 110,
    sound = "hvap/engine/pz4/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz4 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.External.High",
    level = 110,
    sound = "hvap/engine/pz4/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine pz4 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.Internal.Idle",
    level = 110,
    sound = "hvap/engine/pz4/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz4 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.Internal.Low",
    level = 110,
    sound = "hvap/engine/pz4/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz4 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.Internal.Medium",
    level = 110,
    sound = "hvap/engine/pz4/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz4 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz4.Internal.High",
    level = 110,
    sound = "hvap/engine/pz4/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Pz5
-------------------------------------------------------

sound.Add( -- engine pz5 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.Start",
    level = 80,
    sound = "hvap/engine/pz5/start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine pz5 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.Stop",
    level = 80,
    sound = "hvap/engine/pz5/stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine pz5 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.Rev",
    level = 115,
    sound = {
		"hvap/engine/pz5/rev_1.wav",
		"hvap/engine/pz5/rev_2.wav",
		"hvap/engine/pz5/rev_3.wav",
		"hvap/engine/pz5/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine pz5 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.External.Idle",
    level = 110,
    sound = "hvap/engine/pz5/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz5 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.External.Low",
    level = 110,
    sound = "hvap/engine/pz5/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz5 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.External.Medium",
    level = 110,
    sound = "hvap/engine/pz5/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz5 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.External.High",
    level = 110,
    sound = "hvap/engine/pz5/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine pz5 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.Internal.Idle",
    level = 110,
    sound = "hvap/engine/pz5/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz5 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.Internal.Low",
    level = 110,
    sound = "hvap/engine/pz5/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz5 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.Internal.Medium",
    level = 110,
    sound = "hvap/engine/pz5/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz5 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz5.Internal.High",
    level = 110,
    sound = "hvap/engine/pz5/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Pz6
-------------------------------------------------------

sound.Add( -- engine pz6 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.Start",
    level = 80,
    sound = "hvap/engine/pz6/start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine pz6 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.Stop",
    level = 80,
    sound = "hvap/engine/pz6/stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine pz6 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.Rev",
    level = 115,
    sound = {
		"hvap/engine/pz6/rev_1.wav",
		"hvap/engine/pz6/rev_2.wav",
		"hvap/engine/pz6/rev_3.wav",
		"hvap/engine/pz6/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine pz6 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.External.Idle",
    level = 110,
    sound = "hvap/engine/pz6/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz6 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.External.Low",
    level = 110,
    sound = "hvap/engine/pz6/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz6 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.External.Medium",
    level = 110,
    sound = "hvap/engine/pz6/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz6 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.External.High",
    level = 110,
    sound = "hvap/engine/pz6/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine pz6 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.Internal.Idle",
    level = 110,
    sound = "hvap/engine/pz6/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz6 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.Internal.Low",
    level = 110,
    sound = "hvap/engine/pz6/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz6 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.Internal.Medium",
    level = 110,
    sound = "hvap/engine/pz6/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine pz6 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Pz6.Internal.High",
    level = 110,
    sound = "hvap/engine/pz6/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Sla16
-------------------------------------------------------

sound.Add( -- engine sla16 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.Rev",
    level = 115,
    sound = {
		"hvap/engine/sla16/rev_1.wav",
		"hvap/engine/sla16/rev_2.wav",
		"hvap/engine/sla16/rev_3.wav",
		"hvap/engine/sla16/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine sla16 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.External.Idle",
    level = 110,
    sound = "hvap/engine/sla16/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine sla16 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.External.Low",
    level = 110,
    sound = "hvap/engine/sla16/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine sla16 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.External.Medium",
    level = 110,
    sound = "hvap/engine/sla16/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine sla16 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.External.High",
    level = 110,
    sound = "hvap/engine/sla16/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine sla16 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.Internal.Idle",
    level = 110,
    sound = "hvap/engine/sla16/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine sla16 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.Internal.Low",
    level = 110,
    sound = "hvap/engine/sla16/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine sla16 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.Internal.Medium",
    level = 110,
    sound = "hvap/engine/sla16/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine sla16 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Sla16.Internal.High",
    level = 110,
    sound = "hvap/engine/sla16/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Stug40
-------------------------------------------------------

sound.Add( -- engine stug40 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.Rev",
    level = 115,
    sound = {
		"hvap/engine/stug40/rev_1.wav",
		"hvap/engine/stug40/rev_2.wav",
		"hvap/engine/stug40/rev_3.wav",
		"hvap/engine/stug40/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine stug40 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.External.Idle",
    level = 110,
    sound = "hvap/engine/stug40/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine stug40 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.External.Low",
    level = 110,
    sound = "hvap/engine/stug40/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine stug40 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.External.Medium",
    level = 110,
    sound = "hvap/engine/stug40/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine stug40 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.External.High",
    level = 110,
    sound = "hvap/engine/stug40/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine stug40 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.Internal.Idle",
    level = 110,
    sound = "hvap/engine/stug40/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine stug40 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.Internal.Low",
    level = 110,
    sound = "hvap/engine/stug40/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine stug40 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.Internal.Medium",
    level = 110,
    sound = "hvap/engine/stug40/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine stug40 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stug40.Internal.High",
    level = 110,
    sound = "hvap/engine/stug40/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- SU100
-------------------------------------------------------

sound.Add( -- engine su100 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.Start",
    level = 80,
    sound = "hvap/engine/su100/start.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine su100 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.Stop",
    level = 80,
    sound = "hvap/engine/su100/stop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- engine su100 rev
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.Rev",
    level = 115,
    sound = {
		"hvap/engine/su100/rev_1.wav",
		"hvap/engine/su100/rev_2.wav",
		"hvap/engine/su100/rev_3.wav",
		"hvap/engine/su100/rev_4.wav"
	},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- engine su100 external idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.External.Idle",
    level = 110,
    sound = "hvap/engine/su100/external/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine su100 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.External.Low",
    level = 110,
    sound = "hvap/engine/su100/external/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine su100 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.External.Medium",
    level = 110,
    sound = "hvap/engine/su100/external/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine su100 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.External.High",
    level = 110,
    sound = "hvap/engine/su100/external/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine su100 internal idle
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.Internal.Idle",
    level = 110,
    sound = "hvap/engine/su100/internal/1.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine su100 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.Internal.Low",
    level = 110,
    sound = "hvap/engine/su100/internal/2.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine su100 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.Internal.Medium",
    level = 110,
    sound = "hvap/engine/su100/internal/3.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine su100 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.SU100.Internal.High",
    level = 110,
    sound = "hvap/engine/su100/internal/4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Tracks
-------------------------------------------------------

sound.Add( -- vehicle tracks light fast
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Light.Fast",
    level = 88,
    sound = 	{
		"hvap/engine/shared/tracks/light/fast_1.wav",
		"hvap/engine/shared/tracks/light/fast_2.wav",
		"hvap/engine/shared/tracks/light/fast_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle tracks light medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Light.Medium",
    level = 84,
    sound = 	{
		"hvap/engine/shared/tracks/light/medium_1.wav",
		"hvap/engine/shared/tracks/light/medium_2.wav",
		"hvap/engine/shared/tracks/light/medium_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle tracks light slow
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Light.Slow",
    level = 80,
    sound = 	{
		"hvap/engine/shared/tracks/light/slow_1.wav",
		"hvap/engine/shared/tracks/light/slow_2.wav",
		"hvap/engine/shared/tracks/light/slow_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- vehicle tracks medium fast
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Medium.Fast",
    level = 88,
    sound = 	{
		"hvap/engine/shared/tracks/medium/fast_1.wav",
		"hvap/engine/shared/tracks/medium/fast_2.wav",
		"hvap/engine/shared/tracks/medium/fast_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle tracks medium medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Medium.Medium",
    level = 84,
    sound = 	{
		"hvap/engine/shared/tracks/medium/medium_1.wav",
		"hvap/engine/shared/tracks/medium/medium_2.wav",
		"hvap/engine/shared/tracks/medium/medium_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle tracks medium slow
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Medium.Slow",
    level = 80,
    sound = 	{
		"hvap/engine/shared/tracks/medium/slow_1.wav",
		"hvap/engine/shared/tracks/medium/slow_2.wav",
		"hvap/engine/shared/tracks/medium/slow_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- vehicle tracks heavy fast
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Heavy.Fast",
    level = 88,
    sound = 	{
		"hvap/engine/shared/tracks/heavy/fast_1.wav",
		"hvap/engine/shared/tracks/heavy/fast_2.wav",
		"hvap/engine/shared/tracks/heavy/fast_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle tracks heavy medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Heavy.Medium",
    level = 84,
    sound = 	{
		"hvap/engine/shared/tracks/heavy/medium_1.wav",
		"hvap/engine/shared/tracks/heavy/medium_2.wav",
		"hvap/engine/shared/tracks/heavy/medium_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle tracks heavy slow
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.Heavy.Slow",
    level = 80,
    sound = 	{
		"hvap/engine/shared/tracks/heavy/slow_1.wav",
		"hvap/engine/shared/tracks/heavy/slow_2.wav",
		"hvap/engine/shared/tracks/heavy/slow_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- vehicle tracks superheavy medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.SuperHeavy.Medium",
    level = 88,
    sound = 	{
		"hvap/engine/shared/tracks/superheavy/medium_1.wav",
		"hvap/engine/shared/tracks/superheavy/medium_2.wav",
		"hvap/engine/shared/tracks/superheavy/medium_3.wav"
		},
    volume = 1.0,
	pitch = 100
})

sound.Add( -- vehicle tracks superheavy slow
{
    channel = CHAN_STATIC,
    name = "HVAP.Vehicle.Tracks.SuperHeavy.Slow",
    level = 84,
    sound = 	{
		"hvap/engine/shared/tracks/superheavy/slow_1.wav",
		"hvap/engine/shared/tracks/superheavy/slow_2.wav",
		"hvap/engine/shared/tracks/superheavy/slow_3.wav"
		},
    volume = 1.0,
	pitch = 100
})
