---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################----###################################################----###################################################-- Engine Audio
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################-- Helicopter 1
-------------------------------------------------------

sound.Add( -- engine hc_1 cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_1.Cockpit",
    level = 75,
    sound = "hvap/engine/hc_1/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_1 engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_1.Engine.Near",
    level = 105,
    sound = "hvap/engine/hc_1/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_1 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_1.Engine.Far",
    level = 120,
    sound = "hvap/engine/hc_1/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_1 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_1.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_1/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_1 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_1.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_1/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_1 turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_1.Turbine",
    level = 120,--far
    sound = "hvap/engine/hc_1/turbine.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_1 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_1.Start",
    level = 90,
    sound = "hvap/engine/shared/heli_start_1.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 2
-------------------------------------------------------

sound.Add( -- engine hc_2 cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_2.Cockpit",
    level = 75,
    sound = "hvap/engine/hc_2/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_2 engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_2.Engine.Near",
    level = 105,
    sound = "hvap/engine/hc_2/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_2 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_2.Engine.Far",
    level = 120,
    sound = "hvap/engine/hc_2/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_2 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_2.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_2/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_2 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_2.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_2/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_2 turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_2.Turbine",
    level = 120,--far
    sound = "hvap/engine/hc_2/turbine.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_2 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_2.Start",
    level = 90,
    sound = "hvap/engine/shared/heli_start_2.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 3
-------------------------------------------------------

sound.Add( -- engine hc_3 cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_3.Cockpit",
    level = 75,
    sound = "hvap/engine/hc_3/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_3 engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_3.Engine.Near",
    level = 105,
    sound = "hvap/engine/hc_3/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_3 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_3.Engine.Far",
    level = 120,
    sound = "hvap/engine/hc_3/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_3 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_3.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_3/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_3 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_3.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_3/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_3 turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_3.Turbine",
    level = 120,--far
    sound = "hvap/engine/hc_3/turbine.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_3 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_3.Start",
    level = 90,
    sound = "hvap/engine/shared/heli_start_3.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 4
-------------------------------------------------------

sound.Add( -- engine hc_4 cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_4.Cockpit",
    level = 75,
    sound = "hvap/engine/hc_4/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_4 engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_4.Engine.Near",
    level = 105,
    sound = "hvap/engine/hc_4/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_4 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_4.Engine.Far",
    level = 120,
    sound = "hvap/engine/hc_4/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_4 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_4.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_4/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_4 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_4.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_4/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_4 turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_4.Turbine",
    level = 120,--far
    sound = "hvap/engine/hc_4/turbine.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_4 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_4.Start",
    level = 90,
    sound = "hvap/engine/shared/heli_start_4.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 5
-------------------------------------------------------

sound.Add( -- engine hc_5 engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_5.Engine.Near",
    level = 105,
    sound = "hvap/engine/hc_5/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_5 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_5.Engine.Far",
    level = 120,
    sound = "hvap/engine/hc_5/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_5 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_5.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_5/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_5 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_5.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_5/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_5 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_5.Start",
    level = 90,
    sound = "hvap/engine/shared/heli_start_5.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 6
-------------------------------------------------------

sound.Add( -- engine hc_6 engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_6.Engine.Near",
    level = 105,
    sound = "hvap/engine/hc_6/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_6 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_6.Engine.Far",
    level = 120,
    sound = "hvap/engine/hc_6/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_6 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_6.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_6/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_6 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_6.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_6/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_6 turbine
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_6.Turbine",
    level = 120,--far
    sound = "hvap/engine/hc_6/turbine.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 7
-------------------------------------------------------

sound.Add( -- engine hc_7 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_7.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_7/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_7 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_7.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_7/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 8
-------------------------------------------------------

sound.Add( -- engine hc_8 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_8.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_8/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_8 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_8.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_8/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 9
-------------------------------------------------------

sound.Add( -- engine hc_9 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_9.Rotor.Near",
    level = 100,
    sound = "hvap/engine/hc_9/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_9 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_9.Rotor.Far",
    level = 110,
    sound = "hvap/engine/hc_9/rotor_far.wav",
    volume = 0.5,
	pitch = 100
})

sound.Add( -- engine hc_9 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_9.Engine.Far",
    level = 90,--far
    sound = "hvap/engine/hc_3/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Helicopter 10
-------------------------------------------------------

sound.Add( -- engine hc_10 cockpit
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_10.Cockpit",
    level = 75,
    sound = "hvap/engine/hc_10/cockpit.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_10 engine near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_10.Engine.Near",
    level = 105,
    sound = "hvap/engine/hc_10/engine_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_10 engine far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_10.Engine.Far",
    level = 120,
    sound = "hvap/engine/hc_10/engine_far.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_10 rotor near
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_10.Rotor.Near",
    level = 116,
    sound = "hvap/engine/hc_10/rotor_close.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine hc_10 rotor far
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.HC_10.Rotor.Far",
    level = 120,--far
    sound = "hvap/engine/hc_10/rotor_far.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Shared
-------------------------------------------------------

sound.Add( -- engine rotorwash
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rotorwash",
    level = 90,
    sound = "hvap/engine/shared/rotorwash.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine stall
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Stall",
    level = 90,
    sound = {
		"hvap/engine/shared/stall_1.wav",
		"hvap/engine/shared/stall_2.wav",
		"hvap/engine/shared/stall_3.wav"
	},
    volume = 1.0,
	pitch = 100
})


--------------------------------------------------------------------------------------------------------------
--##########################################################################################################--
--##################################################PLANE###################################################--
--##########################################################################################################--
--------------------------------------------------------------------------------------------------------------

-------------------------------------------------------
--###################################################-- A6M2
-------------------------------------------------------

sound.Add( -- engine a6m2 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.Start",
    level = 90,
    sound = "hvap/engine/a6m2/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m2 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.Stop",
    level = 90,
    sound = "hvap/engine/a6m2/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine a6m2 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.External.Low",
    level = 135,
    sound = "hvap/engine/a6m2/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m2 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.External.Medium",
    level = 135,
    sound = "hvap/engine/a6m2/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m2 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.External.High",
    level = 135,
    sound = "hvap/engine/a6m2/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine a6m2 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.Internal.Low",
    level = 135,
    sound = "hvap/engine/a6m2/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m2 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.Internal.Medium",
    level = 135,
    sound = "hvap/engine/a6m2/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m2 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M2.Internal.High",
    level = 135,
    sound = "hvap/engine/a6m2/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- A6M3
-------------------------------------------------------

sound.Add( -- engine a6m3 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.Start",
    level = 90,
    sound = "hvap/engine/a6m3/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m3 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.Stop",
    level = 90,
    sound = "hvap/engine/a6m3/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine a6m3 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.External.Low",
    level = 135,
    sound = "hvap/engine/a6m3/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m3 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.External.Medium",
    level = 135,
    sound = "hvap/engine/a6m3/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m3 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.External.High",
    level = 135,
    sound = "hvap/engine/a6m3/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine a6m3 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.Internal.Low",
    level = 135,
    sound = "hvap/engine/a6m3/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m3 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.Internal.Medium",
    level = 135,
    sound = "hvap/engine/a6m3/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine a6m3 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.A6M3.Internal.High",
    level = 135,
    sound = "hvap/engine/a6m3/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- B17
-------------------------------------------------------

sound.Add( -- engine b17 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.Start",
    level = 90,
    sound = "hvap/engine/b17/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b17 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.Stop",
    level = 90,
    sound = "hvap/engine/b17/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine b17 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.External.Low",
    level = 135,
    sound = "hvap/engine/b17/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b17 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.External.Medium",
    level = 135,
    sound = "hvap/engine/b17/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b17 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.External.High",
    level = 135,
    sound = "hvap/engine/b17/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine b17 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.Internal.Low",
    level = 135,
    sound = "hvap/engine/b17/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b17 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.Internal.Medium",
    level = 135,
    sound = "hvap/engine/b17/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b17 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B17.Internal.High",
    level = 135,
    sound = "hvap/engine/b17/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- B25
-------------------------------------------------------

sound.Add( -- engine b25 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.Start",
    level = 90,
    sound = "hvap/engine/b25/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b25 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.Stop",
    level = 90,
    sound = "hvap/engine/b25/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine b25 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.External.Low",
    level = 135,
    sound = "hvap/engine/b25/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b25 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.External.Medium",
    level = 135,
    sound = "hvap/engine/b25/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b25 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.External.High",
    level = 135,
    sound = "hvap/engine/b25/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine b25 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.Internal.Low",
    level = 135,
    sound = "hvap/engine/b25/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b25 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.Internal.Medium",
    level = 135,
    sound = "hvap/engine/b25/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine b25 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.B25.Internal.High",
    level = 135,
    sound = "hvap/engine/b25/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Bf109
-------------------------------------------------------

sound.Add( -- engine bf109 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.Start",
    level = 90,
    sound = "hvap/engine/bf109/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine bf109 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.Stop",
    level = 90,
    sound = "hvap/engine/bf109/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine bf109 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.External.Low",
    level = 135,
    sound = "hvap/engine/bf109/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine bf109 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.External.Medium",
    level = 135,
    sound = "hvap/engine/bf109/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine bf109 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.External.High",
    level = 135,
    sound = "hvap/engine/bf109/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine bf109 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.Internal.Low",
    level = 135,
    sound = "hvap/engine/bf109/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine bf109 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.Internal.Medium",
    level = 135,
    sound = "hvap/engine/bf109/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine bf109 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Bf109.Internal.High",
    level = 135,
    sound = "hvap/engine/bf109/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Fw190
-------------------------------------------------------

sound.Add( -- engine fw190 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.Start",
    level = 90,
    sound = "hvap/engine/fw190/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine fw190 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.Stop",
    level = 90,
    sound = "hvap/engine/fw190/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine fw190 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.External.Low",
    level = 135,
    sound = "hvap/engine/fw190/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine fw190 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.External.Medium",
    level = 135,
    sound = "hvap/engine/fw190/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine fw190 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.External.High",
    level = 135,
    sound = "hvap/engine/fw190/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine fw190 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.Internal.Low",
    level = 135,
    sound = "hvap/engine/fw190/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine fw190 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.Internal.Medium",
    level = 135,
    sound = "hvap/engine/fw190/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine fw190 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Fw190.Internal.High",
    level = 135,
    sound = "hvap/engine/fw190/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Generic1
-------------------------------------------------------

sound.Add( -- engine generic1 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.Start",
    level = 90,
    sound = "hvap/engine/generic1/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic1 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.Stop",
    level = 90,
    sound = "hvap/engine/generic1/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine generic1 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.External.Low",
    level = 135,
    sound = "hvap/engine/generic1/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic1 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.External.Medium",
    level = 135,
    sound = "hvap/engine/generic1/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic1 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.External.High",
    level = 135,
    sound = "hvap/engine/generic1/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine generic1 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.Internal.Low",
    level = 135,
    sound = "hvap/engine/generic1/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic1 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.Internal.Medium",
    level = 135,
    sound = "hvap/engine/generic1/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic1 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic1.Internal.High",
    level = 135,
    sound = "hvap/engine/generic1/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Generic2
-------------------------------------------------------

sound.Add( -- engine generic2 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.Start",
    level = 90,
    sound = "hvap/engine/generic2/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic2 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.Stop",
    level = 90,
    sound = "hvap/engine/generic2/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine generic2 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.External.Low",
    level = 135,
    sound = "hvap/engine/generic2/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic2 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.External.Medium",
    level = 135,
    sound = "hvap/engine/generic2/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic2 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.External.High",
    level = 135,
    sound = "hvap/engine/generic2/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine generic2 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.Internal.Low",
    level = 135,
    sound = "hvap/engine/generic2/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic2 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.Internal.Medium",
    level = 135,
    sound = "hvap/engine/generic2/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine generic2 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Generic2.Internal.High",
    level = 135,
    sound = "hvap/engine/generic2/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Griffeon
-------------------------------------------------------

sound.Add( -- engine griffeon start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.Start",
    level = 90,
    sound = "hvap/engine/griffeon/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine griffeon stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.Stop",
    level = 90,
    sound = "hvap/engine/griffeon/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine griffeon external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.External.Low",
    level = 135,
    sound = "hvap/engine/griffeon/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine griffeon external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.External.Medium",
    level = 135,
    sound = "hvap/engine/griffeon/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine griffeon external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.External.High",
    level = 135,
    sound = "hvap/engine/griffeon/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine griffeon internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.Internal.Low",
    level = 135,
    sound = "hvap/engine/griffeon/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine griffeon internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.Internal.Medium",
    level = 135,
    sound = "hvap/engine/griffeon/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine griffeon internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Griffeon.Internal.High",
    level = 135,
    sound = "hvap/engine/griffeon/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- He111
-------------------------------------------------------

sound.Add( -- engine he111 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.Start",
    level = 90,
    sound = "hvap/engine/he111/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine he111 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.Stop",
    level = 90,
    sound = "hvap/engine/he111/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine he111 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.External.Low",
    level = 135,
    sound = "hvap/engine/he111/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine he111 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.External.Medium",
    level = 135,
    sound = "hvap/engine/he111/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine he111 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.External.High",
    level = 135,
    sound = "hvap/engine/he111/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine he111 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.Internal.Low",
    level = 135,
    sound = "hvap/engine/he111/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine he111 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.Internal.Medium",
    level = 135,
    sound = "hvap/engine/he111/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine he111 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.He111.Internal.High",
    level = 135,
    sound = "hvap/engine/he111/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Jet1
-------------------------------------------------------

sound.Add( -- engine jet1 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.Start",
    level = 90,
    sound = "hvap/engine/jet1/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine jet1 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.Stop",
    level = 90,
    sound = "hvap/engine/jet1/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine jet1 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.External.Low",
    level = 135,
    sound = "hvap/engine/jet1/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine jet1 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.External.Medium",
    level = 135,
    sound = "hvap/engine/jet1/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine jet1 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.External.High",
    level = 135,
    sound = "hvap/engine/jet1/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine jet1 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.Internal.Low",
    level = 135,
    sound = "hvap/engine/jet1/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine jet1 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.Internal.Medium",
    level = 135,
    sound = "hvap/engine/jet1/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine jet1 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Jet1.Internal.High",
    level = 135,
    sound = "hvap/engine/jet1/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Ju87
-------------------------------------------------------

sound.Add( -- engine ju87 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.Start",
    level = 90,
    sound = "hvap/engine/ju87/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ju87 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.Stop",
    level = 90,
    sound = "hvap/engine/ju87/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine ju87 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.External.Low",
    level = 135,
    sound = "hvap/engine/ju87/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ju87 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.External.Medium",
    level = 135,
    sound = "hvap/engine/ju87/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ju87 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.External.High",
    level = 135,
    sound = "hvap/engine/ju87/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine ju87 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.Internal.Low",
    level = 135,
    sound = "hvap/engine/ju87/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ju87 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.Internal.Medium",
    level = 135,
    sound = "hvap/engine/ju87/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine ju87 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Ju87.Internal.High",
    level = 135,
    sound = "hvap/engine/ju87/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Lancaster
-------------------------------------------------------

sound.Add( -- engine lancaster start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.Start",
    level = 90,
    sound = "hvap/engine/lancaster/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine lancaster stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.Stop",
    level = 90,
    sound = "hvap/engine/lancaster/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine lancaster external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.External.Low",
    level = 135,
    sound = "hvap/engine/lancaster/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine lancaster external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.External.Medium",
    level = 135,
    sound = "hvap/engine/lancaster/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine lancaster external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.External.High",
    level = 135,
    sound = "hvap/engine/lancaster/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine lancaster internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.Internal.Low",
    level = 135,
    sound = "hvap/engine/lancaster/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine lancaster internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.Internal.Medium",
    level = 135,
    sound = "hvap/engine/lancaster/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine lancaster internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Lancaster.Internal.High",
    level = 135,
    sound = "hvap/engine/lancaster/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Me410
-------------------------------------------------------

sound.Add( -- engine me410 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.Start",
    level = 90,
    sound = "hvap/engine/me410/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine me410 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.Stop",
    level = 90,
    sound = "hvap/engine/me410/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine me410 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.External.Low",
    level = 135,
    sound = "hvap/engine/me410/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine me410 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.External.Medium",
    level = 135,
    sound = "hvap/engine/me410/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine me410 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.External.High",
    level = 135,
    sound = "hvap/engine/me410/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine me410 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.Internal.Low",
    level = 135,
    sound = "hvap/engine/me410/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine me410 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.Internal.Medium",
    level = 135,
    sound = "hvap/engine/me410/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine me410 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Me410.Internal.High",
    level = 135,
    sound = "hvap/engine/me410/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- P47
-------------------------------------------------------

sound.Add( -- engine p47 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.Start",
    level = 90,
    sound = "hvap/engine/p47/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p47 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.Stop",
    level = 90,
    sound = "hvap/engine/p47/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine p47 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.External.Low",
    level = 135,
    sound = "hvap/engine/p47/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p47 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.External.Medium",
    level = 135,
    sound = "hvap/engine/p47/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p47 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.External.High",
    level = 135,
    sound = "hvap/engine/p47/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine p47 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.Internal.Low",
    level = 135,
    sound = "hvap/engine/p47/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p47 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.Internal.Medium",
    level = 135,
    sound = "hvap/engine/p47/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p47 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P47.Internal.High",
    level = 135,
    sound = "hvap/engine/p47/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- P51
-------------------------------------------------------

sound.Add( -- engine p51 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.Start",
    level = 90,
    sound = "hvap/engine/p51/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p51 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.Stop",
    level = 90,
    sound = "hvap/engine/p51/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine p51 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.External.Low",
    level = 135,
    sound = "hvap/engine/p51/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p51 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.External.Medium",
    level = 135,
    sound = "hvap/engine/p51/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p51 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.External.High",
    level = 135,
    sound = "hvap/engine/p51/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine p51 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.Internal.Low",
    level = 135,
    sound = "hvap/engine/p51/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p51 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.Internal.Medium",
    level = 135,
    sound = "hvap/engine/p51/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine p51 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.P51.Internal.High",
    level = 135,
    sound = "hvap/engine/p51/internal/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------
--###################################################-- Rocket1
-------------------------------------------------------

sound.Add( -- engine rocket1 start
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.Start",
    level = 90,
    sound = "hvap/engine/rocket1/start.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine rocket1 stop
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.Stop",
    level = 90,
    sound = "hvap/engine/rocket1/stop.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine rocket1 external low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.External.Low",
    level = 135,
    sound = "hvap/engine/rocket1/external/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine rocket1 external medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.External.Medium",
    level = 135,
    sound = "hvap/engine/rocket1/external/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine rocket1 external high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.External.High",
    level = 135,
    sound = "hvap/engine/rocket1/external/high.wav",
    volume = 1.0,
	pitch = 100
})

-------------------------------------------------------

sound.Add( -- engine rocket1 internal low
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.Internal.Low",
    level = 135,
    sound = "hvap/engine/rocket1/internal/low.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine rocket1 internal medium
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.Internal.Medium",
    level = 135,
    sound = "hvap/engine/rocket1/internal/medium.wav",
    volume = 1.0,
	pitch = 100
})

sound.Add( -- engine rocket1 internal high
{
    channel = CHAN_STATIC,
    name = "HVAP.Engine.Rocket1.Internal.High",
    level = 135,
    sound = "hvap/engine/rocket1/internal/high.wav",
    volume = 1.0,
	pitch = 100
})


