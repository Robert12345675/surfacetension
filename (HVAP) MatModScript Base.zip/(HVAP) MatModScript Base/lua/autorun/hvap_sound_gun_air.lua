---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################----###################################################----###################################################-- Aircraft Gun Audio
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
--###################################################-- Aircraft Guns
-------------------------------------------------------

sound.Add( -- gun 2a38 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.2A38.End",
    level = 150,
    sound = "hvap/gun/mg/2a38/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun 2a38 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.2A38.Loop",
    level = 150,
    sound = "hvap/gun/mg/2a38/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun 2a42 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.2A42.End",
    level = 150,
    sound = "hvap/gun/mg/2a42/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun 2a42 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.2A42.Loop",
    level = 150,
    sound = "hvap/gun/mg/2a42/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun 77breda end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.77Breda.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/77breda/end_1.wav",
		"hvap/gun/mg/77breda/end_2.wav",
		"hvap/gun/mg/77breda/end_3.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun 77breda loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.77Breda.Loop",
    level = 150,
    sound = "hvap/gun/mg/77breda/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun 127breda end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.127Breda.End",
    level = 150,
    sound = "hvap/gun/mg/127breda/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun 127breda loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.127Breda.Loop",
    level = 150,
    sound = "hvap/gun/mg/127breda/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun bk37 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BK37.Fire",
    level = 150,
    sound = "hvap/gun/mg/bk37/fire.wav",
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- gun bk75 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BK75.Fire",
    level = 150,
    sound = "hvap/gun/mg/bk75/fire.wav",
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- gun brezenub end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BrezenUB.End",
    level = 150,
    sound = "hvap/gun/mg/brezenub/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun brezenub loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.BrezenUB.Loop",
    level = 150,
    sound = "hvap/gun/mg/brezenub/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun gsh23 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GSh23.End",
    level = 150,
    sound = "hvap/gun/mg/gsh23/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun gsh23 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GSh23.Loop",
    level = 150,
    sound = "hvap/gun/mg/gsh23/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun gsh301 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GSh301.End",
    level = 150,
    sound = "hvap/gun/mg/gsh301/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun gsh301 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GSh301.Loop",
    level = 150,
    sound = "hvap/gun/mg/gsh301/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun gshG end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GShG.End",
    level = 150,
    sound = "hvap/gun/mg/gshg/gshg_end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun gshG loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GShG.Loop",
    level = 150,
    sound = "hvap/gun/mg/gshg/gshg.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun ho103 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Ho103.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/ho103/end_1.wav",
		"hvap/gun/mg/ho103/end_2.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})


sound.Add( -- gun ho103 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Ho103.Loop",
    level = 150,
    sound = 	{
		"hvap/gun/mg/ho103/loop_1.wav",
		"hvap/gun/mg/ho103/loop_2.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun ho301 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Ho301.End",
    level = 150,
    sound = "hvap/gun/mg/ho301/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun ho301 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Ho301.Loop",
    level = 150,
    sound = "hvap/gun/mg/ho301/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun hs404 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Hs404.End",
    level = 150,
    sound = "hvap/gun/mg/hs404/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun hs404 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Hs404.Loop",
    level = 150,
    sound = "hvap/gun/mg/hs404/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun hsmk2 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.HsMk2.End",
    level = 150,
    sound = "hvap/gun/mg/hsmk2/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun hsmk2 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.HsMk2.Loop",
    level = 150,
    sound = "hvap/gun/mg/hsmk2/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun hsmk5 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.HsMk5.End",
    level = 150,
    sound = "hvap/gun/mg/hsmk5/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun hsmk5 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.HsMk5.Loop",
    level = 150,
    sound = "hvap/gun/mg/hsmk5/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m2 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M2.End",
    level = 150,
    sound = "hvap/gun/mg/m2/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m2 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M2.Loop",
    level = 150,
    sound = "hvap/gun/mg/m2/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m2hb end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M2HB.End",
    level = 150,
    sound = "hvap/gun/mg/m2hb/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m2hb loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M2HB.Loop",
    level = 150,
    sound = "hvap/gun/mg/m2hb/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m3 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M3.End",
    level = 150,
    sound = "hvap/gun/mg/m3/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m3 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M3.Loop",
    level = 150,
    sound = "hvap/gun/mg/m3/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m4 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M4.Fire",
    level = 150,
    sound = "hvap/gun/mg/m4/fire.wav",
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- gun m57 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M57.Fire",
    level = 150,
    sound = 	{
		"hvap/gun/mg/m57/fire_1.wav",
		"hvap/gun/mg/m57/fire_2.wav",
		"hvap/gun/mg/m57/fire_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- gun m60 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M60.End",
    level = 150,
    sound = "hvap/gun/mg/m60/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m60 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M60.Loop",
    level = 150,
    sound = "hvap/gun/mg/m60/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m61 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M61.End",
    level = 150,
    sound = "hvap/gun/mg/m61/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m61 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M61.Loop",
    level = 150,
    sound = "hvap/gun/mg/m61/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m230 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M230.End",
    level = 150,
    sound = "hvap/gun/mg/m230/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m230 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M230.Loop",
    level = 150,
    sound = "hvap/gun/mg/m230/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m249 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M249.End",
    level = 150,
    sound = "hvap/gun/mg/m249/M249_end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m249 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M249.Loop",
    level = 150,
    sound = "hvap/gun/mg/m249/M249.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m1918 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M1918.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/m1918/1_end.wav",
		"hvap/gun/mg/m1918/2_end.wav",
		"hvap/gun/mg/m1918/3_end.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun m1918 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M1918.Loop",
    level = 150,
    sound = "hvap/gun/mg/m1918/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun m1919 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M1919.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/m1919/1_end.wav",
		"hvap/gun/mg/m1919/2_end.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})


sound.Add( -- gun m1919 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M1919.Loop",
    level = 150,
    sound = 	{
		"hvap/gun/mg/m1919/1_loop.wav",
		"hvap/gun/mg/m1919/2_loop.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun maxim end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Maxim.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/maxim/end_1.wav",
		"hvap/gun/mg/maxim/end_2.wav",
		"hvap/gun/mg/maxim/end_3.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun maxim loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Maxim.Loop",
    level = 150,
    sound = "hvap/gun/mg/maxim/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mg15 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG15.End",
    level = 150,
    sound = "hvap/gun/mg/mg15/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mg15 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG15.Loop",
    level = 150,
    sound = "hvap/gun/mg/mg15/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mg17 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG17.End",
    level = 150,
    sound = "hvap/gun/mg/mg17/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mg17 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG17.Loop",
    level = 150,
    sound = "hvap/gun/mg/mg17/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mg81 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG81.End",
    level = 150,
    sound = "hvap/gun/mg/mg81/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mg81 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG81.Loop",
    level = 150,
    sound = "hvap/gun/mg/mg81/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mg131 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG131.End",
    level = 150,
    sound = "hvap/gun/mg/mg131/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mg131 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG131.Loop",
    level = 150,
    sound = "hvap/gun/mg/mg131/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mg151 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG151.End",
    level = 150,
    sound = "hvap/gun/mg/mg151/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mg151 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MG151.Loop",
    level = 150,
    sound = "hvap/gun/mg/mg151/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mgff end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MGFF.End",
    level = 150,
    sound = "hvap/gun/mg/mgff/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mgff loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MGFF.Loop",
    level = 150,
    sound = "hvap/gun/mg/mgff/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mk103 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/mk103/1_end.wav",
		"hvap/gun/mg/mk103/2_end.wav",
		"hvap/gun/mg/mk103/3_end.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mk103 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK103.Loop",
    level = 150,
    sound = "hvap/gun/mg/mk103/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun mk108 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK108.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/mk108/1_end.wav",
		"hvap/gun/mg/mk108/2_end.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun mk108 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.MK108.Loop",
    level = 150,
   sound = 	{
		"hvap/gun/mg/mk108/1_loop.wav",
		"hvap/gun/mg/mk108/2_loop.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun ns37 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.NS37.Fire",
    level = 150,
    sound = "hvap/gun/mg/ns37/fire.wav",
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- gun ns45 fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.NS45.Fire",
    level = 150,
    sound = 	{
		"hvap/gun/mg/ns45/fire_1.wav",
		"hvap/gun/mg/ns45/fire_2.wav",
		"hvap/gun/mg/ns45/fire_3.wav"
		},
    volume = 1.0,
	pitch = { 95, 105 },
})

-------------------------------------------------------

sound.Add( -- gun shkas end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ShKAS.End",
    level = 150,
    sound = "hvap/gun/mg/shkas/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun shkas loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ShKAS.Loop",
    level = 150,
    sound = "hvap/gun/mg/shkas/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun shvak end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ShVAK.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/shvak/end_1.wav",
		"hvap/gun/mg/shvak/end_2.wav",
		"hvap/gun/mg/shvak/end_3.wav",
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun shvak loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.ShVAK.Loop",
    level = 150,
    sound = "hvap/gun/mg/shvak/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun t160 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.T160.End",
    level = 150,
    sound = "hvap/gun/mg/t160/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun t160 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.T160.Loop",
    level = 150,
    sound = "hvap/gun/mg/t160/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun type97 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Type97.End",
    level = 150,
    sound = "hvap/gun/mg/type97/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun type97 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Type97.Loop",
    level = 150,
    sound = "hvap/gun/mg/type97/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun type99 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Type99.End",
    level = 150,
    sound = "hvap/gun/mg/type99/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun type99 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.Type99.Loop",
    level = 150,
    sound = "hvap/gun/mg/type99/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun vickersk end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.VickersK.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/vickersk/end_1.wav",
		"hvap/gun/mg/vickersk/end_2.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})


sound.Add( -- gun vickersk loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.VickersK.Loop",
    level = 150,
    sound = 	{
		"hvap/gun/mg/vickersk/loop_1.wav",
		"hvap/gun/mg/vickersk/loop_2.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun vickerss fire
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.VickersS.Fire",
    level = 150,
    sound = "hvap/gun/mg/vickerss/fire_1.wav",
    volume = 1.0,
	pitch = { 95, 105 }
})

-------------------------------------------------------

sound.Add( -- gun vya23 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.VYa23.End",
    level = 150,
    sound = 	{
		"hvap/gun/mg/vya23/1_end.wav",
		"hvap/gun/mg/vya23/2_end.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})


sound.Add( -- gun vya23 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.VYa23.Loop",
    level = 150,
    sound = 	{
		"hvap/gun/mg/vya23/1_loop.wav",
		"hvap/gun/mg/vya23/2_loop.wav"
		},
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------

sound.Add( -- gun yakb end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.YakB.End",
    level = 150,
    sound = "hvap/gun/mg/yakb/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})


sound.Add( -- gun yakb loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.YakB.Loop",
    level = 150,
    sound = "hvap/gun/mg/yakb/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- GAU-8
-------------------------------------------------------

sound.Add( -- gun gau8 loop
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GAU8.Loop",
    level = 160,
    sound = "hvap/gun/gat/gau8/loop.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

sound.Add( -- gun gau8 end
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.GAU8.End",
    level = 160,
    sound = "hvap/gun/gat/gau8/end.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

-------------------------------------------------------
--###################################################-- M134
-------------------------------------------------------

sound.Add( -- gun m134 end close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M134.End.Close",
    level = 140,
    sound = "hvap/gun/gat/m134/end_near.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})


sound.Add( -- gun m134 loop close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M134.Loop.Close",
    level = 140,
    sound = "hvap/gun/gat/M134/loop_near.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})


sound.Add( -- gun m134 start close
{
    channel = CHAN_WEAPON,
    name = "HVAP.Gun.M134.Start.Close",
    level = 140,
    sound = "hvap/gun/gat/m134/start_near.wav",
    volume = 1.0,
	pitch = { 98, 102 },
})

