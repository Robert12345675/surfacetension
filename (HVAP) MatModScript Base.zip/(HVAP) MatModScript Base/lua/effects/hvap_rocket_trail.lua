
AddCSLuaFile()

function EFFECT:Init(data)

	self.Ent = data:GetEntity()
	self.Fwd = data:GetNormal()
	self.Pos = data:GetOrigin()
	self.Scl = data:GetScale()
	self.Smoke = tobool(LocalPlayer():GetInfo("hvap_cl_air_gsmokeeffect"))
	self.Siz = 7 --math.Clamp(data:GetRadius(),0 , 8)

	if !self.Ent:IsValid() then return end
	
	self.Col = 180
	
	local flashemitter = ParticleEmitter(self.Ent:GetPos())
		local particle = flashemitter:Add("effects/muzzleflash"..math.random(1,4), self.Pos+(self.Fwd*3))
			particle:SetVelocity((self.Fwd*80))
			particle:SetDieTime(0.1)
			particle:SetStartAlpha(255)
			particle:SetEndAlpha(0)
			particle:SetStartSize(self.Siz*8)
			particle:SetEndSize(self.Siz*2)
			particle:SetRoll(math.Rand(180,480))
			particle:SetRollDelta(math.Rand(-1,1))
			particle:SetColor(255,255,255)	
	
	if self.Smoke then
		local emitter = ParticleEmitter(self.Ent:GetPos())
			emitter:SetNearClip( 32, 128 )
			for i = 1, 10 do 
				local smoke = emitter:Add("particle/smokesprites_000"..math.random(1,9), self.Pos-self.Fwd*100)
					smoke:SetVelocity(100*(1.6)*self.Fwd*i)
					smoke:SetDieTime(math.Rand(1,1.6))
					smoke:SetStartAlpha(math.Rand(30,32)+i*self.Scl)
					smoke:SetEndAlpha(0)
					smoke:SetStartSize(math.random(2,2.56)*i*self.Scl)
					smoke:SetEndSize(math.Rand(10,12)*self.Siz+self.Scl)
					smoke:SetRoll(math.Rand(180,480))
					smoke:SetRollDelta(math.Rand(-1,1))
					smoke:SetColor(self.Col,self.Col,self.Col)
					smoke:SetAirResistance(16/i)
			end
	end

end

function EFFECT:Think()		
	return false
end

function EFFECT:Render()
end