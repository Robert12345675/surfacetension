
AddCSLuaFile()

function EFFECT:Init( data )
	self.Fancy = tobool(LocalPlayer():GetInfo("hvap_cl_air_eheateffect"))
	self.Fancy2 = tobool(LocalPlayer():GetInfo("hvap_cl_air_esmokeeffect"))
	local Ent = data:GetEntity() or self
	if !IsValid(Ent) then return end
	local Pos = data:GetOrigin()
	local Pos2 = data:GetStart()
	local Mag = data:GetMagnitude()
	local Col = math.Clamp(data:GetColor()+25,10,255)
	local Col2 = data:GetRadius()
	local Scale = (1-data:GetScale())
	local Vel = Ent:GetVelocity()	
	local Vell = Vel:Length()/512
	
	local emitter = ParticleEmitter( Pos )
	emitter:SetNearClip( 64, 800 )

	if self.Fancy and Mag > 0.01 then
		local particle = emitter:Add( "particle/smokesprites_000"..math.random(1,9), Pos )
		if (particle) then
			particle:SetVelocity( ( (Ent:GetForward()*Mag) )*(-1200) + Vel + (Ent:GetForward()*Mag*VectorRand()*160) )
			particle:SetLifeTime(0) 
			particle:SetDieTime(Mag+math.random(0.2,0.256)) 
			particle:SetStartAlpha(Mag*math.random(12,16)+Scale+2)
			particle:SetEndAlpha(0)
			particle:SetStartSize(24*Mag+16)
			particle:SetEndSize(math.random(148,168)*Mag+32)
			particle:SetAngles( Angle(0,0,0) )
			particle:SetAngleVelocity( Angle(0,math.random(-2,2),0) ) 
			particle:SetRoll(math.Rand( 0, 360 ))
			particle:SetColor(Col, Col, Col, 255)
			particle:SetAirResistance(16)
			particle:SetCollide(true)
			particle:SetBounce(0.256)
		end
	end
	
	if Mag > 0.5 then
	
	end
---------------------------------------------------------- damgesmoke
	if self.Fancy2 and Scale > 0 and Scale <= 0.95 then 
		local smoke = emitter:Add( "particle/smokesprites_000"..math.random(1,9), Pos2+VectorRand()*math.random(-8,8))
		if (smoke) then
			smoke:SetVelocity((Ent:GetForward()*Scale*5+Ent:GetForward()*0.12)*-160+(Vel/2))
			smoke:SetLifeTime(0) 
			smoke:SetDieTime(2.56+Scale) 
			smoke:SetStartAlpha( math.Clamp(70*Scale+100, 0,255) )
			smoke:SetEndAlpha(0)
			smoke:SetStartSize(32*Scale+70)
			smoke:SetEndSize(42*-Scale+340)
			smoke:SetAngles( Angle(0,0,0) )
			smoke:SetAngleVelocity( Angle(0,math.random(-2,2),0) ) 
			smoke:SetRoll(math.Rand( 0, 360 ))
			smoke:SetColor(Col2, Col2, Col2, 255)
			smoke:SetAirResistance(16)
			smoke:SetCollide(true)
			smoke:SetBounce(0.256)
			smoke:SetStartLength( 8 )
			smoke:SetEndLength( 512 )
		end	
	end

	emitter:Finish()
	
end

function EFFECT:Think()		
	return false
end

function EFFECT:Render()
end