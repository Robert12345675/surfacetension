
AddCSLuaFile()

function EFFECT:Init( data )
	self.Fancy = tobool(LocalPlayer():GetInfo("hvap_cl_air_eheateffect"))
	self.Fancy2 = tobool(LocalPlayer():GetInfo("hvap_cl_air_esmokeeffect"))
	local Ent = data:GetEntity() or self
	if !IsValid(Ent) then return end
	local Pos = data:GetOrigin()
	local Pos2 = data:GetStart()
	local Mag = data:GetMagnitude()
	local Col = math.Clamp(data:GetColor()+25,10,255)
	local Col2 = data:GetRadius()
	local Scale = (1-data:GetScale())
	local Vel = Ent:GetVelocity()	
	local Vell = Vel:Length()/512
	
	local emitter = ParticleEmitter( Pos )
	emitter:SetNearClip( 64, 800 )

	if self.Fancy and Mag > 0.01 then
		local particle = emitter:Add( "particle/smokesprites_000"..math.random(1,9), Pos+(Ent:GetForward()*(Mag*-1280))+(Ent:GetForward()*320) )
		if (particle) then
			particle:SetVelocity( ( (Ent:GetForward()*Mag) )*(-1200) + Vel + (Ent:GetForward()*Mag*VectorRand()*160) )
			particle:SetLifeTime(0) 
			particle:SetDieTime(Mag+math.random(0.2,0.256)) 
			particle:SetStartAlpha(Mag*math.random(4,6)+8)
			particle:SetEndAlpha(0)
			particle:SetStartSize(24*Mag+16)
			particle:SetEndSize(math.random(148,168)*Mag+32)
			particle:SetAngles( Angle(0,0,0) )
			particle:SetAngleVelocity( Angle(0,math.random(-2,2),0) ) 
			particle:SetRoll(math.Rand( 0, 360 ))
			particle:SetColor(Col, Col, Col, 255)
			particle:SetAirResistance(16)
			particle:SetCollide(true)
			particle:SetBounce(0.256)
		end
	end
	
	if Mag > 0.5 then
		local SubMag = ((Mag-0.5)/0.5)^2
		local Flash = emitter:Add( "particles/fire_glow", Pos+(Ent:GetForward()*(SubMag*-64))+(Ent:GetForward()*130) )
		if (Flash) then
			Flash:SetVelocity( (Ent:GetForward()*(SubMag)+Ent:GetForward())*(-160))
			Flash:SetLifeTime(0) 
			Flash:SetDieTime(SubMag/16+0.03) 
			Flash:SetStartAlpha(SubMag*64+20)
			Flash:SetEndAlpha(SubMag)
			Flash:SetStartSize(40*SubMag+16)
			Flash:SetEndSize(8*SubMag+8)
			Flash:SetAngles( Angle(0,0,0) )
			Flash:SetAngleVelocity( Angle(0,math.random(-32,32),0) ) 
			Flash:SetRoll(math.Rand( 0, 360 ))
			Flash:SetColor(255,math.random(210,220),math.random(40,50),255)
			Flash:SetAirResistance(16)
			Flash:SetCollide(true)
			Flash:SetBounce(0.256)
			Flash:SetStartLength( 192 )
			Flash:SetEndLength( 1280-((1-SubMag)*320) )
		end
		
		local Flame = emitter:Add( "particles/fire_glow", Pos+(Ent:GetForward()*(SubMag*-64))+(Ent:GetForward()*170) )
		if (Flame) then
			Flame:SetVelocity( (Ent:GetForward()*(SubMag)+Ent:GetForward())*(-192))
			Flame:SetLifeTime(0) 
			Flame:SetDieTime(SubMag/12+0.03) 
			Flame:SetStartAlpha(SubMag*76+32)
			Flame:SetEndAlpha(SubMag)
			Flame:SetStartSize(128*SubMag+32)
			Flame:SetEndSize(32*SubMag+24)
			Flame:SetAngles( Angle(0,0,0) )
			Flame:SetAngleVelocity( Angle(0,math.random(-32,32),0) ) 
			Flame:SetRoll(math.Rand( 0, 360 ))
			Flame:SetColor(math.random(60,68),math.random(0,8),255,255)
			Flame:SetAirResistance(16)
			Flame:SetCollide(true)
			Flame:SetBounce(0.256)
			Flame:SetStartLength( 160 )
			Flame:SetEndLength( 1024-((1-SubMag)*256) )
		end		
	end
---------------------------------------------------------- damgesmoke
	if self.Fancy2 and Scale > 0 and Scale <= 0.95 then 
		local smoke = emitter:Add( "particle/smokesprites_000"..math.random(1,9), Pos2+VectorRand()*math.random(-8,8)+(Mag*Ent:GetForward()*-300))
		if (smoke) then
			smoke:SetVelocity((Ent:GetForward()*Scale*5+Ent:GetForward()*0.12)*-160+(Vel/2))
			smoke:SetLifeTime(0) 
			smoke:SetDieTime(2.56+Scale) 
			smoke:SetStartAlpha( math.Clamp(70*Scale+100, 0,255) )
			smoke:SetEndAlpha(0)
			smoke:SetStartSize(32*Scale+70)
			smoke:SetEndSize(42*-Scale+340)
			smoke:SetAngles( Angle(0,0,0) )
			smoke:SetAngleVelocity( Angle(0,math.random(-2,2),0) ) 
			smoke:SetRoll(math.Rand( 0, 360 ))
			smoke:SetColor(Col2, Col2, Col2, 255)
			smoke:SetAirResistance(16)
			smoke:SetCollide(true)
			smoke:SetBounce(0.256)
		end	
	end

	emitter:Finish()
	
end

function EFFECT:Think()		
	return false
end

function EFFECT:Render()
end