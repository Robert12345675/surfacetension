
AddCSLuaFile()

function EFFECT:Init(data)

	self.Pos 		= data:GetOrigin()
	self.Scale 		= math.Clamp(data:GetScale(), 8, 32)
	self.Emitter 		= ParticleEmitter( self.Pos )	
	self.Emitter:SetNearClip( 128, 320 )
	local ply = LocalPlayer()
	local dist = self.Pos:Distance(ply:GetPos())
	self.Fancy = tobool(ply:GetInfo("hvap_cl_air_bulleteffect"))
	
	sound.Play("HVAP.Bullet.Explode.Small", self.Pos, 1, 1, 180)	

	for i=0, self.Scale/2 do
		local Smoke = self.Emitter:Add( "particle/smokesprites_000"..math.random(1,9), self.Pos )
		if (Smoke) then
		Smoke:SetVelocity( VectorRand():GetNormalized()*self.Scale*math.Rand(8, 12) )
		Smoke:SetDieTime( math.Rand( 1 , 2.56 ) )
		Smoke:SetStartAlpha( math.Rand( 80, 128 ) )
		Smoke:SetEndAlpha( 0 )
		Smoke:SetStartSize( 32*self.Scale )
		Smoke:SetEndSize( 80*self.Scale )
		Smoke:SetRoll( math.Rand(150, 360) )
		Smoke:SetRollDelta( math.Rand(-2, 2) )			
		Smoke:SetAirResistance( 2 ) 			 
		Smoke:SetGravity( Vector( 0, 0, -2 ) ) 			
		Smoke:SetColor( 100,100,100 )
		end
	end	
	
	if self.Fancy then 
		local Compress = self.Emitter:Add("sprites/heatwave", self.Pos)
		if (Compress) then
		Compress:SetVelocity( VectorRand():GetNormalized()*self.Scale*math.Rand(1, 1.92) )
		Compress:SetDieTime(math.Rand(0.64,1.28))
		Compress:SetStartSize(math.random(64,128)+10*self.Scale)
		Compress:SetEndSize(0)
		Compress:SetRoll(math.Rand(180,480))
		Compress:SetRollDelta(math.Rand(-1,1))
		Compress:SetAirResistance(160)
		end
	end

end

function EFFECT:Think( )
return false
end

function EFFECT:Render()
end
