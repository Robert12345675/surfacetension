
AddCSLuaFile()

function EFFECT:Init( data )
	self.Fancy = tobool(LocalPlayer():GetInfo("hvap_cl_air_eheateffect"))
	self.Fancy2 = tobool(LocalPlayer():GetInfo("hvap_cl_air_esmokeeffect"))
	local Ent = data:GetEntity() or self
	if !IsValid(Ent) then return end
	local Pos = data:GetOrigin()
	local Pos2 = data:GetStart()
	local Mag = data:GetMagnitude()
	local Col = math.Clamp(data:GetColor()+25,10,255)
	local Col2 = data:GetRadius()
	local Scale = (1-data:GetScale())
	local Vel = Ent:GetVelocity()	
	local Vell = Vel:Length()/512
	
	local emitter = ParticleEmitter( Pos )
	emitter:SetNearClip( 64, 800 )

	if self.Fancy and Mag > 0.01 then
		local particle = emitter:Add( "particle/smokesprites_000"..math.random(1,9), Pos+(Ent:GetForward()*(Mag*-1280))+(Ent:GetForward()*320) )
		if (particle) then
			particle:SetVelocity( ( (Ent:GetForward()*Mag) )*(-1200) + Vel + (Ent:GetForward()*Mag*VectorRand()*160) )
			particle:SetLifeTime(0) 
			particle:SetDieTime(Mag+math.random(0.2,0.256)) 
			particle:SetStartAlpha(Mag*math.random(4,6)+8)
			particle:SetEndAlpha(0)
			particle:SetStartSize(24*Mag+16)
			particle:SetEndSize(math.random(148,168)*Mag+32)
			particle:SetAngles( Angle(0,0,0) )
			particle:SetAngleVelocity( Angle(0,math.random(-2,2),0) ) 
			particle:SetRoll(math.Rand( 0, 360 ))
			particle:SetColor(Col, Col, Col, 255)
			particle:SetAirResistance(16)
			particle:SetCollide(true)
			particle:SetBounce(0.256)
		end
	end
	
	if Mag > 0.5 then
		local SubMag = ((Mag-0.5)/0.5)^2
		local Flash = emitter:Add( "particles/fire_glow", Pos+(Ent:GetForward()*(SubMag*10))+(Ent:GetForward()*40) )
		if (Flash) then
			Flash:SetVelocity( (Ent:GetForward()*(SubMag)+Ent:GetForward())*(-128))
			Flash:SetLifeTime(0) 
			Flash:SetDieTime(SubMag/16+0.032) 
			Flash:SetStartAlpha(SubMag*160+32)
			Flash:SetEndAlpha(SubMag)
			Flash:SetStartSize(40*SubMag+32)
			Flash:SetEndSize(8*SubMag+8)
			Flash:SetAngles( Angle(0,0,0) )
			Flash:SetAngleVelocity( Angle(0,math.random(-32,32),0) ) 
			Flash:SetRoll(math.Rand( 0, 360 ))
			Flash:SetColor(math.random(240,255),10,10,255)
			Flash:SetAirResistance(16)
			Flash:SetCollide(false)
			Flash:SetStartLength( 210 )
			Flash:SetEndLength( 512*SubMag )
		end
		
		local Flame = emitter:Add( "particles/fire_glow", Pos+(Ent:GetForward()*(SubMag*16))+(Ent:GetForward()*60) )
		if (Flame) then
			Flame:SetVelocity( (Ent:GetForward()*(SubMag)+Ent:GetForward())*(-128))
			Flame:SetLifeTime(0) 
			Flame:SetDieTime(SubMag/12+0.032) 
			Flame:SetStartAlpha(SubMag*48+64)
			Flame:SetEndAlpha(SubMag)
			Flame:SetStartSize(128*SubMag+50)
			Flame:SetEndSize(32*SubMag+24)
			Flame:SetAngles( Angle(0,0,0) )
			Flame:SetAngleVelocity( Angle(0,math.random(-32,32),0) ) 
			Flame:SetRoll(math.Rand( 0, 360 ))
			Flame:SetColor(math.random(240,255),math.random(200,220),32,255)
			Flame:SetAirResistance(16)
			Flame:SetCollide(false)
			Flame:SetStartLength( 190 )
			Flame:SetEndLength( 400*SubMag )
		end		
	end
---------------------------------------------------------- damgesmoke
	if self.Fancy2 and Scale > 0 and Scale <= 0.95 then 
		local smoke = emitter:Add( "particle/smokesprites_000"..math.random(1,9), Pos2+VectorRand()*math.random(-8,8)+(Mag*Ent:GetForward()*-300))
		if (smoke) then
			smoke:SetVelocity((Ent:GetForward()*Scale*5+Ent:GetForward()*0.12)*-160+(Vel/2))
			smoke:SetLifeTime(0) 
			smoke:SetDieTime(2.56+Scale) 
			smoke:SetStartAlpha( math.Clamp(70*Scale+100, 0,255) )
			smoke:SetEndAlpha(0)
			smoke:SetStartSize(32*Scale+70)
			smoke:SetEndSize(42*-Scale+340)
			smoke:SetAngles( Angle(0,0,0) )
			smoke:SetAngleVelocity( Angle(0,math.random(-2,2),0) ) 
			smoke:SetRoll(math.Rand( 0, 360 ))
			smoke:SetColor(Col2, Col2, Col2, 255)
			smoke:SetAirResistance(16)
			smoke:SetCollide(true)
			smoke:SetBounce(0.256)
		end	
	end

	emitter:Finish()
	
end

function EFFECT:Think()		
	return false
end

function EFFECT:Render()
end