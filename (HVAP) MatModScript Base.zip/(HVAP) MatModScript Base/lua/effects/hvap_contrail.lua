
AddCSLuaFile()

function EFFECT:Init( data )
	self.Fancy = !tobool(LocalPlayer():GetInfo("hvap_cl_air_esmokeeffect"))
	if self.Fancy then return end
	local Ent = data:GetEntity()
	local Pos = data:GetOrigin()
	local Scl = data:GetScale()
	local Col = data:GetColor()
	if !Ent:IsValid() then return end	
	local Vel = Ent:GetVelocity()	
	local Vell = Vel:Length()/512
	
	local emitter = ParticleEmitter( Pos )
	if !emitter then return end
	emitter:SetNearClip( 8, 256 )

	local particle = emitter:Add( "particle/smokesprites_000"..math.random(1,9), Pos+VectorRand()*math.random(-1,1))

	if (particle) then
		particle:SetVelocity(Vel/2-(Ent:GetForward()*16))
		particle:SetLifeTime(0) 
		particle:SetDieTime(1.6) 
		particle:SetStartAlpha( 38 )
		particle:SetEndAlpha(0)
		particle:SetStartSize(16)
		particle:SetEndSize(64)
		particle:SetAngles( Ent:GetAngles() )
		particle:SetAngleVelocity( Angle(0,math.random(-2,2),0) ) 
		particle:SetRoll(math.Rand( 0, 360 ))
		particle:SetColor(Col, Col, Col, 8)
		particle:SetAirResistance(16)
		particle:SetCollide(true)
		particle:SetBounce(0.256)
		particle:SetStartLength( 8 )
		particle:SetEndLength( 512 )
	end
	
end

function EFFECT:Think()		
	return false
end

function EFFECT:Render()

end
