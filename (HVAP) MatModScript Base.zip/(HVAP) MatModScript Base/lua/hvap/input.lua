
include "hvap/base.lua"

hvap.input = hvap.input or {
	
	registerSeat = function(seat)
		seat.hvap = seat.hvap or {}
		--seat.hvap.addInput
	end,

}