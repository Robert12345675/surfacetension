
AddCSLuaFile()

ENT.Base 				= "base_anim"
ENT.Type 				= "anim"

ENT.PrintName			= "HVAP Turret"
ENT.Author				= hvap.author
ENT.Category			= ""
ENT.Contact    			= ""
ENT.Purpose 			= ""
ENT.Instructions 		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable	= false
ENT.Disabled = false
ENT.Pitch = true	
ENT.Yaw = true
ENT.valid = false
ENT.IsHVAP = true
ENT.HVAP_ENTITY = true

ENT.IsHVAPAircraft = true
ENT.IsHVAPGround = false
ENT.AllowAmmo = true
ENT.AllowFuel = true
ENT.AllowRepair = true

if SERVER then

function ENT:Initialize() 
	self.Entity:PhysicsInit( SOLID_VPHYSICS )
	self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
	self.Entity:SetSolid( SOLID_VPHYSICS )	
	self.Phy = self.Entity:GetPhysicsObject()
	self.Phy:SetMass(self.mass)
	self.valid = true
end

function ENT:Think()
	if !self.valid then return end
	return true
end

function ENT:DamageTurret(dmg)

end

function ENT:OnTakeDamage(dmg)
	self.aircraft:TakeDamageInfo(dmg)
end

function ENT:Use(a, b, c, d)
	self.aircraft:Use(a, b, c, d)
end

function ENT:Rearm(amt, b)
	if b then return end
	self.aircraft:Rearm(amt, b)
end

function ENT:Refuel(amt, b)
	if b then return end
	self.aircraft:Refuel(amt, b)
end

function ENT:Repair(amt, b)
	if b then return end
	self.aircraft:Repair(amt, b)
end

function ENT:OnRemove()

end

end

function ENT:UpdateTransmitState() return TRANSMIT_PVS end -- TRANSMIT_ALWAYS
