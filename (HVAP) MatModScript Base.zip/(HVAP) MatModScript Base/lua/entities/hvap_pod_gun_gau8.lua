AddCSLuaFile()

ENT.Base = "hvap_pod_gun_base"
ENT.Type = "point"

ENT.PrintName = "GAU-8"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "GAU-8"
ENT.Ammo = 1000
ENT.FireRate = 4200 --4200

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.CoolDown = 4//ammount taken from heat every sec
ENT.HeatMult = 11//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 2//time it takes for unoverheat
ENT.Caliber = 30
ENT.Spread = 1
ENT.SndPitch = 100

ENT.Punch = 45

ENT.AmmoBelt = {
	{
		"heit",
		"api",
		"hei",
		"api",
		"hei",
		"api",
		"hei",		
		"api",
		"hei",
		"api",
		"hei",
		"api",
		"hei",
		"api",
		"hei",
		"api",
		"hei",		
		"api",
		"hei",
		"api",
		"hei",
		"api",
	}
}

ENT.AmmoData = {
	["api"] = {
		class = "hvap_bullet_api",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=1013,--velocity m/s
			Radius=90,--caliber
			Penetrate= 40,--caliber
			BallisticDrag	= 16,
			Drift=0.64,
			Mass=395,--g
			TissueDamage = math.Rand(140,160),--
			EffectSize = 1,
			Size=30--caliber
		}
	},	
	["hei"] = {
		class = "hvap_bullet_he",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=1020,--velocity m/s
			Radius=256,--caliber
			Penetrate= 18,--caliber
			BallisticDrag	= 16,
			Drift=0.256,
			Mass=378,--g
			TissueDamage = math.Rand(190,200),--
			EffectSize = 1,
			Size=30--caliber
		}
	},
	["heit"] = {
		class = "hvap_bullet_he",
		info = {
			Large=true,
			SelfDestr=true,
			Flak=true,
			Tracer=true,--tracer?
			Timer=0.8,-- time to remove bullet or to explode if SelfDestr
			col=Color(200, 200, 120),
			Speed=1016,--velocity m/s
			Radius=200,--caliber
			Penetrate= 18,--caliber
			BallisticDrag	= 16,
			Drift=0.01,
			Mass=370,--g
			TissueDamage = math.Rand(190,200),--
			EffectSize = 1,
			Size=30--caliber
		}
	},
}


ENT.Sounds = {
	shoot = "HVAP.Gun.GAU8.Loop", -- sound played when firing
	stop = "HVAP.Gun.GAU8.End", -- sound played when stop firing
	blank = "", -- sound played when stop firing but hammed 
	clickstop = "", -- sound plaed when near overheat
	clickshoot = "", -- sound plaed when near overheat stop
	Jam = "", -- sound to play when gun jams
	GunReady = "HVAP.Gun.Jam.Ready"
}
