AddCSLuaFile()

ENT.Base = "hvap_pod_gun_base"
ENT.Type = "point"

ENT.PrintName = "Hispano Mk.V"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "Hispano Mk.V"
ENT.Ammo = 1000
ENT.FireRate = 750
ENT.Force = 9999999999

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.CoolDown = 6//ammount taken from heat every sec
ENT.HeatMult = 20//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 2//time it takes for unoverheat
ENT.Caliber = 20
ENT.Spread = 1
ENT.SndPitch = 100

ENT.Punch = 32

ENT.AmmoBelt = {
	{
		"hefi",
		
		"sapi",

		"ap",
		
		"apt",
	},
	
	{
		"hefi",
		"hefi",
		
		"sapi",		
		"sapi",

		"ap",
		"ap",
		
		"apt",		
		"apt",
	},	
	
	{
		"hefi",
		"hefi",
		"hefi",
		
		"sapi",				
		"sapi",		
		"sapi",

		"ap",
		"ap",
		"ap",
		
		"apt",		
		"apt",		
		"apt",
	},	

	{
		"hefi",
		"hefi",
		"hefi",
		"hefi",
		
		"sapi",		
		"sapi",		
		"sapi",		
		"sapi",

		"ap",
		"ap",
		"ap",
		"ap",
		
		"apt",		
		"apt",		
		"apt",		
		"apt",
	},		
}

ENT.AmmoData = {
	["apt"] = {
		class = "hvap_bullet_ap",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=true,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 0, 0),
			Speed=835,--velocity m/s
			Radius=32,--caliber
			Penetrate= 23,--caliber
			BallisticDrag	= 16,
			Drift=0.768,
			Mass=102,--g
			TissueDamage = math.Rand(80,128),--
			EffectSize = 10,
			Size=20--caliber
		}
	},
	["ap"] = {
		class = "hvap_bullet_ap",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 0, 0),
			Speed=822,--velocity m/s
			Radius=32,--caliber
			Penetrate= 22,--caliber
			BallisticDrag	= 16,
			Drift=0.8,
			Mass=102,--g
			TissueDamage = math.Rand(90,110),--
			EffectSize = 10,
			Size=20--caliber
		}
	},	
	["sapi"] = {
		class = "hvap_bullet_api",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=true,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 255, 255),
			Speed=844,--velocity m/s
			Radius=128,--caliber
			Penetrate= 20,--caliber
			BallisticDrag	= 16,
			Drift=0.8,
			Mass=102,--g
			TissueDamage = math.Rand(34,42),--
			EffectSize = 10,
			Size=20--caliber
		}
	},
	["hefi"] = {
		class = "hvap_bullet_he",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=true,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 10, 10),
			Speed=890,--velocity m/s
			Radius=256,--caliber
			Penetrate= 20,--caliber
			BallisticDrag	= 16,
			Drift=1.5,
			Mass=102,--g
			TissueDamage = math.Rand(80,128),--
			EffectSize = 10,
			Size=20--caliber
		}
	},
}

ENT.Sounds = {
	shoot = "HVAP.Gun.HSMk5.Loop", -- sound played when firing
	stop = "HVAP.Gun.HSMk5.End", -- sound played when stop firing
	blank = "HVAP.Gun.Misc.BlankFire", -- sound played when stop firing but hammed 
	clickstop = "HVAP.Gun.Jam.Click.End", -- sound plaed when near overheat
	clickshoot = "HVAP.Gun.Jam.Click.Loop", -- sound plaed when near overheat stop
	Jam = "HVAP.Gun.Jam.Start", -- sound to play when gun jams
	GunReady = "HVAP.Gun.Jam.Finish"
}
