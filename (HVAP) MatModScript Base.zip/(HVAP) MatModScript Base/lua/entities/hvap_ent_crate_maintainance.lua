AddCSLuaFile()

ENT.Base = "hvap_ent_crate_base"
ENT.Type = "anim"

ENT.PrintName = "Maintainance Package"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.health = 200
ENT.Mass = 150
ENT.Scl = 12
ENT.Model = "models/props_junk/wood_crate002a.mdl"

if SERVER then

function ENT:Function(cdat)
	if( cdat.DeltaTime > 0.5 && cdat.Speed > 32 ) then
		if IsValid( cdat.HitEntity ) and cdat.HitEntity.IsHVAP then
			if cdat.HitEntity.AllowRepair then
				cdat.HitEntity:Repair(1)
				sound.Play( "HVAP.Misc.Repair.Large", self:GetPos() )	
			end		
			if cdat.HitEntity.AllowAmmo then
				cdat.HitEntity:Rearm()
				sound.Play( "HVAP.Reload.Multi", self:GetPos() )				
			end	
			if  cdat.HitEntity.AllowFuel then
				cdat.HitEntity:Refuel(1000)
				sound.Play( "HVAP.Reload.Secondary", self:GetPos() )	
			end	
			self:Remove()				
		end	
	end				
end

end
