AddCSLuaFile()

ENT.Base = "hvap_ent_crate_base"
ENT.Type = "anim"

ENT.PrintName = "Small Parts Crate"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 100
ENT.Mass = 80
ENT.Scl = 10
ENT.Model = "models/items/item_item_crate.mdl"

if SERVER then

function ENT:Function(cdat)
	if IsValid( cdat.HitEntity ) and cdat.HitEntity.IsHVAP and cdat.HitEntity.AllowRepair then
		cdat.HitEntity:Repair(4)
		sound.Play( "HVAP.Misc.Repair.Small", self:GetPos() )	
		self:Remove()	
	end	
end				

end
