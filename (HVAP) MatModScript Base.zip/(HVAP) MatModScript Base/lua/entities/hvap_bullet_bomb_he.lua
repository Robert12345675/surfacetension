
AddCSLuaFile()

ENT.Type 			= "anim"  
ENT.Base 			= "base_anim"     
ENT.PrintName			= "Bomb"  
ENT.Author			= "The_HAVOK"  
ENT.Contact			= "The_HAVOK"  
ENT.Purpose			= ""  
ENT.Instructions		= ""  

ENT.Spawnable			= false

ENT.HVAP_ENTITY = true
ENT.HVAP_BOMB = true

ENT.valid = false

ENT.Sounds = {
	Whistle = "HVAP.Bomb.Whistle"
}

if CLIENT then

function ENT:Draw()            
	self.Entity:DrawModel()
end

elseif SERVER then

function ENT:Initialize()   
	self.Impacted = false
	self:SetModel( self.model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_NONE )
	
	self:addSounds()

	self.Phy=self:GetPhysicsObject()
	self.Phy:SetMass(self.mass)
	self.Phy:EnableDrag( true )
	self.Phy:SetAngleDragCoefficient( self.mass )
	self.Phy:SetDragCoefficient( math.Clamp(self.mass/25,5,15)+10 )
	self.HitWater = false


	self.active = false

	self.Mask = MASK_SHOT+CONTENTS_EMPTY

	self.valid = true
end 

function ENT:ActivateFuse()
	self.active = true
	self.TraceEnd = self:GetPos()
	if self:GetMoveType() != MOVETYPE_VPHYSICS then
		self:SetMoveType( MOVETYPE_VPHYSICS )
	end
	self.Phy:Wake()
	self.Phy:EnableGravity(true)
	self.Phy:SetMass(self.mass)
end

function ENT:Think()
	if !self:IsValid() or !self.valid then return end
	local crt = CurTime()
	if self.active then

		local vel = self:GetVelocity()
		local vell = vel:Length()
		if vell > 0 then
			if !self.sounds.Whistle:IsPlaying() then
				self.sounds.Whistle:Play()
			end
		else
			if self.sounds.Whistle:IsPlaying() then
				self.sounds.Whistle:Stop()
			end	
		end				

	end
	self:NextThink( crt )
	return true
end

function ENT:PhysicsUpdate(ph)

	local vel = ph:GetVelocity()
	local vell = vel:Length()
	local fwd = self:GetForward()
	
	if self.active then
		local tr = util.TraceLine({
			start 	= (self.TraceEnd),
			endpos 	= (self:GetPos() + fwd*128),
			filter 	= self.EntFilter,
			mask 	= self.Mask
		})	
		self.TraceEnd = tr.endpos
		if tr.Hit and !table.HasValue( self.EntFilter, tr.Entity ) and tr.Entity:GetClass() != "hvap_rotor" and tr.Entity:GetClass() != "hvap_rotor_r" and !tr.Entity.HVAP_BOMB then
			self.Mat = math.ceil(tr.MatType)	
			if tr.HitSky then
				self:Remove()
				return true
			end
			if self.Mat==83 and !self.HitWater then
				local effectdata = EffectData()
				effectdata:SetOrigin( tr.HitPos )
				effectdata:SetNormal( tr.HitNormal )
				effectdata:SetScale( self.Size )
				util.Effect( "watersplash", effectdata )
				self.HitWater = true
				self:Impact(tr)
			end
			self:Impact(tr)
		end			
		ph:AddVelocity(fwd*math.random(1,8)+VectorRand()*math.random(-8,8))
		local drop = LerpVector( 0.001, -fwd, Vector(0,0,-1) )*math.random(1,3.2)
		ph:AddAngleVelocity( VectorRand()*math.random(-5,5) + Vector(0,drop.y,(drop.x*(math.random(-1,1))/6) ) )
	end

end

function ENT:Impact(tr)
	local pos = self:GetPos()
	util.BlastDamage( self.AircraftFiring or self, self.Owner or self, pos+Vector(0,0,64), self.Radius*1.6, self.Damage*1.6 )
	
	local effectdata = EffectData()
		effectdata:SetEntity(tr.Entity)
		effectdata:SetMagnitude(10)
		effectdata:SetNormal(tr.HitNormal)
		effectdata:SetOrigin(tr.HitPos)
		effectdata:SetScale(self.mass)
		effectdata:SetStart(self:GetForward())
		effectdata:SetSurfaceProp(tr.MatType or 1)
	util.Effect("hvap_bomb_explode", effectdata )
	util.ScreenShake( pos, self.mass, self.mass/10, 3.5, self.Radius*2 )
	self:Remove()
end

function ENT:OnRemove()
	self:StopAllSounds()
end

function ENT:StopAllSounds()
	for k, s in pairs(self.sounds) do
		if s:IsPlaying() then
			s:Stop()
		end
	end
end

end

function ENT:addSounds()
	self.sounds = {}
	for k, v in pairs(self.Sounds) do
		if k != "BaseClass" then
			self.sounds[k] = CreateSound(self, v)
		end
	end
end

function ENT:UpdateTransmitState() return TRANSMIT_PVS end -- TRANSMIT_ALWAYS
