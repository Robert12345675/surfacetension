AddCSLuaFile()

ENT.Base = "hvap_ent_crate_base"
ENT.Type = "anim"

ENT.PrintName = "Fuel Barrel"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 200
ENT.Mass = 120
ENT.Scl = 14
ENT.Model = "models/props_c17/oildrum001.mdl"

if SERVER then

function ENT:Function(cdat)
	if IsValid( cdat.HitEntity ) and cdat.HitEntity.IsHVAP and cdat.HitEntity.AllowFuel then
		cdat.HitEntity:Refuel(1000)
		sound.Play( "HVAP.Reload.Secondary", self:GetPos() )	
		self:Remove()	
	end	
end				
	
end