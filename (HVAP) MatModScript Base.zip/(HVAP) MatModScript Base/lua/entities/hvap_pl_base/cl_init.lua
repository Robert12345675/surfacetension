
include("shared.lua")

ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:Initialize()

	if self.DisableIR then 
		self.EnableIR = false
	else
		self.EnableIR = tobool(cvars.Number("hvap_viewmode_ir",1))
	end
	self.EnableNV = tobool(cvars.Number("hvap_viewmode_nv",1))
	self.EnableTP = tobool(cvars.Number("hvap_thirdperson_enabled",1))
	self.active = false
	self.Targeted = false
	self.Throttle = 0
	self.rotorRpm = 0
	self.engineRpm = 0
	self.EnginesHealth = 0
	self.FSCL = 0
	self.FuelScl = 0
	self.Zoom = 1
	self.ZoomVal = 0
	
	self.Speed = 0
	
	self.LastThink = CurTime()
	self.Flash = CurTime()
	self:addSounds()
	self.weapons = {}
	self.weapons2 = {}
	self.countermeasure = nil
	self.matstore = {}
	self.colstore = {}

	self.valid = true
end

-----------------------------------------------------------------Get

function ENT:getWeapon(seatId)
	local seat = self.Seats[seatId]
	if !seat then return end
	local active = self:GetNWInt("seat_"..seatId.."_actwep")
	if !seat.weapons or !seat.weapons[active] or !self.weapons then return end
	return self.weapons[seat.weapons[active]]
end

function ENT:getWeapon2(seatId)
	local seat = self.Seats[seatId]
	if !seat then return end
	local active = self:GetNWInt("seat_"..seatId.."_actwep2")
	if !seat.weapons2 or !seat.weapons2[active] or !self.weapons2 then return end
	return self.weapons2[seat.weapons2[active]]
end

function ENT:getPassenger(seat)
	if !IsValid(self:GetSwitcher()) then return end
	local s = self:GetSwitcher().seats[seat]
	if IsValid(s) then
		return s:GetPassenger()
	end
end

-----------------------------------------------------------------Tick

function ENT:receiveInput(name, value, seat)
	if !self.valid then return end
	local player = LocalPlayer()
	local vehicle = player:GetVehicle()
	if name == "FreeView" then
		if value > 0.5 then
			player.hvap.viewFree = true
		else
			player.hvap.viewFree = false
			player.hvap_air_resetview = true
		end
	elseif name == "NextWeapon" and value > 0.5 then
		sound.Play( "HVAP.Switch.Click", self:GetPos() )		
	elseif name == "Zoom" then
		if value > 0.5 then
			self.Zoom = self.Zoom + 1
			if self.Zoom > 3 then 
				self.Zoom = 1
			end
			if vehicle.useCamera then
				sound.Play( "HVAP.Switch.Zoom", self:GetPos() )	
			end
		end
		self.ZoomVal = value
	end
	if self.Seats[seat] and self.Seats[seat].Turret then
		if name == "Camera" then
			if value > 0.5 then
				self.Zoom = 1
				vehicle.useCamera = !vehicle.useCamera
				if vehicle.useCamera then 
					sound.Play( "HVAP.Switch.FLIR.In_1", self:GetPos() )	
				else 
					sound.Play( "HVAP.Switch.FLIR.Out_1", self:GetPos() )	
					vehicle.RenderToggle = false
				end
			end
		elseif name == "RenderMode" and value > 0.5 and !self.DisableIR then
			if vehicle.useCamera then
				vehicle.RenderToggle = !vehicle.RenderToggle
				if vehicle.RenderToggle then 
					sound.Play( "HVAP.Switch.FLIR.In_1", self:GetPos() )	
				else 
					sound.Play( "HVAP.Switch.FLIR.Out_1", self:GetPos() )	
				end				
				sound.Play( "HVAP.Switch.Click", self:GetPos() )	
			end
		end

	end
end

function ENT:Think()	
	if not self.valid then return end
	local crt = CurTime()
	local frt = crt-self.LastThink	

	self.active = self:GetNWBool("on")	
	self.Targeted = self:GetNWBool("Targeted")
	self.Throttle = self.Throttle - (self.Throttle-self:GetNWFloat("up"))*frt*10
	self.rotorRpm = self.rotorRpm - (self.rotorRpm-self:GetNWFloat("rotorRpm"))*frt*10
	self.engineRpm = self.engineRpm - (self.engineRpm-self:GetNWFloat("engineRpm"))*frt/2
	self.EnginesHealth = self.EnginesHealth - (self.EnginesHealth-self:GetNWFloat("ehp"))*frt*10
	self.FSCL = self.FSCL - (self.FSCL-self:GetNWFloat("fhp"))*frt*10
	self.FuelScl = self.FuelScl - (self.FuelScl-self:GetNWFloat("fuel"))*frt*10
	self.Speed = math.Round(self:GetVelocity():Length()*0.06858,1)
	
	local e = LocalPlayer():GetViewEntity()
	if !IsValid(e) then e = LocalPlayer() end
	
	local pos = e:GetPos()
	local spos = self:GetPos()
	local doppler = (pos:Distance(spos+e:GetVelocity())-pos:Distance(spos+self:GetVelocity()))/128
	local vehicle = LocalPlayer():GetVehicle()
	local inVehicle = false
	if IsValid(vehicle) and vehicle:GetNWEntity("hvap_aircraft") == self then
		if !vehicle:GetThirdPersonMode() then
			inVehicle = true
		end
		doppler = 0
	end

	local volume = tonumber(LocalPlayer():GetInfo("hvap_cl_air_volume"))
	local val = math.Clamp(self.rotorRpm*100 + doppler + self:GetVelocity():Length()/50, 0, 200)
	local mod = (doppler+self.Throttle*20+self:GetVelocity():Length()/80)
	local enginevolume = math.Clamp(self.engineRpm*100 + doppler + self:GetVelocity():Length()/50, 0, 200)/100
	local rotorpitch = math.Clamp(self.rotorRpm*100+mod*self.rotorRpm, 0, 200)
	local rotorvolume = math.Clamp(self.rotorRpm*100 + doppler + self:GetVelocity():Length()/50, 0, 200)/100
	local cockpit = math.Clamp(self.Throttle*5+self.engineRpm*70, 0, 120)
	
	local engpitch = math.Clamp(75+self.engineRpm/0.04 + self.Throttle/0.04 + doppler, 0, 200)
	local rpms = self.engineRpm*1000	

	if self.active then
		if !self.sounds.Start:IsPlaying() then
			self.sounds.Start:PlayEx(volume*(inVehicle and 0.5 or 1),100)
		end		
		if self.sounds.Stop:IsPlaying() then
			self.sounds.Stop:Stop()
		end		
	else
		if !self.sounds.Stop:IsPlaying() then
			self.sounds.Stop:PlayEx(volume*(inVehicle and 0.5 or 1),100)
		end		
		if self.sounds.Start:IsPlaying() then
			self.sounds.Start:Stop()
		end			
	end		
	
	if inVehicle then
------------------------------------------------------------------------------low
		if rpms <= 600 and rpms > 100 then
			if !self.sounds.int1:IsPlaying() then
				self.sounds.int1:PlayEx(0,engpitch)
			else
				if rpms > 300 then
					self.sounds.int1:ChangePitch(engpitch, 0.1)
					self.sounds.int1:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.75)*2,0 , 1), 0.1)				
				else
					self.sounds.int1:ChangePitch(engpitch, 0.1)
					self.sounds.int1:ChangeVolume(math.Clamp(math.abs(self.engineRpm)*8,0 , 1), 0.1)
				end
			end
		elseif self.sounds.int1:IsPlaying() then
			self.sounds.int1:Stop()
		end
------------------------------------------------------------------------------medium
		if rpms > 300 and rpms < 990 then
			if !self.sounds.int2:IsPlaying() then
				self.sounds.int2:PlayEx(0,engpitch)
			else
				if rpms > 800 then
					self.sounds.int2:ChangePitch(engpitch, 0.1)
					self.sounds.int2:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.99)*2,0 , 1), 0.1)				
				else
					self.sounds.int2:ChangePitch(engpitch, 0.1)
					self.sounds.int2:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.3)*2,0 , 1), 0.1)
				end
			end
		elseif self.sounds.int2:IsPlaying() then
			self.sounds.int2:Stop()
		end
------------------------------------------------------------------------------high
		if rpms > 710 then
			if !self.sounds.int3:IsPlaying() then
				self.sounds.int3:PlayEx(0,engpitch)
			else
				self.sounds.int3:ChangePitch(engpitch, 0.1)
				self.sounds.int3:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.71)*2,0 , 1), 0.1)
			end
		elseif self.sounds.int3:IsPlaying() then
			self.sounds.int3:Stop()
		end
------------------------------------------------------------------------------end
		self.sounds.ext1:Stop()
		self.sounds.ext2:Stop()
		self.sounds.ext3:Stop()
	else
		if rpms <= 600 and rpms > 0.01 then
			if !self.sounds.ext1:IsPlaying() then
				self.sounds.ext1:PlayEx(0,engpitch)
			else
				if rpms > 300 then
					self.sounds.ext1:ChangePitch(engpitch, 0.1)
					self.sounds.ext1:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.75)*2,0 , 1), 0.1)				
				else
					self.sounds.ext1:ChangePitch(engpitch, 0.1)
					self.sounds.ext1:ChangeVolume(math.Clamp(math.abs(self.engineRpm)*8,0 , 1), 0.1)
				end
			end
		elseif self.sounds.ext1:IsPlaying() then
			self.sounds.ext1:Stop()
		end
------------------------------------------------------------------------------medium
		if rpms > 300 and rpms < 990 then
			if !self.sounds.ext2:IsPlaying() then
				self.sounds.ext2:PlayEx(0,engpitch)
			else
				if rpms > 800 then
					self.sounds.ext2:ChangePitch(engpitch, 0.1)
					self.sounds.ext2:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.99)*2,0 , 1), 0.1)				
				else
					self.sounds.ext2:ChangePitch(engpitch, 0.1)
					self.sounds.ext2:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.3)*2,0 , 1), 0.1)
				end
			end
		elseif self.sounds.ext2:IsPlaying() then
			self.sounds.ext2:Stop()
		end
------------------------------------------------------------------------------high
		if rpms > 710 then
			if !self.sounds.ext3:IsPlaying() then
				self.sounds.ext3:PlayEx(0,engpitch)
			else
				self.sounds.ext3:ChangePitch(engpitch, 0.1)
				self.sounds.ext3:ChangeVolume(math.Clamp(math.abs(self.engineRpm-0.71)*2,0 , 1), 0.1)
			end
		elseif self.sounds.ext3:IsPlaying() then
			self.sounds.ext3:Stop()
		end
------------------------------------------------------------------------------end		
		self.sounds.int1:Stop()
		self.sounds.int2:Stop()
		self.sounds.int3:Stop()	
	end
--------------------------end enginecontroller

	
	if self.skin ~= self:GetSkin() then
		self.skin = self:GetSkin()
		self:updateSkin(self.skin)
	end	
	self.LastThink=CurTime()	
end

-----------------------------------------------------------------ViewCalc

function ENT:CreateViewCalc(seat, p, pos, ang, fov)
	if !self.valid or !IsValid(p) or p:GetViewEntity() != p then return end
	local vehicle = p:GetVehicle()
	local view = {origin = pos, angles = ang, fov = fov}
	local k = math.Clamp(seat,1,9)

	if (vehicle and vehicle:GetNWEntity("hvap_aircraft") != self) or !IsValid(vehicle) then
		return self:DrawExitViewCalc(k, p, view)
	end	
	
	hvap.smoothApproachAngles(p.hvap.lagAngles, self:GetAngles(), 20)
	local shakeEnabled = p:GetInfo("hvap_cl_air_shakeview") == "1"
	if shakeEnabled then
		hvap.smoothApproachVector(p.hvap.lagPos, self:GetPos(), 20)
		hvap.smoothApproachVector(p.hvap.lagSpeed, p.hvap.lagPos-self:GetPos(), 20)
		hvap.smoothApproachVector(p.hvap.lagAccel, p.hvap.lagSpeed, 20)
		hvap.smoothApproachVector(p.hvap.lagAccelDelta, p.hvap.lagAccel, 20)
	end	

	if self.Turrets and self.Seats[k].Turret then
		if self.Turrets[self.Seats[k].Turret] then
			local info = self.Turrets[self.Seats[k].Turret].info
			view.angles = self:WorldToLocalAngles(view.angles)

			view.angles = self:LocalToWorldAngles( Angle(
								((view.angles.p <= info.minAng.p and info.minAng.p) or (view.angles.p >= info.maxAng.p and info.maxAng.p) or view.angles.p),
								((view.angles.y <= info.minAng.y and info.minAng.y) or (view.angles.y >= info.maxAng.y and info.maxAng.y) or view.angles.y),
								0
							))
			view.angles:RotateAroundAxis(self:GetUp(), self.Seats[k].ang.y)
		end
	end		
	
	if vehicle:GetThirdPersonMode() then
		view = self:DrawThirdPersonViewCalc(k, p, view)
	else
		if vehicle.useCamera then
			view = self:DrawCameraViewCalc(k, p, view)
		else
			view = self:DrawFirstPersonViewCalc(k, p, view)
		end
	end
	
	if self.viewTarget then
		self.viewPos = self.viewPos or table.Copy(self.viewTarget)
		hvap.smoothApproachVector(self.viewPos.origin, self.viewTarget.origin, 30)
		hvap.smoothApproachAngles(self.viewPos.angles, self.viewTarget.angles, 30)
		view.origin = view.origin + self.viewPos.origin
		if p:GetInfo("hvap_cl_air_smoothview") == "1" then
			view.angles = self:GetAngles()*2 + self.viewPos.angles - p.hvap.lagAngles
			if shakeEnabled then
				view.origin = view.origin + (p.hvap.lagAccel - p.hvap.lagAccelDelta)/7
			end
		else
			view.angles = self:LocalToWorldAngles(self.viewPos.angles)
		end
		self.viewTarget = nil
	end

	if IsValid(p) and view and self.Seats[k].Turret then
		net.Start("hvap.aircraft.updateCamera")
			net.WriteEntity(self)
			net.WriteInt( k, 5 )
			net.WriteTable( view )
		net.SendToServer()
	end
	return view
end

function ENT:DrawFirstPersonViewCalc(k, p, view)
	p.hvap = p.hvap or {}


	view.origin = view.origin+Vector(0,0,1.15)

	if self.ZoomVal > 0.5 then
		view.fov = 90-(self.ZoomVal*35)
	else
		view.fov = 90
	end

	if k == 1 and p:GetInfo("hvap_cl_air_mouse") == "1" and !p.hvap.viewFree then
		self.viewTarget = {
			origin = Vector(),
			angles = Angle(),
			fov = view.fov
		}
	else
		self.viewTarget = {
			origin = Vector(),
			angles = p:GetAimVector():Angle() - self:GetAngles(),
			fov = view.fov
		}
		self.viewTarget.angles.r = self.viewTarget.angles.r + self:GetAngles().r
	end	
	self:RefreshRender()
	return view
end

function ENT:DrawThirdPersonViewCalc(k, p, view)
	local ang;
	local vehicle = p:GetVehicle()
	if k == 1 and p:GetInfo("hvap_cl_air_mouse") == "1" and !p.hvap.viewFree
	then
		ang = self:GetAngles()
	else
		ang = p:GetAimVector():Angle()
		ang.r = view.angles.r
	end
	ang:RotateAroundAxis(ang:Right(), -self.thirdPerson.angle)
	local origin = self:LocalToWorld(self.thirdPerson.position)

	local tr = util.QuickTrace(
			origin,
			ang:Forward()*-self.thirdPerson.distance,
			{self.Entity}
	) 
	self.viewTarget = {
		origin = (tr.HitPos - tr.Normal*10) - view.origin,
		angles = ang - self:GetAngles()-Angle(10,0,0)
	}

	self:RefreshRender()

	return view
end

function ENT:DrawCameraViewCalc(k, p, view)
	if self.Turrets and self.Seats[k].Turret then
		if self.Turrets[self.Seats[k].Turret] then
			local info = self.Turrets[self.Seats[k].Turret].info
			view.origin = self:LocalToWorld(info.viewPos)+view.angles:Forward()*info.viewOffset.x
			
			view.fov = 100-(self.Zoom*30)
			return view
		end
	end
end

function ENT:DrawExitViewCalc(k, p, view)
	p.hvap.air.vehicle = nil
	self:RefreshRender()
end

-----------------------------------------------------------------END

function ENT:onViewSwitch(p, thirdPerson)
	self.viewPos = nil
	self.ZoomVal = 0
	self:RefreshRender()
end

function ENT:onEnter(p)
	p.hvap.lagAngles =  self:GetAngles()
	p.hvap.lagPos = self:GetPos()
	p.hvap.lagSpeed = Vector(0, 0, 0)
	p.hvap.lagAccel = Vector(0, 0, 0)
	p.hvap.lagAccelDelta = Vector(0, 0, 0)
	p.hvap.air.vehicle = self
end

function ENT:MovePlayerView(k,p,md)
	if !self.Seats or !self.Seats[k] then return end
	local viewAngs = md:GetViewAngles()	
	local frt = FrameTime()

	if p.hvap_air_resetview then
		md:SetViewAngles(Angle(0,90,0))
		p.hvap_air_resetview = false 
	end

	if k==1 and p:GetInfo("hvap_cl_air_mouse")=="1" then
		if p.hvap.viewFree then

		else
			viewAngs.p = viewAngs.p-viewAngs.p*frt*5.5
			viewAngs.y = viewAngs.y-(viewAngs.y-90)*frt*5.5
		end
	end
	md:SetViewAngles(viewAngs)
end

-----------------------------------------------------------------Draw

local HudMat = Material("WeltEnSTurm/helihud/arrow")
local HudCol = Color(70,199,50,180)
local Black = Color(0,0,0,200)

function ENT:Draw()
	self:DrawModel()
	if !self.Seats then return end
	p = LocalPlayer()

	for k, t in pairs(self.Seats) do
		if k != "BaseClass" and IsValid(self:getPassenger(k)) and !self.Seats[k].nohud and self:LocalToWorld(self.Seats[k].pos):Distance(p:GetPos()) < 128 then
			self:DrawWeaponSelection(k, t)
			if k == 1 then
				self:DrawPilotHud()
			end			
		end
	end	
	
end

function ENT:DrawPilotHud()
	local pos = self:GetPos()
	local fwd = self:GetForward()
	local ri = self:GetRight()
	local ang = self:GetAngles()
	ang:RotateAroundAxis(ri, 90)
	ang:RotateAroundAxis(fwd, 90)
	local crt = CurTime()
	local pulse = math.abs(math.sin(CurTime() * 10))
		
	cam.Start3D2D(self:LocalToWorld(Vector(20,3.75,37.75)+self.Seats[1].pos), ang, 0.015)
	cam.IgnoreZ( true )
	surface.SetDrawColor(HudCol)

	local rects = {
		{235, 249, 10, 2},
		{255, 249, 10, 2},
		{249, 235, 2, 10},
		{249, 255, 2, 10},
		{-3, 0, 3, 500},
		{500, 0, 3, 500},
		{7, 0, 3, 500},
		{490, 0, 3, 500},
		{-6,-3,19,3},
		{-6,500,19,3},
		{487,-3,19,3},
		{487,500,19,3},
		{9,248,5,3},
		{485,248,5,3},
		{1, 500-self.rotorRpm*500, 5, self.rotorRpm*500},		
		{494, 500-self.engineRpm*500, 5, self.engineRpm*500},
	}

	for _, e in pairs(rects) do
		surface.DrawRect(e[1], e[2], e[3], e[4])
	end
	
	surface.DrawLine(30, 5*ang.r-200+2.77*ang.p, 220, 5*ang.r-200+2.77*(ang.p*0.12))
	surface.DrawLine(30, 5*ang.r-200+2.77*ang.p+1, 220, 5*ang.r-200+2.77*(ang.p*0.12)+1)
	surface.DrawLine(280, 5*ang.r-200-2.77*(ang.p*0.12), 470, 5*ang.r-200-2.77*ang.p)
	surface.DrawLine(280, 5*ang.r-200-2.77*(ang.p*0.12)+1, 470, 5*ang.r-200-2.77*ang.p+1)
	surface.SetMaterial(HudMat)
	surface.DrawTexturedRect(-20,500-self.Throttle*500-10,20,20)
	surface.DrawTexturedRectRotated(512,math.Clamp(250-self:GetVelocity().z/5.249*2,0,500),20,20,180)
	surface.SetTextColor(HudCol)
	surface.SetFont("hvap_heli_small")
	
	if self.Targeted then
		surface.SetTextColor(Color(70,199,50,180*pulse))
	else
		surface.SetTextColor(Color(20,149,0,50))		
	end
	surface.SetTextPos(-10, 505)
	surface.DrawText("MSL")	
	surface.SetTextColor(HudCol)

	if self.EnginesHealth <= .25 then
		surface.SetTextColor(Color(70,199,50,180*pulse))	
	else
		surface.SetTextColor(Color(20,149,0,50))	
	end
	surface.SetTextPos(-10, 525)
	surface.DrawText("FIRE")		
	surface.SetTextColor(HudCol)	

--[[
--	if !self:GetHover() then
		surface.SetTextColor(Color(20,149,0,50))
--	end
	surface.SetTextPos(-10, 545)
	surface.DrawText("HVR")	
	surface.SetTextColor(HudCol)	
]]		
---------------------------------------------	
	
	local tr=util.QuickTrace(pos,Vector(0,0,-999999),self.Entity)
	surface.SetTextPos(485,505)
	surface.DrawText("ALT")
	surface.SetTextPos(525,505)
	surface.DrawText(math.floor((pos.z-tr.HitPos.z)/52.49343832021).."m")
	
	surface.SetTextPos(483, 525) 
	surface.DrawText("SPD")
	surface.SetTextPos(525, 525) 
	surface.DrawText((self.Speed*3.2 ).."km/h")

	if self.FuelScl <= .20 then
		surface.SetTextColor(Color(70,199,50,180*pulse))		
	end
	surface.SetTextPos(483, 545)
	surface.DrawText("FUL")
	surface.SetTextColor(HudCol)	
	surface.SetTextPos(525, 545)
	surface.DrawText((math.Round(self.FuelScl*100,0)) .."%")	

	if self.EnginesHealth <= .5 then
		surface.SetTextColor(Color(70,199,50,180*pulse))		
	end	
	surface.SetTextPos(483, 565)
	surface.DrawText("ENG")		
	surface.SetTextColor(HudCol)	
	surface.SetTextPos(525, 565)
	surface.DrawText((math.Round(self.EnginesHealth*100,0)) .."%")	

	if self.FSCL <= .5 then
		surface.SetTextColor(Color(70,199,50,180*pulse))		
	end		
	surface.SetTextPos(483, 585)
	surface.DrawText("HUL")		
	surface.SetTextColor(HudCol)	
	surface.SetTextPos(525, 585)
	surface.DrawText((math.Round(self.FSCL*100,0)) .."%")		

	if self.active and self.engineRpm <= .5 then
		surface.SetTextColor(Color(70,199,50,180*pulse))		
	end			
	surface.SetTextPos(481,-26)
	surface.DrawText("ENG")--rpm meter
	surface.SetTextColor(HudCol)	

	if self.active and self.rotorRpm <= .5 then
		surface.SetTextColor(Color(70,199,50,180*pulse))		
	end			
	surface.SetTextPos(-11,-26)
	surface.DrawText("ROT")--rpm meter
	
	cam.IgnoreZ( false )
	
	cam.End3D2D()
end

function ENT:DrawWeaponSelection(k, t)
	local fwd = self:GetForward()
	local ri = self:GetRight()
	local ang = self:GetAngles()
	ang:RotateAroundAxis(ri, 90)
	ang:RotateAroundAxis(fwd, 90)
	if (self:getWeapon(k) or self:getWeapon2(k)) then
		cam.Start3D2D(self:LocalToWorld(Vector(20,5,25) + t.pos), ang, 0.02)
		cam.IgnoreZ( true )
		surface.SetDrawColor(HudCol)
		surface.SetTextColor(HudCol)
		surface.DrawRect(-10, -25, 500, 30)
		surface.DrawRect(-10, 5, 10, 20)
		
		local weapon = self:getWeapon(k)
		local indicator = weapon:GetSecondary()
		local ammo = weapon:GetAmmo()

		draw.SimpleText(k.." "..t.weapons[self:GetNWInt("seat_"..k.."_actwep")], "hvap_heli_big", 0, -25, Black, 0)
		draw.SimpleText(ammo, "hvap_heli_big", 480, -25, Black, 2)
		surface.DrawRect( -10, 5, indicator/1000*480, 20)
		
		if k != "BaseClass" and self:getWeapon2(k) then
		
			surface.DrawRect(-10, 25, 500, 30)
			surface.DrawRect(-10, 55, 10, 20)
			
			local weapon2 = self:getWeapon2(k)			
			local indicator2 = weapon2:GetSecondary()
			local ammo2 = weapon2:GetAmmo()		

			draw.SimpleText(k.." "..t.weapons2[self:GetNWInt("seat_"..k.."_actwep2")], "hvap_heli_big", 0, 25, Black, 0)
			draw.SimpleText(ammo2, "hvap_heli_big", 480, 25, Black, 2)	
			surface.DrawRect( -10, 55, indicator2/1000*480, 20)			
			
		end
		cam.IgnoreZ( false )
		cam.End3D2D()
	end
end

-----------------------------------------------------------------Effects

function ENT:CreateScreenSpaceEffects(k,p)
	if !IsValid(p) or !self.Seats[k] or p:GetViewEntity() != p or self.Seats[k].nohud then return end
	local vehicle = p:GetVehicle()
	
	if vehicle.useCamera and !vehicle:GetThirdPersonMode() then
		self:DrawCameraViewEffects(k)
	elseif vehicle:GetThirdPersonMode() then
		self:DrawThirdPersonViewEffects(k)		
	else
		self:DrawFirstPersonViewEffects(k)	
	end
end

function ENT:DrawFirstPersonViewEffects(seat)

end

function ENT:DrawThirdPersonViewEffects(seat)

end

function ENT:DrawCameraViewEffects(seat)
	if self.NoCamEffects then return end
	local player = LocalPlayer()
	local vehicle = player:GetVehicle()
	local crt = CurTime()
	local sw = ScrW()
	local sh = ScrH()
	local x = sw/2
	local y = sh/2
	local irmat1 = ("hvap/ir_1")
	local irmat2 = ("hvap/ir_2")
--	render.SetColorMaterialIgnoreZ(irmat1)

	if self.EnableIR and vehicle.RenderToggle then
		for k,v in pairs(ents.GetAll()) do
			if IsValid(v) and v:GetModel() and v != self and v:GetParent() != self and v:GetNWEntity("hvap_aircraft") != self then
				if v:IsPlayer() or v:IsNPC() or v.IsHVAP or v.HVAP_ENTITY then
					local mat = v:GetMaterial()
					local col = v:GetColor()
					if mat != irmat1 then
						self.matstore[v] = mat
						v:SetMaterial( irmat1, true )
					end
					if col != Color(255,255,255,255) then
						self.colstore[v] = col
						v:SetColor(Color(255,255,255,255))
					end
				end
			end
		end
		self.RenderRefreshed = false
	elseif self.EnableIR then
		self:RefreshRender()
	end

	if vehicle.RenderToggle and self.EnableIR then
		DrawColorModify({
			[ "$pp_colour_addr" ] 		= -.4,
			[ "$pp_colour_addg" ] 		= -.5,
			[ "$pp_colour_addb" ] 		= -.5,
			[ "$pp_colour_brightness" ] = 0.25,
			[ "$pp_colour_contrast" ] 	= 1,
			[ "$pp_colour_colour" ] 	= 0,
			[ "$pp_colour_mulr" ] 		= 0,
			[ "$pp_colour_mulg" ] 		= 0,
			[ "$pp_colour_mulb" ] 		= 0,
		}) 
		DrawBloom(	
			0.768,  					-- Darken
			1,				-- Multiply
			1.28, 				-- Horizontal Blur
			1, 				-- Vertical Blur
			1, 				-- Passes
			1, 				-- Color Multiplier
			0, 				-- Red
			0, 				-- Green
			0 	 			-- Blue
		)
		DrawTexturize( 1, Material( "pp/texturize/plain.png" ) )
	elseif !self.DisableCamEffects then
		DrawColorModify({
			["$pp_colour_addr"] = 0,
			["$pp_colour_addg"] = 0,
			["$pp_colour_addb"] = 0,
			["$pp_colour_brightness"] = 0,
			["$pp_colour_contrast" ] = 1,
			["$pp_colour_colour" ] = 0,
			["$pp_colour_mulr" ] = 0,
			["$pp_colour_mulg" ] = 0,
			["$pp_colour_mulb" ] = 0,
		})
	end
end

-----------------------------------------------------------------HUD

function ENT:CreateHUDPaint(k,p)
	if !IsValid(p) or !self.Seats[k] or p:GetViewEntity() != p then return end
	local vehicle = p:GetVehicle()

	if vehicle:GetThirdPersonMode() then
		view = self:DrawThirdPersonHUD(k)
	else
		if vehicle.useCamera then
			view = self:DrawCameraHUD(k)
		else
			view = self:DrawFirstPersonHUD(k)
		end
	end

end

function ENT:DrawFirstPersonHUD(seat)

end

function ENT:DrawThirdPersonHUD(seat)

end

function ENT:DrawCameraHUD(seat)

	local sw = ScrW()
	local sh = ScrH()
	local center = {x=sw/2, y=sh/2}	
	local w = sh/6
	local s = sh/3
	
	surface.SetDrawColor(70,199,50,180)
	
	surface.DrawLine(sw/2-s, sh/2-s, sw/2-s+w, sh/2-s)
	surface.DrawLine(sw/2-s, sh/2-s, sw/2-s, sh/2-s+w)
	
	surface.DrawLine(sw/2+s, sh/2-s, sw/2+s-w, sh/2-s)
	surface.DrawLine(sw/2+s, sh/2-s, sw/2+s, sh/2-s+w)
	
	surface.DrawLine(sw/2-s, sh/2+s, sw/2-s+w, sh/2+s)
	surface.DrawLine(sw/2-s, sh/2+s, sw/2-s, sh/2+s-w)
	
	surface.DrawLine(sw/2+s, sh/2+s, sw/2+s-w, sh/2+s)
	surface.DrawLine(sw/2+s, sh/2+s, sw/2+s, sh/2+s-w)
--[[
	for k,v in pairs(ents.GetAll()) do
		if v:IsPlayer() or v:IsNPC() then	
			local pos = v:GetPos():ToScreen()
			pos = {
				x = pos.x-center.x+center.x,
				y = pos.y-center.y+center.y
			}
			surface.DrawOutlinedRect(pos.x-10, pos.y-20, 20, 20)
		elseif v.IsHVAP and !v.HVAP_ENTITY then
			if v.IsHVAPAircraft then
				local pos = v:GetPos():ToScreen()
				pos = {
					x = pos.x-center.x+center.x,
					y = pos.y-center.y+center.y
				}
			surface.DrawOutlinedRect(pos.x-20, pos.y-40, 40, 40)		
			elseif v.IsHVAPGround then
				local pos = v:GetPos():ToScreen()
				pos = {
					x = pos.x-center.x+center.x,
					y = pos.y-center.y+center.y
				}
			surface.DrawOutlinedRect(pos.x-20, pos.y-40, 40, 40)		
			end
		end
	end
]]	
	
	if not self.Seats[seat].weapons then
		return
	end
	
	local weapon = self:getWeapon(seat)
	if IsValid(weapon) and weapon.drawCrosshair then
		weapon:drawCrosshair()
	end
	local weapon2 = self:getWeapon2(seat)
	if IsValid(weapon2) and weapon2.drawCrosshair then
		weapon2:drawCrosshair()
	end	

	local count=0
	for i, name in pairs(self.Seats[seat].weapons) do
		if i != "BaseClass" then
			count = count+1
			if i == self:GetNWInt("seat_"..seat.."_actwep") then
				surface.SetDrawColor(10,10,10,150)
				surface.DrawRect(sw/2+w*2,sh/7+count*50,w*2+10,50)
			end
		end
	end
	surface.SetDrawColor(10,10,10,100)
	surface.DrawRect(sw/2+w*2,sh/7+50,w*2+10,count*50)
	surface.SetDrawColor(255,255,255,200)
	surface.DrawOutlinedRect(sw/2+w*2,sh/7+50,w*2+10,count*50)
	surface.SetFont("hvap_heli_small")
	surface.SetTextColor(230,230,230,255)

	local h = 1
	for i, name in pairs(self.Seats[seat].weapons) do
		if i != "BaseClass" then
			local wep = self.weapons[name]
			if wep then
				local ammo = wep:GetAmmo()
				surface.SetTextPos(sw/2+w*2+5,sh/7+5+h*50)
				surface.DrawText(name)
				surface.SetTextPos(sw/2+w*4+5-string.len(ammo)*14,sh/7+5+h*50)
				surface.DrawText(ammo)
				surface.SetDrawColor(255,255,255,200)
				local indicator = wep:GetSecondary()
				surface.DrawRect(sw/2+w*2,sh/7+h*50+40, (w*2+10)*indicator/1000, 10)
				h=h+1
			end
		end
	end
	
	if IsValid(weapon2) then 
		for i, name in pairs(self.Seats[seat].weapons2) do
			if i != "BaseClass" then
				count = count+1
				if i == self:GetNWInt("seat_"..seat.."_actwep2") then
					surface.SetDrawColor(10,10,10,150)
					surface.DrawRect(sw/2+w*2,sh/7+count*50,w*2+10,50)
				end
			end
		end
		surface.SetDrawColor(10,10,10,100)
		surface.DrawRect(sw/2+w*2,sh/7+50,w*2+10,count*50)
		surface.SetDrawColor(255,255,255,200)
		surface.DrawOutlinedRect(sw/2+w*2,sh/7+50,w*2+10,count*50)
		surface.SetFont("hvap_heli_small")
		surface.SetTextColor(230,230,230,255)

		for i, name in pairs(self.Seats[seat].weapons2) do
			if i != "BaseClass" then
				local wep = self.weapons2[name]
				if wep then
					local ammo = wep:GetAmmo()
					surface.SetTextPos(sw/2+w*2+5,sh/7+5+h*50)
					surface.DrawText(name)
					surface.SetTextPos(sw/2+w*4+5-string.len(ammo)*14,sh/7+5+h*50)
					surface.DrawText(ammo)
					surface.SetDrawColor(255,255,255,200)
					local indicator = wep:GetSecondary()
					surface.DrawRect(sw/2+w*2,sh/7+h*50+40, (w*2+10)*indicator/1000, 10)
					h=h+1
				end
			end
		end
	end
end

-----------------------------------------------------------------

function ENT:RefreshRender()
	if !self.EnableIR or self.RenderRefreshed then return end
	for ent,emat in pairs( self.matstore ) do
		if ent:IsValid() then
			ent:SetMaterial( emat )
		end
	end	
	for ent,ecol in pairs( self.colstore ) do
		if ent:IsValid() then
			ent:SetColor( ecol )
		end
	end	
	self.RenderRefreshed = true
	self.matstore = {}
	self.colstore = {}
end

function ENT:OnRemove()
	self:RefreshRender()
	for _,s in pairs(self.sounds) do
		s:Stop()
	end
end

net.Receive("hvap.aircraft.updateWeapons", function(length)
	local aircraft = net.ReadEntity()
	local count = net.ReadInt(5)
	for i = 1, count do
		local name = net.ReadString()
		local weapon = net.ReadEntity()
		aircraft.weapons[name] = weapon
		for index, value in pairs(aircraft.Weapons[name].info) do
			weapon[index] = value
		end
		if weapon.clientUpdate then
			weapon:clientUpdate()
		end
	end

	local count2 = net.ReadInt(5)
	for i = 1, count2 do
		local name = net.ReadString()
		local weapon2 = net.ReadEntity()
		aircraft.weapons2[name] = weapon2
		for index, value in pairs(aircraft.Weapons2[name].info) do
			weapon2[index] = value
		end
		if weapon2.clientUpdate then
			weapon2:clientUpdate()
		end
	end

end)
