
if !hvap or !hvap.aircraft then
	error("hvap scripts not loaded.")
end

if wac then
	MsgC( Color( 255, 0, 0 ), "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )
	PrintMessage( HUD_PRINTCENTER, "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )
	PrintMessage( HUD_PRINTTALK, "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )	
return end

ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.PrintName = "Base Plane"
ENT.Author = hvap.author
ENT.Category = hvap.aircraft.spawnCategory
ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.FuselageHealth = 1000

ENT.HasCanopy = false
ENT.HasGear = false

ENT.Fuel = 100
ENT.BaseFuel = 100
ENT.FuelConMult = 1
ENT.CoopEngines = true

ENT.FlyableEngines = 1

ENT.RotSPD = 0.05

ENT.Aerodynamics = {
	Rotation = {
		Forwards = Vector(0, -1, 0),-- rotate aircraft for (left) (down) (right) when moving forwards | 0,8,0 |
		Right = Vector(-1, 0, 1), -- rotate aircraft for (left) (up) (right) when moving right | 0,0,0 |
		Up = Vector(0, 4, 0) -- rotate aircraft for (right) (down) (left) when moving up | 0,0,0 |
	},
	Movement = {
		Forwards = Vector(0, 0, -4), -- move aircraft for (forwards) (right) (up) when moving forwards | 0,0,-4 |
		Right = Vector(0, 0, 0), -- move aircraft for (backwards) (right) (down) when moving right | 0,0,0 |
		Up = Vector(6, 0, 0) -- move aircraft for (forwards) (right) (up) whem moving up | 1,0,-2 |
	},
	Rail = Vector(0.1, 1, 0.1),-- 0,0,0
	RailRotor = 1, -- like Z rail but only active when moving and the rotor is turning
	AngleDrag = Vector(0.1, 0.1, 0.1),
	Rotate = Vector(3.8, 3.8, 3.6),-- rotation multipliers (roll) (pitch) (yaw)
} 

ENT.Weight = 1000

ENT.SeatSwitcherPos = Vector(0,0,50)

ENT.BullsEyePos	= Vector(20,0,50)

ENT.MaxEnterDistance = 50

ENT.WheelStabilize = -400
ENT.Wheels = {}

ENT.Weapons = {}
ENT.Weapons2 = {}
ENT.CounterMeasures = {}
ENT.Lights = {}
ENT.Doors = {}

ENT.PlyDmgMult = 1 -- player damage multiplier
ENT.PlyDmgDist=50 -- max distance to damage player

ENT.Function = 0
ENT.Function2 = 0

ENT.Scale = 1

ENT.Seats = {
	{
		pos = Vector(68, 0, 48),
		exit = Vector(72,70,0),
	},
}

ENT.IsHVAP = true
ENT.IsHVAPAircraft = true
ENT.IsHVAPPlane = true
ENT.IsHVAPGround = false
ENT.AllowAmmo = true
ENT.AllowFuel = true
ENT.AllowRepair = true
ENT.Submersible = false
ENT.CrRotorWash = false

ENT.thirdPerson = {
	distance = 600,
	angle = 10,
	position = Vector(-50,0,100)
}

ENT.HatingNPCs={
	"CombineElite",
	"npc_combinegunship",
	"npc_combine_s",
	"npc_helicopter",
	"npc_manhack",
	"npc_metropolice",
	"CombinePrison",
	"PrisonShotgunner",
	"npc_rollermine",
	"npc_clawscanner",
	"ShotgunSoldier",
	
	"npc_stalker",
	"npc_strider",
	"npc_turret_floor",
	"npc_combine_camera",
	"npc_turret_ceiling",
	"npc_hunter",
	"npc_antlion",
	"PrisonShotgunner",
	"npc_antlion_grub",
	"npc_antlionguard",
	"npc_antlionguardian",
	"npc_antlion_worker",
	"npc_barnacle",
	"npc_headcrab_fast",
	"npc_fastzombie",
	"npc_fastzombie_torso",
	"npc_headcrab",
	"npc_headcrab_black",
	"npc_poisonzombie",
	"npc_zombie",
	"npc_zombie_torso",
	"npc_zombine",
	"npc_cscanner",
	"npc_combinedropship",
}

ENT.Sounds = {
	Start = "",
	Stop = "", 

	ext1 = "",
	ext2 = "", 
	ext3 = "",
	
	int1 = "",
	int2 = "", 
	int3 = "",
	
	MissileAlert = "HVAP.Alarm.Missile",
	Alarm25 = "HVAP.Alarm.25",
	Alarm50 = "HVAP.Alarm.50",
	Alarm75 = "HVAP.Alarm.75",
	Burning = "HVAP.Vehicle.Burn",
	Damaged = "HVAP.Alarm.Damaged",
	
	Refuel = "ambient.steam01",	
}

function ENT:addSounds()
	self.sounds = {}
	for k, v in pairs(self.Sounds) do
		if k != "BaseClass" then
			self.sounds[k] = CreateSound(self, v)
		end
	end
end

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "Hover")
	self:NetworkVar("Entity", 0, "Switcher")
end

function ENT:base(name)
	local current = self
	while current do
		if current.ClassName == name then
			return current
		end
		current = current.BaseClass
	end
	error("No base class with name \"" .. name .. "\"", 2)
end

function ENT:updateSkin(n)
	if SERVER then
		for _, e in pairs(self.Children) do
			if IsValid(e) then
				e:SetSkin(n)
			end
		end
	end
end

function ENT:getPassenger(seat)
	if !IsValid(self:GetSwitcher()) then return end
	local s = self:GetSwitcher().seats[seat]
	if IsValid(s) then
		return s:GetDriver()
	end
end

function ENT:GetViewTarget(k)
	if !IsValid(self.seats[k]) or !self.CamData[k] or !IsValid(self:getPassenger(k)) then return end

	local minAng = self.Turrets[self.Seats[k].Turret].info.minAng
	local maxAng = self.Turrets[self.Seats[k].Turret].info.maxAng
	local ang = self:WorldToLocalAngles(self.CamData[k].angles)
	local pos = self.CamData[k].origin

	local tr = util.QuickTrace(pos, self:LocalToWorldAngles(ang):Forward()*999999999, self.Children)

	return tr

end

