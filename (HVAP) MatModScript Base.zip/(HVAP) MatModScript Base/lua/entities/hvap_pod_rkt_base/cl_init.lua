
include ("shared.lua")

function ENT:drawCrosshair()
	surface.SetDrawColor(70,199,50,180)
	local center = {x=ScrW()/2, y=ScrH()/2}
	surface.DrawLine(center.x+10, center.y, center.x+30, center.y)
	surface.DrawLine(center.x-30, center.y, center.x-10, center.y)
	surface.DrawLine(center.x, center.y+10, center.x, center.y+30)
	surface.DrawLine(center.x, center.y-30, center.x, center.y-10)
	surface.DrawOutlinedRect(center.x-20, center.y-25, 40, 50)
	surface.DrawOutlinedRect(center.x-11, center.y-11, 22, 22)
end
