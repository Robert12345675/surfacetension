
include ("shared.lua")
AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")

ENT.Base 				= "base_entity"
ENT.Type 				= "point"

ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:Initialize()
	self:SetNextShot(0)
	self:SetLastShot(0)
	self:SetAmmo(self.Ammo)
	self:SetSecondary(0)
	self.OnRemoveEntities={}
	self.OnRemoveFunctions={}
	self:addSounds()
	self.ActiveBelt = self.AmmoBelt[self.Belt]
	self.CurEffect = CurTime()		
end

function ENT:OnRemove()
	for _,f in pairs(self.OnRemoveFunctions) do
		f()
	end
	for _,e in pairs(self.OnRemoveEntities) do
		if IsValid(e) then e:Remove() end
	end
end

function ENT:getAttacker()
	if IsValid(self.seat) and IsValid(self.seat:GetDriver()) then
		return self.seat:GetDriver()
	end
	return self.aircraft
end

function ENT:trigger(b, seat)
	self.shouldShoot = b
	self.seat = seat
end

function ENT:fire()
	if self.Sequential then
		self.currentPod = self.currentPod or 1
		self:fireRocket(self.Pods[self.currentPod], self:GetAngles())
		self.currentPod = (self.currentPod == #self.Pods and 1 or self.currentPod + 1)
	else
		for _, pos in pairs(self.Pods) do
			self:fireRocket(pos, self:GetAngles())
		end
	end
end

function ENT:fireRocket(pos)
	if !self.CanShoot or !self:takeAmmo(1) or !self.seat then return end
	local pos2;
	local ang;

	if self.IsAimed then
		local gun = self.aircraft.turrets[self.Turret][self.Pod][self.Attach]
		pos2 = gun:LocalToWorld(pos)
		ang = gun:GetAngles()+Angle(math.Rand(-self.Spread,self.Spread),math.Rand(-self.Spread,self.Spread),0)
	else
		pos2 = self.aircraft:LocalToWorld(pos)
		ang = self.aircraft:GetAngles()+Angle(math.Rand(-self.Spread,self.Spread),math.Rand(-self.Spread,self.Spread),0)	
	end
	math.randomseed( pos2:Length() )

	local bt = self.AmmoData[self.ActiveBelt[ self.bulletIndex  ] ]

	b=ents.Create(bt.class)
	for k, v in pairs(bt.info) do
		b[k] = v
	end
	b.airvel=self.IsAimed and Vector() or self.aircraft:GetVelocity()*0.256
	b:SetPos(pos2)
	b:SetAngles(ang)
	b.AircraftFiring=self.aircraft
	b.EntFilter = self.aircraft.Children
	b.Owner = self.seat:GetDriver()
	b:Spawn()
	self:AddOnRemove(b)
	self:MuzzleEffect(pos2, self.Caliber, ang)
	self.aircraft.phys:ApplyForceOffset( (ang:Forward()*math.random(320,400)+VectorRand()*math.random(380,420))*(-self.Punch), pos2 )

	sound.Play( self.Sounds.fire, pos2 )	
	
	self.bulletIndex = self.bulletIndex + 1
	if ( self.bulletIndex > #self.ActiveBelt ) then
		self.bulletIndex = 1
	end
end

function ENT:MuzzleEffect(pos, size)
	local effectdata = EffectData()
	effectdata:SetEntity(self)
	effectdata:SetNormal(self:GetForward())
	effectdata:SetOrigin(pos)
	effectdata:SetScale(1)
	effectdata:SetRadius(size)
	util.Effect("hvap_rocket_trail", effectdata)
end

function ENT:stop()

end

function ENT:select(bool)
	if !bool then
		self:stop()
	end
end

function ENT:takeAmmo(amount)
	if self:GetAmmo() < amount then return false end
	self:SetAmmo(math.Clamp(self:GetAmmo() - amount,0,self.Ammo))
	return true
end

function ENT:Think()

	self:SetSecondary((self:GetAmmo()/self.Ammo)*1000)
		
	if IsValid(self.seat) and self.shouldShoot and self:GetNextShot() <= CurTime() and self:GetAmmo() > 0 then
		if !IsValid(self.seat:GetDriver()) then
			self.shouldShoot = false
		else
			self:fire()
			self:SetLastShot(CurTime())
			self:SetNextShot(self:GetLastShot() + 60/self.FireRate)		
		end
	end

	if self:GetNextShot() <= CurTime() then
		self:stop()
	end
	self:NextThink(CurTime())
	return true
end
