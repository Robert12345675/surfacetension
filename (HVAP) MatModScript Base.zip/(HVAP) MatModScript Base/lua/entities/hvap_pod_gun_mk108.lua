AddCSLuaFile()

ENT.Base = "hvap_pod_gun_base"
ENT.Type = "point"

ENT.PrintName = "MK108"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "MK108"
ENT.Ammo = 1000
ENT.FireRate = 660
ENT.Punch = 55

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.CoolDown = 4//ammount taken from heat every sec
ENT.HeatMult = 8//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 1//time it takes for unoverheat
ENT.Caliber = 30
ENT.Spread = 0.64
ENT.SndPitch = 100

ENT.AmmoBelt = {
	{
		"heit",
		"i",
	},
	{
		"heit",
		"heit",
		"i",
		"i",
	},
	{
		"heit",
		"heit",
		"heit",
		"i",
		"i",
		"i",
	},
	{
		"heit",
		"heit",
		"heit",
		"heit",
		"i",
		"i",
		"i",
		"i",
	},
}

ENT.AmmoData = {
	["heit"] = {
		class = "hvap_bullet_he",
		info = {
			Large=false,
			SelfDestr=true,
			Flak=true,
			Tracer=true,--tracer?
			Timer=0.7,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 255, 255),
			Speed=510,--velocity m/s
			Radius=256,--caliber
			Penetrate= 0,--caliber
			BallisticDrag	= 16,
			Drift=0.64,
			Mass=102,--g
			TissueDamage = math.Rand(180,256),--
			EffectSize = 15,
			Size=30--caliber
		}
	},
	["i"] = {
		class = "hvap_bullet_api",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=510,--velocity m/s
			Radius=80,--caliber
			Penetrate= 20,--caliber
			BallisticDrag	= 16,
			Drift=0.55,
			Mass=102,--g
			TissueDamage = math.Rand(256,320),--
			EffectSize = 15,
			Size=30--caliber
		}
	},	
}

ENT.Sounds = {
	shoot = "HVAP.Gun.MK108.Loop", -- sound played when firing
	stop = "HVAP.Gun.MK108.End", -- sound played when stop firing
	blank = "HVAP.Gun.Misc.BlankFire", -- sound played when stop firing but hammed 
	clickstop = "HVAP.Gun.Jam.Click.End", -- sound plaed when near overheat
	clickshoot = "HVAP.Gun.Jam.Click.Loop", -- sound plaed when near overheat stop
	Jam = "HVAP.Gun.Jam.Start", -- sound to play when gun jams
	GunReady = "HVAP.Gun.Jam.Finish"
}
