
AddCSLuaFile()

ENT.Type 			= "anim"  
ENT.Base 			= "base_anim"     
ENT.PrintName			= "Missile"  
ENT.Author			= "The_HAVOK"  
ENT.Contact			= "The_HAVOK"  
ENT.Purpose			= ""  
ENT.Instructions		= ""  

ENT.Spawnable			= false

ENT.HVAP_ENTITY = true
ENT.HVAP_BOMB = true
ENT.Fuel = 1000
ENT.valid = false

ENT.Sounds = {
	Whistle = "HVAP.Rocket.Fly"
}

if CLIENT then

function ENT:Draw()            
	self.Entity:DrawModel()
end

elseif SERVER then

function ENT:Initialize()   
	math.randomseed(CurTime())
	self.Impacted = false
	self:SetModel( self.model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_NONE )
	
	self:addSounds()
	self.Flightvector 	= (self.speed*52.459*FrameTime())*10	
	self.Phy=self:GetPhysicsObject()
	self.Phy:SetMass(self.mass)
	self.Phy:EnableDrag( true )
	self.Phy:SetAngleDragCoefficient( self.Size/10 )
	self.Phy:SetDragCoefficient( self.Size/25 )
	self.HitWater = false
	self.airvel = Vector()
	self.Timed = false
	self.active = false
	self.Shine = nil
	self.Mask = MASK_SHOT+CONTENTS_EMPTY
	self.valid = true
end   

function ENT:ActivateFuse()
	self.active = !self.active
	self.TraceEnd = self:GetPos()
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:GetPhysicsObject():Wake()
	self.Phy:SetMass(self.mass)
	if !self.Shine then
		self.Shine = ents.Create("env_sprite")
		self.Shine:SetPos(self:LocalToWorld(Vector(-8,0,0)))
		self.Shine:SetKeyValue("renderfx", "0")
		self.Shine:SetKeyValue("rendermode", "5")
		self.Shine:SetKeyValue("renderamt", "192")
		self.Shine:SetKeyValue("rendercolor", "255 130 100")
		self.Shine:SetKeyValue("framerate12", "20")
		self.Shine:SetKeyValue("model", "light_glow03.spr")
		self.Shine:SetKeyValue("scale",1)
		self.Shine:SetKeyValue("GlowProxySize", 1)
		self.Shine:SetParent(self.Entity)
		self.Shine:Spawn()
		self.Shine:Activate()	
	end
end

function ENT:Think()
	if !self:IsValid() or !self.valid then return end
	local crt = CurTime()
	local fwd = self:GetForward()
	if self.active then
		
		if self.Fuel > 0 then
			if !self.sounds.Whistle:IsPlaying() then
				self.sounds.Whistle:Play()
			end
		else
			if self.sounds.Whistle:IsPlaying() then
				sound.Play( "HVAP.Bullet.Explode.Small", self:GetPos() )	
				self.sounds.Whistle:Stop()
			end	
		end				

	end
	self:NextThink( crt )
	return true
end

function ENT:PhysicsUpdate(ph)
	if !self:IsValid() or !self.valid then return end
	local vel = self:WorldToLocal(self:GetPos()+self:GetVelocity())
	vel.x = 0
	local vell = vel:Length()
	local pos = self:GetPos()
	local fwd = self:GetForward()
	local ang = self:GetAngles()
	local phm = FrameTime()*66

	if self.active then
		local tr = util.TraceLine({
			start 	= (self.TraceEnd),
			endpos 	= (self:GetPos() + fwd*128),
			filter 	= self.EntFilter,
			mask 	= self.Mask
		})	
		self.TraceEnd = tr.endpos
		
		if tr.Hit and !table.HasValue( self.EntFilter, tr.Entity ) and tr.Entity:GetClass() != "hvap_rotor" and tr.Entity:GetClass() != "hvap_rotor_r" and !tr.Entity.HVAP_BOMB then
			self.Mat = math.ceil(tr.MatType)	
			if tr.HitSky then
				self:Remove()
				return true
			end
			if self.Mat==83 and !self.HitWater then
				local effectdata = EffectData()
				effectdata:SetOrigin( tr.HitPos )
				effectdata:SetNormal( tr.HitNormal )
				effectdata:SetScale( self.Size )
				util.Effect( "watersplash", effectdata )
				self.HitWater = true
			end
			self:Impact(tr)
		end		
	
		self.Fuel = math.Clamp (self.Fuel - 1,0,1000)
		if self.Fuel > 0 then
			ph:AddVelocity(self:GetForward()*self.Fuel*self.Flightvector-self:LocalToWorld(vel*Vector(0.1, 1, 1))+self:GetPos())
			ph:AddAngleVelocity(
				VectorRand()*16
				+ Vector(0, -vel.z, vel.y)
			)
		else
			if IsValid(self.Shine) then
				self.Shine:Remove()
			end
		end

	end
	
end

function ENT:Impact(tr)

	local pos = self:GetPos()	
	local effectdata = EffectData()
		effectdata:SetEntity(tr.Entity)
		effectdata:SetMagnitude(10)
		effectdata:SetNormal(tr.HitNormal)
		effectdata:SetOrigin(tr.HitPos)
		effectdata:SetScale(self.Size)
		effectdata:SetStart(self:GetForward())
		effectdata:SetSurfaceProp(tr.MatType or 1)
	util.Effect("hvap_bullet_impact_missile", effectdata )
	util.BlastDamage( self.AircraftFiring or self, self.Owner or self, pos+Vector(0,0,64), self.Radius*1.6, self.Damage*1.6 )
	util.ScreenShake( pos, self.mass, self.mass/10, 3.5, self.Radius*2 )
	self:Remove()
end

function ENT:OnRemove()
	self:StopAllSounds()
	if IsValid(self.Shine) then
		self.Shine:Remove()
	end
end

function ENT:StopAllSounds()
	for k, s in pairs(self.sounds) do
		if s:IsPlaying() then
			s:Stop()
		end
	end
end

end

function ENT:addSounds()
	self.sounds = {}
	for k, v in pairs(self.Sounds) do
		if k != "BaseClass" then
			self.sounds[k] = CreateSound(self, v)
		end
	end
end

function ENT:UpdateTransmitState() return TRANSMIT_PVS end -- TRANSMIT_ALWAYS
