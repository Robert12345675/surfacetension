AddCSLuaFile()

ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.PrintName = "Station"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = false
ENT.health = 100
ENT.valid = false
ENT.Radius = 5120
ENT.TickTime = 1
ENT.Mass = 4000
ENT.Scl = 14
ENT.Model = ""
ENT.HVAP_ENTITY = true

if SERVER then

function ENT:SpawnFunction( ply, tr)
	if (!tr.Hit) then return end	
	local ent=ents.Create(ClassName)
	local ang = ply:EyeAngles()	
	
	ent:SetPos(tr.HitPos+tr.HitNormal*self.SpawnHeight or 20)
	ent:SetAngles(Angle(tr.HitPos:GetNormal().x,(ply:EyeAngles().y+180),tr.HitPos:GetNormal().z))

	ent:Spawn()
	ent:Activate()
	ent.Owner=ply
	return ent
end

function ENT:Initialize()
	self.Entity:SetModel(self.Model)
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Phy = self.Entity:GetPhysicsObject()
	self.Phy:SetMass(self.Mass)
	self.Phy:Wake()
	self.Basehealth = self.health
	self.LastDamageTaken = 0
	self.CurTick = CurTime()
	self:SecondaryInitialize()
	self.valid = true
end

function ENT:SecondaryInitialize()
end

function ENT:Think()
	if !self.valid then return end
	local crt = CurTime()
	
	if self.CurTick < crt then
		for _, v in pairs(ents.FindInSphere(self:GetPos(), self.Radius)) do
			self:Function(v, crt)
		end	
		self.CurTick = crt + self.TickTime
	end
	
	if self.health == 0 then
		self:Explode()
	end
	self:NextThink(crt)
	return true	
end

function ENT:Explode()
	local lasta=(self.LastDamageTaken<CurTime()+6 and self.LastAttacker or self.Entity)
	local effectdata = EffectData()
	effectdata:SetOrigin(self.Entity:GetPos())
	effectdata:SetScale(self.Scl)
	util.Effect("hvap_explode", effectdata)
	util.BlastDamage(self.Entity,(IsValid(lasta) and lasta or self.Entity), self.Entity:GetPos(), 250, 300)
	util.ScreenShake( self.Entity:GetPos(), self.Scl, self.Scl, 3, self.Scl*100 )
	self:Remove()
end

function ENT:OnTakeDamage( dmg )
	local crt = CurTime()	
	self.LastAttacker=dmg:GetAttacker()
	self.LastDamageTaken=crt
	self:DamageSelf(dmg:GetDamage())
end

function ENT:PhysicsCollide( cdat, phys )
	if cdat.DeltaTime > 0.5 then
		local mass = cdat.HitObject:GetMass()
		if cdat.HitEntity:GetClass() == "worldspawn" then
			mass = 3200
		end
		local dmg = (math.pow(cdat.Speed, 2)*math.Clamp(mass, 0, 5000))/10000000

		if !dmg or dmg <= 32 then return end	
		self:DamageSelf(dmg)
	end	
end

function ENT:DamageSelf(dmg)
	if self.Unbreakable then return end
	self.health = math.Clamp(self.health - dmg/10, 0, self.Basehealth)
end

function ENT:Function()
end

end