AddCSLuaFile()

ENT.Base = "hvap_pod_gun_base"
ENT.Type = "point"

ENT.PrintName = "Yak-B"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "Yak-B"
ENT.Ammo = 1470 
ENT.FireRate = 2000
ENT.Force = 9999999999

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.CoolDown = 0//ammount taken from heat every sec
ENT.HeatMult = 50//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 0.42//time it takes for unoverheat
ENT.Caliber = 12.7
ENT.Spread = 0.2
ENT.SndPitch = 100
ENT.DisableOverShoot = true

ENT.Punch = 40

ENT.AmmoBelt = {--A165 Belt
	{
		"apt",
		"api",
		"ap",
		"api",
		"ap",
	}
}

ENT.AmmoData = {
	["ap"] = {
		class = "hvap_bullet_ap",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=824,--velocity m/s
			Radius=128,--caliber
			Penetrate= 16,--caliber
			BallisticDrag	= 16,
			Drift=0.32,
			Mass=102,--g
			TissueDamage = math.Rand(30,45),--
			EffectSize = 10,
			Size=12.7,--caliber
		}
	},
	["api"] = {
		class = "hvap_bullet_api",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=824,--velocity m/s
			Radius=128,--caliber
			Penetrate= 16,--caliber
			BallisticDrag	= 16,
			Drift=0.32,
			Mass=102,--g
			TissueDamage = math.Rand(30,45),--
			EffectSize = 10,
			Size=12.7,--caliber
		}
	},
	["apt"] = {
		class = "hvap_bullet_ap",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=true,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(20, 250, 20),
			Speed=824,--velocity m/s
			Radius=128,--caliber
			Penetrate= 16,--caliber
			BallisticDrag	= 16,
			Drift=0.256,
			Mass=102,--g
			TissueDamage = math.Rand(30,45),--
			EffectSize = 10,
			Size=12.7,--caliber
		}
	},
}

ENT.Sounds = {
	shoot = "HVAP.Gun.YakB.Loop", -- sound played when firing
	stop = "HVAP.Gun.YakB.End", -- sound played when stop firing
	blank = "", -- sound played when stop firing but hammed 
	clickstop = "", -- sound plaed when near overheat
	clickshoot = "", -- sound plaed when near overheat stop
	Jam = "", -- sound to play when gun jams
	GunReady = ""
}
