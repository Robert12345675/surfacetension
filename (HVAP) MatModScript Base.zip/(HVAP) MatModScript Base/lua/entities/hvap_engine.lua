
AddCSLuaFile()
ENT.Base 				= "base_anim"
ENT.Type 				= "anim"
--[[
ENT.Base 				= "base_entity"
ENT.Type 				= "point"
]]
ENT.PrintName			= "HVAP Engine"
ENT.Author				= hvap.author
ENT.Category			= ""
ENT.Contact    			= ""
ENT.Purpose 			= ""
ENT.Instructions 		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable	= false
ENT.engineRpm = 0
ENT.RPMSCL = 0
ENT.enginePower = 0
ENT.engineHealth = 0
ENT.FuelSub = 0
ENT.Disabled = false
ENT.Burning = false
ENT.Smoking = false
ENT.EngineFire = NULL
ENT.HealthScale = 1
ENT.valid = false
ENT.IsHVAP = true
ENT.AllowRepair = true
ENT.Plane = false

if SERVER then

function ENT:Initialize()

	self.Entity:SetModel("models/props_junk/PopCan01a.mdl")

	self.OnRemoveEntities = {}
	self.SmokeTimer = CurTime()
	self.CreatingSmoke = false
	
	self.EngineHPMult = self.aircraft.EngineHPMult
	
	if self.EngineHPMult > 0 then
		self.engineHealth = self.engineHealth*self.EngineHPMult
		self.Unbreakable = false
	else
		self.Unbreakable = true
	end
	
	if self.aircraft.Unbreakable then
		self.Unbreakable = true
	end	
	
	self.BaseHealth=self.engineHealth
	
	self.valid = true
end

function ENT:Think()
	if !self.valid then return end
	local crt = CurTime()
	local frt = FrameTime()

	if self.aircraft.active and self.engineHealth > 0 then		
		if !self.Plane then 
			self.engineRpm = math.Clamp(self.engineRpm+(self.aircraft.StartSpd+1)*30*frt, 0, self.MaxRPM+(self.MaxRPM*(self.HealthScale-1))/math.random(2,3))	
			if hvap.aircraft.cvars.fuelenable:GetInt() == 1 then
				self.FuelSub = ((self.RPMSCL)+(1-self.HealthScale)*10)*self.Consumption
			end
		else--planes
			self.engineRpm = math.Clamp(self.engineRpm+(self.aircraft.StartSpd+1)*30*frt, 0, (self.aircraft.Throttle*(self.MaxRPM+(self.MaxRPM*(self.HealthScale-1))/math.random(2,3)))*0.8 + 0.2*self.MaxRPM)	
			if hvap.aircraft.cvars.fuelenable:GetInt() == 1 then
				self.FuelSub = ((self.RPMSCL)+(1-self.HealthScale)*10)*self.Consumption
			end
		end
		if !self.Plane then self:CreateEffect() end
	else
		self.engineRpm = math.Clamp(self.engineRpm-(self.aircraft.StartSpd+1)*18*frt, 0, self.MaxRPM)
		self.FuelSub = 0
	end	
	
	if self.Plane then self:CreateEffect() end

	if self.HealthScale < 0.95 and self.HealthScale > 0.25 then
		self.Smoking = true	
	elseif self.HealthScale < 0.25 then
		self.Burning = true
	else
		self.Smoking = false
		self.Burning = false
	end
	
	if self.Burning then
		self:DamageEngine(0.05)
		self:Burn()
	else
		if self.EngineFire:IsValid() then
			self.EngineFire:Remove()
		end
	end
	
	if self.Smoking then
		self.CreatingSmoke = false
		if self.aircraft:GetVelocity():Length() < 80 then 
			if self.SmokeTimer < crt then
				self:CreateSmoke()
				self.SmokeTimer = crt + 0.2
			else
			end
		else
			self:CreateSmoke()
		end
	else
	end
	
	if self.engineHealth == 0 and !self.Disabled then
		local effectdata = EffectData()
		effectdata:SetOrigin(self.Entity:GetPos())
		effectdata:SetScale(self.BaseHealth/10)
		util.Effect("hvap_explode_engine", effectdata)
		self.Disabled = true
	end
	
	self.enginePower = math.Clamp(self.RPMSCL*self.Power+(self.Power*(self.HealthScale-1)/10), 0, self.Power)	
	self.HealthScale = self.engineHealth/self.BaseHealth
	self.RPMSCL = self.engineRpm/self.MaxRPM	

	self:NextThink(crt+0.0512)
	return true
end

function ENT:DamageEngine(dmg)
	if self.Disabled or self.Unbreakable then return end
	self.engineHealth = math.Clamp(self.engineHealth - dmg/4, 0, self.BaseHealth)
end

function ENT:CreateSmoke(crt)
	self.CreatingSmoke = true
	if self.Unbreakable or self:WaterLevel() >= 1 or self.Burning or self.Plane then return end
	local ed=EffectData()
	local colmod = math.Clamp(math.random(119,121)*self.HealthScale+ (self.Plane and -64 or 50),1, 255)
	ed:SetEntity(self.aircraft)
	ed:SetOrigin(self:LocalToWorld(self.SmokePos))
	ed:SetColor(colmod)
	ed:SetScale(1-self.HealthScale)
	ed:SetRadius(self.RPMSCL)
	smoke = util.Effect(self.SmokeEffect, ed)
	self:AddOnRemove(smoke)
end

function ENT:CreateEffect()
	if self:WaterLevel() >= 1 or self.Burning then return end
	if self.EffectPos and self:IsValid() then
		local ed=EffectData()
		local colmod = 255-math.Clamp(math.random(119,121)*self.RPMSCL + 80,1, 255)
		local colmod2 = math.Clamp(math.random(119,121)*self.HealthScale -64,1, 255)
		ed:SetEntity(self.aircraft)
		ed:SetStart(self:LocalToWorld(self.SmokePos))
		ed:SetOrigin(self:LocalToWorld(self.EffectPos))
		ed:SetColor(colmod)
		ed:SetMagnitude(self.RPMSCL)
		ed:SetScale(self.CreatingSmoke and self.HealthScale or 0)
		ed:SetRadius(colmod2)
		heatwave = util.Effect(self.EngineEffect, ed)
		self:AddOnRemove(heatwave)
	else return end
end

function ENT:Burn()
	if self.Unbreakable or self:WaterLevel() >= 1 or !self.Burning then 
		if self.EngineFire:IsValid() then
			self.EngineFire:Remove()
		end
		return
	end
	if !self.EngineFire:IsValid() then
		local fire = ents.Create("env_fire_trail")
		fire:SetPos(self:LocalToWorld(self.FirePos))
		fire:Spawn()
		fire:SetParent(self.Entity)
		self.EngineFire = fire
		self:AddOnRemove(fire)
	end
end

function ENT:Repair(amt,b)
	if b then
		if self.engineHealth < self.BaseHealth then
			self.engineHealth = math.Clamp(self.engineHealth + amt, 0, self.BaseHealth )
		end
			
		if self.Disabled then 
			self.Disabled = false
		end
	else
		if self.engineHealth < self.BaseHealth then
			self.engineHealth = math.Clamp(self.engineHealth + self.BaseHealth/amt, 0, self.BaseHealth )
			
			if self.Disabled then 
				self.Disabled = false
			elseif self.Burning then
				self.Burning = false
			elseif self.Smoking then
				self.Smoking = false
			end
			
			if self.EngineFire:IsValid() then
				self.EngineFire:Remove()
			end
		end
	end
end

function ENT:AddOnRemove(f)
	if type(f)=="Entity" then
		table.insert(self.OnRemoveEntities,f)
	end
end

function ENT:OnRemove()
	for _,e in pairs(self.OnRemoveEntities) do
		if IsValid(e) then e:Remove() end
	end
end

end

function ENT:UpdateTransmitState() return TRANSMIT_PVS end -- TRANSMIT_ALWAYS
