
include ("shared.lua")
AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")

ENT.Base 				= "base_entity"
ENT.Type 				= "point"

ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:Initialize()
	self:SetAmmo(0)
	self.Ammo = #self.Pods
	self:SetNextShot(0)
	self:SetLastShot(0)
	self:SetSecondary(0)
	self.OnRemoveEntities={}
		
	self.ActiveBelt = self.AmmoBelt[self.Belt]	
	if hvap.aircraft.cvars.nospawnordinance:GetFloat() != 1 then
		self:ReloadBombs()
	end
	self.CurEffect = CurTime()		
end

function ENT:AddOnRemove(f)
	table.insert(self.OnRemoveEntities,f)
end

function ENT:OnRemove()
	for _,e in pairs(self.OnRemoveEntities) do
		if IsValid(e) then e:Remove() end
	end
end

function ENT:ReloadBombs()	
	self.bombs={}
	for k,v in pairs(self.Pods) do
		local bt = self.AmmoData[ self.ActiveBelt[ self.bulletIndex  ] ]
		local b=ents.Create(bt.class)

		for k, v in pairs(bt.info) do
			b[k] = v
		end
		b:SetPos(self.aircraft:LocalToWorld(v.pos))
		b:SetAngles(self.aircraft:GetAngles()+v.ang)
		b:Spawn()
		b.EntFilter = self.aircraft.Children
		b:SetParent(self.aircraft)
		b:Activate()
		b.Phy=b:GetPhysicsObject()
		self.bombs[#self.bombs+1]=b
		self:AddOnRemove(b)
		self.bulletIndex = self.bulletIndex + 1
		self:takeAmmo(-1)
		if ( self.bulletIndex > #self.ActiveBelt ) then
			self.bulletIndex = 1
		end

	end
	self.Ammo = #self.bombs
end

function ENT:trigger(b, seat)
	self.shouldShoot = b
	self.seat = seat
end

function ENT:fire()
	if self.Sequential then
		self.currentPod = self.currentPod or 1
		self:DropBomb(self.bombs[self.currentPod])
		self.currentPod = (self.currentPod == #self.bombs and 1 or self.currentPod + 1)
	else
		for k,v in pairs(self.bombs) do
			self:DropBomb(v)
		end
	end
end

function ENT:DropBomb(bomb)
	if !self:takeAmmo(1) then return end
	if not IsValid(bomb) then return end
	bomb:SetParent(nil)
	bomb:ActivateFuse()
	bomb.AircraftFiring = self.aircraft
	bomb.EntFilter = self.aircraft.Children
	bomb.Owner = self.seat:GetDriver()
	bomb.Phy:AddVelocity(self.aircraft:GetVelocity()*0.256)
	self.aircraft:EmitSound(self.FireSound)
	self:MuzzleEffect(bomb:GetPos(), 128, bomb:GetAngles())
end

function ENT:MuzzleEffect(pos, size)
	local effectdata = EffectData()
	effectdata:SetEntity(self)
	effectdata:SetNormal(self:GetForward())
	effectdata:SetOrigin(pos)
	effectdata:SetScale(1)
	effectdata:SetRadius(size)
	util.Effect("hvap_rocket_trail", effectdata)
end

function ENT:stop()

end

function ENT:select(bool)
	if !bool then
		self:stop()
	end
end

function ENT:takeAmmo(amount)
	if self:GetAmmo() < amount then return false end
	self:SetAmmo(math.Clamp(self:GetAmmo() - amount,0,self.Ammo))
	return true
end

function ENT:Think()

	self:SetSecondary((self:GetAmmo()/self.Ammo)*1000)
		
	if IsValid(self.seat) and self.shouldShoot and self:GetNextShot() <= CurTime() and self:GetAmmo() > 0 then
		if !IsValid(self.seat:GetDriver()) then
			self.shouldShoot = false
		else
			self:fire()
			self:SetLastShot(CurTime())
			self:SetNextShot(self:GetLastShot() + 60/self.FireRate)		
		end
	end

	if self:GetNextShot() <= CurTime() then
		self:stop()
	end
	self:NextThink(CurTime())
	return true
end
