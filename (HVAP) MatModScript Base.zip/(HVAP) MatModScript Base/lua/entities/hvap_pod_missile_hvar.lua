AddCSLuaFile()

ENT.Base = "hvap_pod_missile_base"
ENT.Type = "point"

ENT.PrintName = "HVAR"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "HVAR"
ENT.FireRate = 600

ENT.Belt = 1

ENT.FireSound ="HVAP.Rocket.HVAR"

ENT.AmmoBelt = {
	{
		"he",
	},
}

ENT.AmmoData = {
	["he"] = {
		class = "hvap_bullet_missile_he",
		info = {
			model = "models/missiles/hvar.mdl",
			speed = 419,
			mass = 50,
			Size = 127,
			Fuel = 128,
			Radius = 400,
			Damage = 2560
		}
	},
	
}
