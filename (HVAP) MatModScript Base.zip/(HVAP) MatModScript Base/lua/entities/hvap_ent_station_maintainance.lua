AddCSLuaFile()

ENT.Base = "hvap_ent_station_base"
ENT.Type = "anim"

ENT.PrintName = "Maintainance Station"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 200
ENT.Mass = 800
ENT.Radius = 1024
ENT.TickTime = -1
ENT.Scl = 32
ENT.Model = "models/props_vehicles/generatortrailer01.mdl"

if SERVER then

function ENT:SecondaryInitialize()
	self.CurTick2 = CurTime()
end

function ENT:Think()
	if !self.valid then return end
	local crt = CurTime()
	
	for _, v in pairs(ents.FindInSphere(self:GetPos(), self.Radius)) do
		self:Function(v, crt)
	end
	
	if self.CurTick < crt then
		self.CurTick = crt + 1
	end
	if self.CurTick2 < crt then
		self.CurTick2 = crt + 0.512
	end
	
	if self.health == 0 then
		self:Explode()
	end
	self:NextThink(crt)
	return true	
end

function ENT:Function(ent,crt)
	if IsValid( ent ) and ent.IsHVAP then
		local dist = 1.25-math.Clamp(ent:GetPos():Distance(self:GetPos())/(self.Radius*.75),0,1)

		if ent.AllowFuel then
			ent:Refuel(0.005+0.006*dist,true)
		end	
		
		if ent.AllowAmmo then
			if self.CurTick < crt then
				ent:Rearm(1,true)
			end
		end
		
		if ent.AllowRepair then
			if self.CurTick2 < crt then
				ent:Repair(math.random(2,7)*dist+5,true)
			end	
		end		
	end	
end				
	
end
