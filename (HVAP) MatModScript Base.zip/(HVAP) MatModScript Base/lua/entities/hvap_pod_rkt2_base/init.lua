
include ("shared.lua")
AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")

ENT.Base 				= "base_entity"
ENT.Type 				= "point"

ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:Initialize()
	self:SetNextShot(0)
	self:SetLastShot(0)
	self:SetAmmo(self.Ammo)
	self:SetSecondary(0)
	self.OnRemoveEntities={}
	self.OnRemoveFunctions={}
	self:addSounds()
	self.TargetTime = CurTime()
	self.ActiveBelt = self.AmmoBelt[self.Belt]
	self.CurEffect = CurTime()		
	self.GuidedVector = Vector()
end

function ENT:OnRemove()
	for _,f in pairs(self.OnRemoveFunctions) do
		f()
	end
	for _,e in pairs(self.OnRemoveEntities) do
		if IsValid(e) then e:Remove() end
	end
end

function ENT:getAttacker()
	if IsValid(self.seat) and IsValid(self.seat:GetDriver()) then
		return self.seat:GetDriver()
	end
	return self.aircraft
end

function ENT:trigger(b, seat)
	self.shouldShoot = b
	self.seat = seat
end

function ENT:canFire()
	if self.Guided then return true else
		return IsValid(self:GetTarget())
	end
end

function ENT:fire()
	if self.Sequential then
		self.currentPod = self.currentPod or 1
		self:fireRocket(self.Pods[self.currentPod], self:GetAngles())
		self.currentPod = (self.currentPod == #self.Pods and 1 or self.currentPod + 1)
	else
		for _, pos in pairs(self.Pods) do
			self:fireRocket(pos, self:GetAngles())
		end
	end
	
	if !self.Overheated then
	self.CurrentHeat = math.Clamp((self.CurrentHeat + self.HeatMult),0,1000)
	else end	
	
	if self.CurrentHeat == 1000 then
		self:Overheat()
		self:SetNextShot(self:GetLastShot() + 60/self.FireRate)
	return else 	
	
	end
end

function ENT:fireRocket(pos)
	if !self.CanShoot or !self:takeAmmo(1) or !self.seat then return end
	local pos2;
	local ang;

	if self.IsAimed then
		local gun = self.aircraft.turrets[self.Turret][self.Pod][self.Attach]
		pos2 = gun:LocalToWorld(pos)
		ang = gun:GetAngles()+Angle(math.Rand(-self.Spread,self.Spread),math.Rand(-self.Spread,self.Spread),0)
	else
		pos2 = self.aircraft:LocalToWorld(pos)
		ang = self.aircraft:GetAngles()+Angle(math.Rand(-self.Spread,self.Spread),math.Rand(-self.Spread,self.Spread),0)	
	end
	math.randomseed( pos2:Length() )

	local bt = self.AmmoData[self.ActiveBelt[ self.bulletIndex  ] ]

	b=ents.Create(bt.class)
	for k, v in pairs(bt.info) do
		b[k] = v
	end
	b.airvel=self.IsAimed and Vector() or self.aircraft:GetVelocity()*0.256
	b:SetPos(pos2)
	b:SetAngles(ang)
	b.AircraftFiring=self.aircraft
	b.EntFilter = self.aircraft.Children
	b.Owner = self.seat:GetDriver()
	b.Pod = self
	b.Launcher=self.aircraft
	b.Owner = self.seat:GetDriver()

	b.Drag = Vector(0,1,1)
	b.TrailLength = 250
	b.Scale = 1
	b.SmokeDens = 1

	b.Guided = self.Guided

	b.target = self:GetTarget()
	b.targetOffset = self:GetTargetOffset()

	b.calcTarget = function(r)
		if !IsValid(r.target) then
			return r:GetPos() + r:GetForward()*100
		else
			return r.target:LocalToWorld(r.targetOffset)
		end
	end		

	b:Spawn()
	b:Activate()	
	b:StartRocket()	
	
	self:AddOnRemove(b)
	self:MuzzleEffect(pos2, self.Caliber, ang)
	self.aircraft.phys:ApplyForceOffset( (ang:Forward()*math.random(320,400)+VectorRand()*math.random(380,420))*(-self.Punch), pos2 )

	sound.Play( self.Sounds.fire, pos2 )	

	self.bulletIndex = self.bulletIndex + 1
	if ( self.bulletIndex > #self.ActiveBelt ) then
		self.bulletIndex = 1
	end

	constraint.NoCollide(b, self.aircraft, 0, 0)
end

function ENT:MuzzleEffect(pos, size)
	local effectdata = EffectData()
	effectdata:SetEntity(self)
	effectdata:SetNormal(self:GetForward())
	effectdata:SetOrigin(pos)
	effectdata:SetScale(1)
	effectdata:SetRadius(30)
	util.Effect("hvap_rocket_trail", effectdata)
end

function ENT:stop()

end

function ENT:select(bool)
	if !bool then
		self:stop()
	end
end

function ENT:takeAmmo(amount)
	if self:GetAmmo() < amount then return false end
	self:SetAmmo(math.Clamp(self:GetAmmo() - amount,0,self.Ammo))
	return true
end

function ENT:Think()	
	local crt = CurTime()
	if SERVER then
		self:SetSecondary(self.CurrentHeat)
		
		local tr = self.aircraft:GetViewTarget(self.aircraft.Turrets[self.Turret].info.seat)

		if tr then
			if !self.Guided then
				if tr.Hit and !tr.HitWorld and tr.Entity:GetClass() != "hvap_cm_smoke" then
					self:SetTarget(tr.Entity)
					self:SetTargetOffset(tr.Entity:WorldToLocal(tr.HitPos))
					self.TargetTime = crt+0.8
				elseif self.TargetTime <= crt then
					self:SetTarget(nil)
				end
			else
				self.GuidedVector = (tr.HitPos)
			end
		end
	end	
	if !self.Overheated then
		if !self.shooting == true then
		self.CurrentHeat = math.Clamp( self.CurrentHeat - self.CoolDown, 0, 1000 )
		end
	else
		self.CurrentHeat = math.Clamp( self.CurrentHeat - ((1000/self.HeatTime)/66), 0, 1000 )
	end		

	if IsValid(self.seat) and self:canFire() and self.shouldShoot and self:GetNextShot() <= CurTime() and self:GetAmmo() > 0 then
		if !IsValid(self.seat:GetDriver()) then
			self.shouldShoot = false
		else
			self:fire()
			self:SetLastShot(CurTime())
			self:SetNextShot(self:GetLastShot() + 60/self.FireRate)
		end
	end
	
	if self:GetNextShot() <= CurTime() then
		self:stop()
	end
	self:NextThink(CurTime())
	return true
end

function ENT:Overheat()
	self.Overheated = true
	self.CanShoot = false
	sound.Play( self.Sounds.reload, self.aircraft:GetPos() )
	timer.Simple( self.HeatTime, function()
		if self:IsValid() then
			self:SetNextShot(0)
			self:SetLastShot(0)
			self.Overheated = false 
			self.CanShoot = true
		end
	end )
	return true
end
