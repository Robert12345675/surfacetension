
ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.PrintName = "Base Gun"
ENT.Author = hvap.author
ENT.Category = hvap.aircraft.spawnCategory
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Name = "Base"
ENT.Ammo = 0
ENT.FireRate = 600
ENT.Force = 9999999999
ENT.ReloadAmt = 100
ENT.Guided = false
ENT.Belt = 1

ENT.CoolDown = 1
ENT.HeatMult = 1
ENT.HeatTime = 1
ENT.Caliber = 1
ENT.Spread = 1
ENT.SndPitch = 100

ENT.Punch = 10

ENT.Overheated = false
ENT.shooting = false
ENT.SingleFire = false
ENT.bulletIndex = 1

ENT.Sequential = true
ENT.MaxRange = 32000
ENT.CurrentHeat = 0
ENT.CanShoot = true
ENT.ReloadAmt = 1

ENT.CoolDown = 0//ammount taken from heat every sec
ENT.HeatMult = 500//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 4.95//time it takes for unoverheat

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "Ammo");
	self:NetworkVar("Entity", 0, "Target")
	self:NetworkVar("Vector", 0, "TargetOffset")
	self:NetworkVar("Int", 1, "Secondary")
	self:NetworkVar("Float", 0, "LastShot")
	self:NetworkVar("Float", 1, "NextShot")
end

function ENT:AddOnRemove(f)
	if type(f)=="function" then
		table.insert(self.OnRemoveFunctions,f)
	elseif type(f)=="Entity" or type(f)=="Vehicle" then
		table.insert(self.OnRemoveEntities,f)
	end
end

function ENT:addSounds()
	self.sounds = {}
	for k, v in pairs(self.Sounds) do
		if k != "BaseClass" then
			self.sounds[k] = CreateSound(self, v)
		end
	end
end

ENT.Sounds = {
	fire = "",
	reload = ""
}
