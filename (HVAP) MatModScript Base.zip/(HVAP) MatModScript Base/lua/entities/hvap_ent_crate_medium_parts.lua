AddCSLuaFile()

ENT.Base = "hvap_ent_crate_base"
ENT.Type = "anim"

ENT.PrintName = "Medium Parts Crate"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 200
ENT.Mass = 110
ENT.Scl = 11
ENT.Model = "models/props_junk/wood_crate001a.mdl"

if SERVER then

function ENT:Function(cdat)
	if IsValid( cdat.HitEntity ) and cdat.HitEntity.IsHVAP and cdat.HitEntity.AllowRepair then
		cdat.HitEntity:Repair(2)
		sound.Play( "HVAP.Misc.Repair.Small", self:GetPos() )	
		self:Remove()	
	end	
end				
	
end