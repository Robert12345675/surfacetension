AddCSLuaFile()

ENT.Base = "hvap_ent_station_base"
ENT.Type = "anim"

ENT.PrintName = "Small Ammo Station"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 300
ENT.Mass = 500
ENT.Radius = 1024
ENT.TickTime = 1
ENT.Scl = 32
ENT.Model = "models/props_vehicles/generatortrailer01.mdl"

if SERVER then

function ENT:Function(ent)
	if IsValid( ent ) and ent.IsHVAP and ent.AllowAmmo then
		ent:Rearm(1,true)
	end	
end				
	
end
