AddCSLuaFile()

ENT.Base = "hvap_pod_rkt_base"
ENT.Type = "point"

ENT.PrintName = "HYDRA 40"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "HYDRA 40"
ENT.Ammo = 7
ENT.FireRate = 120

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.Caliber = 40
ENT.Spread = 0.1

ENT.Sounds = {
	fire = "HVAP.Rocket.Hydra"
}

ENT.Punch = 5

ENT.AmmoBelt = {
	{
		"he",
	},
}

ENT.AmmoData = {
	["he"] = {
		class = "hvap_bullet_rocket",
		info = {
			mdl = "models/missiles/ffar_40mm.mdl",
			Speed=739,--velocity m/s
			Radius=math.Rand(340,380),
			BallisticDrag	= 20,
			Drift=2,
			Mass=102,--g
			TissueDamage = math.Rand(5400,5480),
			EffectSize = 16,
			Size=70
		}
	}
}
