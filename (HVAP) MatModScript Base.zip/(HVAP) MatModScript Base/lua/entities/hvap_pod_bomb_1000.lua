AddCSLuaFile()

ENT.Base = "hvap_pod_bomb_base"
ENT.Type = "point"

ENT.PrintName = "500kg Bomb"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "500kg Bomb"
ENT.Ammo = 2000
ENT.FireRate = 60

ENT.Belt = 1

ENT.AmmoBelt = {
	{
		"he",
	},
}

ENT.AmmoData = {
	["he"] = {
		class = "hvap_bullet_bomb_he",
		info = {
			model = "models/bombs/an_m66.mdl",
			mass = 1000,
			Radius = 5120,
			Damage = 2560
		}
	},
	
}
