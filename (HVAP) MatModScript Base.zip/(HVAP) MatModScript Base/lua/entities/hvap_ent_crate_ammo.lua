AddCSLuaFile()

ENT.Base = "hvap_ent_crate_base"
ENT.Type = "anim"

ENT.PrintName = "Ammo Crate"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 200
ENT.Mass = 110
ENT.Scl = 14
ENT.Model = "models/Items/ammocrate_smg1.mdl"

if SERVER then

function ENT:Function(cdat)
	if IsValid( cdat.HitEntity ) and cdat.HitEntity.IsHVAP and cdat.HitEntity.AllowAmmo then
		cdat.HitEntity:Rearm()
		sound.Play( "HVAP.Reload.Multi", self:GetPos() )				
		self:Remove()	
	end		
end

end