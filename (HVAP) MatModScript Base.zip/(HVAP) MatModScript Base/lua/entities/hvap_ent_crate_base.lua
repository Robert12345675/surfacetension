AddCSLuaFile()

ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.PrintName = "Crate"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = false
ENT.health = 100
ENT.valid = false
ENT.active = true
ENT.Mass = 200
ENT.Scl = 14
ENT.Model = ""
ENT.HVAP_ENTITY = true

if SERVER then

function ENT:SpawnFunction( ply, tr)
	if (!tr.Hit) then return end	
	local ent=ents.Create(ClassName)
	local ang = ply:EyeAngles()	
	
	ent:SetPos(tr.HitPos+tr.HitNormal*20)
	ent:SetAngles(Angle(tr.HitPos:GetNormal().x,(ply:EyeAngles().y+180),tr.HitPos:GetNormal().z))

	ent:Spawn()
	ent:Activate()
	ent.Owner=ply
	return ent
end

function ENT:Initialize()
	self.Entity:SetModel(self.Model)
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Phy = self.Entity:GetPhysicsObject()
	self.Phy:SetMass(self.Mass)
	self.Phy:Wake()
	self.Basehealth = self.health
	self.LastDamageTaken = 0
	self:SetActive(false)
	self.valid = true
end

function ENT:Think()
	if !self.valid then return end
	local crt = CurTime()
	
	if self.health == 0 then
		self:Explode()
	end

	self:NextThink(crt)
	return true	
end

function ENT:Explode()
	local lasta=(self.LastDamageTaken<CurTime()+6 and self.LastAttacker or self.Entity)
	local effectdata = EffectData()
	effectdata:SetOrigin(self.Entity:GetPos())
	effectdata:SetScale(self.Scl)
	util.Effect("hvap_explode", effectdata)
	sound.Play( "HVAP.Bullet.Explode.Medium", self:GetPos() )
	util.BlastDamage(self.Entity,(IsValid(lasta) and lasta or self.Entity), self.Entity:GetPos(), 250, 300)
	util.ScreenShake( self.Entity:GetPos(), self.Scl, self.Scl, 2.5, 400 )
	self:Remove()
end

function ENT:OnTakeDamage( dmg )
	local crt = CurTime()	
	self.LastAttacker=dmg:GetAttacker()
	self.LastDamageTaken=crt
	self:DamageSelf(dmg:GetDamage())
end

function ENT:Use( act, cal)
	if act.hvap and act.hvap.lastEnter and act.hvap.lastEnter+1 > CurTime() then return end
	self:SetActive(!self.active)
	act.hvap = act.hvap or {}
	act.hvap.lastEnter = CurTime()
end

function ENT:SetActive(b)
	if b then
		if self.active then return end
		self.active = true
		sound.Play( "HVAP.Switch.BeepClick", self:GetPos() )	
		self:SetColor(Color(192,255,192,255))
	elseif self.active then
		self.active=false
		sound.Play( "HVAP.Switch.BoopClick", self:GetPos() )	
		self:SetColor(Color(255,192,192,255))
	end
end

function ENT:PhysicsCollide( cdat, phys )
	if cdat.DeltaTime > 0.5 then
		local mass = cdat.HitObject:GetMass()
		if cdat.HitEntity:GetClass() == "worldspawn" then
			mass = 3200
		end
		local dmg = (math.pow(cdat.Speed, 2)*math.Clamp(mass, 0, 5000))/10000000

		if !dmg or dmg <= 32 then return end	
		self:DamageSelf(dmg)

		if self.active and cdat.Speed > 16 then
			self:Function(cdat)
		end
		
	end	
end

function ENT:DamageSelf(dmg)
	if self.Unbreakable then return end
	self.health = math.Clamp(self.health - dmg/10, 0, self.Basehealth)
end

function ENT:Function()
end

end