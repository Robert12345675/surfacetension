AddCSLuaFile()

ENT.Base = "hvap_ent_crate_base"
ENT.Type = "anim"

ENT.PrintName = "Bomb Crate"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 250
ENT.Mass = 110
ENT.Scl = 20
ENT.Model = "models/items/ammocrate_grenade.mdl"

if SERVER then

function ENT:Function(cdat)
	if IsValid( cdat.HitEntity ) and cdat.HitEntity.IsHVAP and cdat.HitEntity.AllowAmmo then
		cdat.HitEntity:Rearm(2, true, true, false) --(amt, b, phy, rkt)
		sound.Play( "HVAP.Reload.Secondary", self:GetPos() )				
		self:Remove()	
	end		
end

end