AddCSLuaFile()

ENT.Base = "hvap_ent_station_base"
ENT.Type = "anim"

ENT.PrintName = "Small Repair Station"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true

ENT.health = 300
ENT.Mass = 500
ENT.Radius = 1024
ENT.TickTime = 0.512
ENT.Scl = 16
ENT.Model = "models/props_vehicles/generatortrailer01.mdl"

if SERVER then

function ENT:Function(ent)
	if IsValid( ent ) and ent.IsHVAP and ent.AllowRepair then
		local dist = 1.25-math.Clamp(ent:GetPos():Distance(self:GetPos())/(self.Radius*.75),0,1)
		ent:Repair(math.random(2,7)*dist+7,true)
	end	
end				
	
end
