AddCSLuaFile()

ENT.Base = "hvap_ent_station_base"
ENT.Type = "anim"

ENT.PrintName = "Fuel Station"
ENT.Author = hvap.author
ENT.Category = "(HVAP)Maintainance"
ENT.Spawnable = true
ENT.SpawnHeight = 64
ENT.health = 100
ENT.Mass = 500
ENT.Radius = 1024
ENT.TickTime = -1
ENT.Scl = 32
ENT.Model = "models/props_wasteland/horizontalcoolingtank04.mdl"

if SERVER then

function ENT:Function(ent)
	if IsValid( ent ) and ent.IsHVAP and ent.AllowFuel then
		local dist = 1.25-math.Clamp(ent:GetPos():Distance(self:GetPos())/(self.Radius*.75),0,1)
		ent:Refuel(0.005+0.006*dist,true)
	end	
end

end
