AddCSLuaFile()

ENT.Base = "hvap_pod_missile_base"
ENT.Type = "point"

ENT.PrintName = "RS-82"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "RS-82"
ENT.FireRate = 600

ENT.Belt = 1

ENT.FireSound ="HVAP.Rocket.HVAR"

ENT.AmmoBelt = {
	{
		"he",
	},
}

ENT.AmmoData = {
	["he"] = {
		class = "hvap_bullet_missile_he",
		info = {
			model = "models/missiles/rs82.mdl",
			speed = 340,
			mass = 50,
			Size = 82,
			Fuel = 100,
			Radius = 300,
			Damage = 1600
		}
	},
	
}
