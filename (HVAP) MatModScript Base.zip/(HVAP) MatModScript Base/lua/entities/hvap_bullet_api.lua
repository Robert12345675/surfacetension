
AddCSLuaFile()

ENT.Type 			= "anim"  
ENT.Base 			= "base_anim"     
ENT.PrintName			= "Bullet"  
ENT.Author			= "The_HAVOK"  
ENT.Contact			= "The_HAVOK"  
ENT.Purpose			= ""  
ENT.Instructions		= ""  
 
ENT.Spawnable			= false

ENT.HVAP_ENTITY = true
ENT.valid = false

if CLIENT then

function ENT:Draw()

end

elseif SERVER then

local mats={ --      	 {penetration mult, 1/rico chance}
	[MAT_ALIENFLESH]	={0.5, 5, 5, 5},
	[MAT_ANTLION]		={0.5, 5, 5, 5},
	[MAT_BLOODYFLESH]	={0.5, 5, 5, 5},
	[MAT_FLESH]			={0.5, 5, 5, 5},
	[45]				={0.5, 5, 5, 5},
	[88]				={0.5, 5, 5, 5},

	[MAT_GLASS]			={1.5, 3.5, 3, 4},	
	[MAT_DIRT]			={0.64, 3.5, 2.5, 4},
	[MAT_GRASS]			={0.64, 3, 2.5, 4},
	
	[MAT_WOOD]			={1.28, 4, 3.5, 5},
	[MAT_FOLIAGE]		={1.28, 4, 3.5, 5},
	
	[MAT_SAND]			={0.1, 4, 3.8, 5},
	[MAT_SNOW]			={0.8, 3.7, 3.5, 5},	
	[MAT_SLOSH]			={0.8, 4.2, 4, 5},

	[MAT_PLASTIC]		={1.4, 3.5, 2.56, 4},
	[MAT_TILE]			={1, 3.1, 2, 4},
	[MAT_CONCRETE]		={.95, 3, 1.92, 4},	

	[MAT_METAL]			={1, 1, 0.95, 2},	
	[MAT_CLIP]			={1.28, 1.128, 1, 2},	
	[MAT_COMPUTER]		={1.28, 1.256, 1, 2},	
	[MAT_VENT]			={4, 6, 6, 2},	
	[MAT_GRATE]			={4, 6, 6, 2},	

	[MAT_WARPSHIELD]	={1, 2, 1, 2},
	[MAT_DEFAULT]		={1, 2, 1, 2},
	[MAT_EGGSHELL]		={1, 2, 1, 2},
}

function ENT:Initialize()   
	self:SetRenderMode( RENDERMODE_NONE )
	self:DrawShadow(false)
	self:SetNoDraw(true)	
	math.randomseed(CurTime())
	self.Flightvector 	= self:GetForward()*(self.Speed*52.459*FrameTime())+self.airvel/self.Speed
	self.Timeleft 		= CurTime() + self.Timer
	self.Impacted 		= false
	self.Burnout 		= CurTime() + (self.TracerBurnout or 1.4)
	self:SetColor(col)
	self:SetModel( "models/led.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_NONE )
	self:GetPhysicsObject():SetMass(self.Mass)
	self.Ricochet=0
	self.Penetrated=0
	self.HitWater = false
	self.Mask = CONTENTS_WATER+MASK_SHOT+CONTENTS_EMPTY
	self.airvel = Vector()
	
	self.IsTracer = false
	if hvap.aircraft.cvars.tracers:GetFloat() == 1 then
		if self.Tracer then
			local colmod=math.random(-24,24)
			local col2=Color(math.Clamp((self.col.r)+math.random(-8,8)-colmod, 0, 255),math.Clamp((self.col.g)+math.random(-8,8)-colmod, 0, 255),math.Clamp((self.col.b)+math.random(-8,8)-colmod, 0, 255),255)
			local startWidth = math.Clamp(self.Size/2, 1, 100)
			local length = math.Clamp(1/self.Size, 0.064, 0.1)/2 + 0.06
			local scl = 1/startWidth*0.5
			self.trail=util.SpriteTrail(self, 0, col2, true, startWidth, 0, length, scl, "trails/hvap_tracer.vmt")
			Shine = ents.Create("env_sprite")
			Shine:SetPos(self.Entity:GetPos())
			Shine:SetKeyValue("renderfx", "0")
			Shine:SetKeyValue("rendermode", "5")
			Shine:SetKeyValue("renderamt", "255")
			Shine:SetKeyValue("rendercolor", tostring(col2) )
			Shine:SetKeyValue("framerate12", "20")
			Shine:SetKeyValue("model", "light_glow03.spr")
			Shine:SetKeyValue("scale", tostring(self.Size/100))
			Shine:SetKeyValue("GlowProxySize", "16")
			Shine:SetParent(self.Entity)
			Shine:Spawn()
			Shine:Activate()
			self.IsTracer = true
		end
	end
	self.valid = true
end

function ENT:Think()
	if !self:IsValid() or !self.valid then return end
	
	local crt = CurTime()

	if self.HitWater then
		self.Mask = MASK_SHOT+CONTENTS_EMPTY
	else
		self.Mask = CONTENTS_WATER+MASK_SHOT+CONTENTS_EMPTY
	end	
	
	if self.IsTracer and self.Burnout < crt then
		if self.trail:IsValid() then
			self.trail:Remove()
		end
	end	
	
	if self.SelfDestr then
		if crt > self.Timeleft+math.Rand(-0.32,0.32) then
			self:Airburst()
		end
	elseif crt > self.Timeleft then
		self:Remove()		
	end

	local tr = util.TraceLine({
		start 	= self:GetPos(),
		endpos 	= self:GetPos() + self.Flightvector,
		filter 	= self.EntFilter,
		mask 	= self.Mask
	})
	
	if tr.Hit and !table.HasValue( self.EntFilter, tr.Entity ) then
		self.Mat = math.ceil(tr.MatType)	
		if tr.HitSky then
			self:Remove()
			return true
		end

		if self.Mat==83 and !self.HitWater then
			local effectdata = EffectData()
			effectdata:SetOrigin( tr.HitPos )
			effectdata:SetNormal( tr.HitNormal )
			effectdata:SetScale( self.Size )
			util.Effect( "watersplash", effectdata )
			self.HitWater = true
			return
		end

		local pr = util.TraceLine({
			start 	= tr.HitPos + self.Flightvector:GetNormalized()*(self.Penetrate*mats[self.Mat][1]),
			endpos 	= tr.HitPos,
			filter 	= self.EntFilter,
			mask 	= self.Mask
		})
		
		if pr.Hit then
			self.Penetrate = self.Penetrate-(tr.HitPos:Distance(pr.HitPos)/mats[self.Mat][1])	
		end
		
		if pr.StartSolid or self.Penetrate<=0 or !pr.Hit then
			local Dot = self.Flightvector:GetNormalized():Dot(tr.HitNormal)
			if (1+Dot) > ((math.Rand(0.192,0.32)) * (tr.Entity.IsHVAP and mats[self.Mat][4] or tr.Entity:IsNPC() and mats[self.Mat][4] or tr.Entity:IsPlayer() and mats[self.Mat][4] or self.IsTracer and mats[self.Mat][3] or mats[self.Mat][2]) ) or math.random(0,mats[self.Mat][1]*100) == 1 then
				self.Flightvector = ( (self.Flightvector:Length()*(1+Dot*1.2)) * (self.Flightvector:GetNormalized()+(tr.HitNormal*Dot*-0.8)+(VectorRand()*0.1)) ) + (self.Flightvector*Dot)/10
				self:SetAngles(self.Flightvector:Angle() + Angle(90,0,0))
				self:SetPos(tr.HitPos+tr.HitNormal)
				self:RicochetB(tr, Dot)
			else
				self:Impact(tr)
			end
		else
			self:Pen(pr)
		end
	else
		local movedrift = self.airvel/self.Flightvector:Length()
		self.Flightvector = self.Flightvector - ((self.Flightvector/self.BallisticDrag) + (VectorRand():GetNormalized()*self.Drift))*.512 + Vector(0,0,-30)/self.Flightvector:Length() + Vector(movedrift.x,movedrift.y,0)
		
		if !self.Impacted then
			self:SetPos(self:GetPos() + self.Flightvector)
			self:SetAngles(self.Flightvector:Angle() + Angle(90,0,0))	
		else
			self.Impacted = false
		end
	end
	
	self:NextThink( crt )
	return true
end

function ENT:Impact(tr)
	local effectdata = EffectData()
		effectdata:SetEntity(tr.Entity)
		effectdata:SetMagnitude(self.EffectSize)
		effectdata:SetNormal(tr.HitNormal)
		effectdata:SetOrigin(tr.HitPos)
		effectdata:SetScale(self.Size)
		effectdata:SetStart(self.Flightvector:GetNormalized())
		effectdata:SetSurfaceProp(tr.MatType or 1)
	util.Effect("hvap_bullet_impact_api", effectdata )
	
	self:ApplyDamage(tr, 1)
	self:Remove()
end

function ENT:Airburst()
	local effectdata = EffectData()
		effectdata:SetMagnitude(self.EffectSize)
		effectdata:SetNormal(-self.Flightvector:GetNormalized())
		effectdata:SetOrigin(self:GetPos())
		effectdata:SetScale(self.Size)
	util.Effect("hvap_bullet_airburst", effectdata )
	
	self:ApplyDamage(tr, 1, true)
	self:Remove()
end

function ENT:RicochetB(tr, dot)
	self.Ricochet = self.Ricochet+1
	if self.Ricochet >= 4 then
		self:Impact(tr)
	end		
	local effectdata = EffectData()
		effectdata:SetEntity(tr.Entity)
		effectdata:SetMagnitude(self.EffectSize)
		effectdata:SetNormal(tr.HitNormal)
		effectdata:SetOrigin(tr.HitPos)
		effectdata:SetScale(self.Size)
		effectdata:SetStart(self.Flightvector:GetNormalized())
		effectdata:SetSurfaceProp(tr.MatType or 1)
	util.Effect("hvap_bullet_ricochet", effectdata )
	
	self.Impacted = true
	self:ApplyDamage(tr, math.abs(dot)+0.128)
	self:NextThink( CurTime() )
end

function ENT:Pen(pr)
	self:SetPos(pr.HitPos + self.Flightvector:GetNormalized())
	self.Flightvector = self.Flightvector - (self.Flightvector/self.Penetrate)*1.5
	
	self.Penetrated = self.Penetrated+1
	if self.Penetrated >= 5 then	
		self:Impact(pr)
	end

	local effectdata = EffectData()
		effectdata:SetEntity(pr.Entity)
		effectdata:SetMagnitude(self.EffectSize)
		effectdata:SetNormal(pr.HitNormal)
		effectdata:SetOrigin(pr.HitPos)
		effectdata:SetScale(self.Size)
		effectdata:SetStart(self.Flightvector:GetNormalized())
		effectdata:SetSurfaceProp(pr.MatType or 1)
	util.Effect( "hvap_bullet_penetrate", effectdata )

	self.Impacted = true	
	self:ApplyDamage(pr, 1.28)
	self:NextThink( CurTime() )
end

function ENT:ApplyDamage(trd, div, b)
	if trd and IsValid(trd.Entity) and !b then
		local dmginfo = DamageInfo()
		if (trd.Entity:IsPlayer() or trd.Entity:IsNPC()) then
			util.Decal("blood", trd.HitPos + trd.HitNormal, trd.HitPos - trd.HitNormal)
			if trd.Entity:IsNPC() then
				trd.Entity:SetEnemy( self.AircraftFiring )
				trd.Entity:SetTarget( self.Owner )
			end
		end
		dmginfo:ScaleDamage( div ) 
		dmginfo:SetAttacker( self.Owner )
		dmginfo:SetDamage( self.TissueDamage ) 
		dmginfo:SetDamageForce( self.Flightvector:GetNormalized()*self.Size*8 )
		dmginfo:SetDamagePosition(trd.HitPos)
		dmginfo:SetDamageType( DMG_BULLET )
		dmginfo:SetInflictor( self.AircraftFiring or self.Owner )
		dmginfo:SetReportedPosition( trd.HitPos )
		trd.Entity:TakeDamageInfo( dmginfo )
	end
	util.BlastDamage( self.AircraftFiring, self.Owner, self:GetPos() + self:GetForward()*32, self.Size*2+self.Radius+64, self.TissueDamage+10 )
	util.ScreenShake( IsValid(trd) and trd.HitPos or self:GetPos(), self.Size*2, self.Size, 1.6, self.Size*4+self.Radius+128 )
end

end

function ENT:UpdateTransmitState() return TRANSMIT_PVS end -- TRANSMIT_ALWAYS
