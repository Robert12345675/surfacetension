
AddCSLuaFile()

ENT.Type 			= "anim"  
ENT.Base 			= "base_anim"     
ENT.PrintName			= "Rocket"  
ENT.Author			= "The_HAVOK"  
ENT.Contact			= "The_HAVOK"  
ENT.Purpose			= ""  
ENT.Instructions		= ""  
 
ENT.Spawnable			= false

ENT.HVAP_ENTITY = true
ENT.valid = false

if CLIENT then

function ENT:Draw()            
	self.Entity:DrawModel()
end

elseif SERVER then

function ENT:Initialize()   
	math.randomseed(CurTime())
	self.Flightvector 	= self:GetForward()*(self.Speed*52.459*FrameTime())
	self.Timeleft 		= CurTime() + 10
	self.Impacted 		= false
	self:SetModel( self.mdl )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_FLYGRAVITY )
	self:SetSolid( SOLID_NONE )
	self:GetPhysicsObject():SetMass(1024)
	self:DrawShadow(false)
	self.HitWater = false
	self.Mask = CONTENTS_WATER+MASK_SHOT+CONTENTS_EMPTY
	self.airvel = Vector()
	
	Glow = ents.Create("env_sprite")
	Glow:SetKeyValue("model","orangecore2.vmt")
	Glow:SetKeyValue("rendermode", "5")
	Glow:SetKeyValue("renderamt", "192")
	Glow:SetKeyValue("rendercolor","255 150 100")
	Glow:SetKeyValue("GlowProxySize", self.Size/5)
	Glow:SetKeyValue("scale",self.Size/100)
	Glow:SetPos(self:LocalToWorld(Vector(-18,0,0)))
	Glow:SetParent(self.Entity)
	Glow:Spawn()
	Glow:Activate()

	Shine = ents.Create("env_sprite")
	Shine:SetPos(self:LocalToWorld(Vector(18,0,0)))
	Shine:SetKeyValue("renderfx", "0")
	Shine:SetKeyValue("rendermode", "5")
	Shine:SetKeyValue("renderamt", "192")
	Shine:SetKeyValue("rendercolor", "255 130 100")
	Shine:SetKeyValue("framerate12", "20")
	Shine:SetKeyValue("model", "light_glow03.spr")
	Shine:SetKeyValue("scale",self.Size/100)
	Shine:SetKeyValue("GlowProxySize", self.Size/5)
	Shine:SetParent(self.Entity)
	Shine:Spawn()
	Shine:Activate()
	
	self.valid = true
end   

function ENT:Think()
	if !self:IsValid() or !self.valid then return end
	
	local crt = CurTime()
	
	if self.HitWater then
		self.Mask = MASK_SHOT+CONTENTS_EMPTY
	else
		self.Mask = CONTENTS_WATER+MASK_SHOT+CONTENTS_EMPTY
	end	
	
	if self.Timeleft < crt then
		self:Remove()	
		return true		
	end

	local tr = util.TraceLine({
		start 	= self:GetPos(),
		endpos 	= self:GetPos() + self.Flightvector,
		filter 	= self.EntFilter,
		mask 	= self.Mask
	})
	
	if tr.Hit and !table.HasValue( self.EntFilter, tr.Entity ) then
		self.Mat = math.ceil(tr.MatType)	
		
		if tr.HitSky then
			self:Remove()
			return true
		end
		
		if self.Mat==83 and !self.HitWater then
			local effectdata = EffectData()
			effectdata:SetOrigin( tr.HitPos )
			effectdata:SetNormal( tr.HitNormal )
			effectdata:SetScale( self.Size )
			util.Effect( "watersplash", effectdata )
			self.HitWater = true
			return
		end		
		
		self:Impact(tr)
	else
		local movedrift = self.airvel/self.Flightvector:Length()
		self.Flightvector = self.Flightvector - ((self.Flightvector/self.BallisticDrag) + (VectorRand():GetNormalized()*self.Drift))*.512 + Vector(0,0,-30)/self.Flightvector:Length() + Vector(movedrift.x,movedrift.y,0)
		
		if !self.Impacted then
			self:SetPos(self:GetPos() + self.Flightvector)
			self:SetAngles(self.Flightvector:Angle())	
		else
			self.Impacted = false
		end
	end

	self:NextThink( crt )
	return true
end

function ENT:Impact(tr)
	local effectdata = EffectData()
		effectdata:SetEntity(tr.Entity)
		effectdata:SetMagnitude(self.EffectSize)
		effectdata:SetNormal(tr.HitNormal)
		effectdata:SetOrigin(tr.HitPos)
		effectdata:SetScale(self.Size)
		effectdata:SetStart(self.Flightvector:GetNormalized())
		effectdata:SetSurfaceProp(tr.MatType or 1)
	util.Effect("hvap_rocket_explode", effectdata )
	util.BlastDamage( self.AircraftFiring or self, self.Owner or self, self:GetPos(), self.Radius+64, self.TissueDamage )
	util.ScreenShake( tr.HitPos, self.Size, self.Size/10, 3.5, self.Radius*1.28+128 )
	self:Remove()
end

end

function ENT:UpdateTransmitState() return TRANSMIT_PVS end -- TRANSMIT_ALWAYS
