AddCSLuaFile()

ENT.Base = "hvap_pod_missile_base"
ENT.Type = "point"

ENT.PrintName = "R4M"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "R4M"
ENT.FireRate = 500

ENT.Belt = 1

ENT.FireSound ="HVAP.Rocket.HVAR"

ENT.AmmoBelt = {
	{
		"he",
	},
}

ENT.AmmoData = {
	["he"] = {
		class = "hvap_bullet_missile_he",
		info = {
			model = "models/chappi/r4m.mdl",
			speed = 525,
			mass = 4,
			Size = 55,
			Fuel = 64,
			Radius = 192,
			Damage = 1920
		}
	},
	
}
