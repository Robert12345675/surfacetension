
AddCSLuaFile()

ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.PrintName = "Entity"
ENT.Author = hvap.author
ENT.Category = "HVAP Entity"
ENT.Spawnable = false
ENT.valid = false
ENT.disabled = false
ENT.active = true
ENT.HVAP_ENTITY = true
ENT.aircraft = nil
ENT.Type = nil

function ENT:SetupDataTables()
	self:NetworkVar( "Entity", 0, "Aircraft" )
end

if SERVER then

function ENT:Initialize()
--	self.Entity:SetModel(self.Model)
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Phy = self.Entity:GetPhysicsObject()
	self.Phy:Wake()
	self.Scl = math.Clamp(self.Phy:GetVolume()/1000,4,20)
	self.Basehealth = self.health
	self.LastDamageTaken = 0
	self:SetAircraft(self.aircraft)
	self.valid = true
end

function ENT:Think()
	if self.health == 0 then
		self:Explode()
	end

	return true
end

function ENT:Explode()
	if self.Unbreakable then return end
	local lasta=(self.LastDamageTaken<CurTime()+6 and self.LastAttacker or self.Entity)
	local effectdata = EffectData()
	effectdata:SetOrigin(self.Entity:GetPos())
	effectdata:SetScale(self.Scl)
	util.Effect("hvap_explode", effectdata)
	util.BlastDamage(self.Entity,(IsValid(lasta) and lasta or self.Entity), self.Entity:GetPos(), 250, 300)
	self:Remove()
end

function ENT:OnTakeDamage( dmg )
	if self.Unbreakable then return end
	local crt = CurTime()	
	self.LastAttacker=dmg:GetAttacker()
	self.LastDamageTaken=crt
	self:DamageSelf(dmg:GetDamage(), dmg:GetAttacker())
end

function ENT:PhysicsCollide( cdat, phys )
	if self.Unbreakable then return end
	if cdat.DeltaTime > 0.5 then
		local mass = cdat.HitObject:GetMass()
		if cdat.HitEntity:GetClass() == "worldspawn" then
			mass = 3200
		end
		local dmg = (math.pow(cdat.Speed, 2)*math.Clamp(mass, 0, 5000))/10000000
		
		if dmg >= 32 then
			self:DamageSelf(dmg, lasta)	
		end
		if self.Type == "Wheel" then
			if dmg >= 40 then
				sound.Play( "Rubber_Tire.ImpactHard", self:GetPos() )				
			elseif dmg >= 20 then
				sound.Play( "Rubber_Tire.ImpactSoft", self:GetPos() )				
			end
		else
			if dmg >= 32 then
				sound.Play( "HVAP.Vehicle.Collide", self:GetPos() )	
			end
		end
	end	
end

function ENT:DamageSelf(dmg, lasta)
	if self.Unbreakable then return end

	self.health = math.Clamp(self.health - dmg/2, 0, self.Basehealth)
end

end
