if wac then
	MsgC( Color( 255, 0, 0 ), "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )
	PrintMessage( HUD_PRINTCENTER, "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )
	PrintMessage( HUD_PRINTTALK, "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )	
return end

include("shared.lua")
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("hvap/aircraft.lua")

util.AddNetworkString("hvap.aircraft.updateWeapons")
util.AddNetworkString("hvap.aircraft.updateCamera")

function ENT:Initialize()
	hvap.aircraft.initialize()
	self.Entity:SetModel(self.Model)
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.phys = self:GetPhysicsObject()
	if self.phys:IsValid() then
		self.phys:SetMass(self.Weight)
		self.phys:EnableDrag(false)
		self.phys:Wake()
	end		
	
	local skins = self:SkinCount()	
	if skins != 1 then
		skin = math.random(skins)
		self:SetSkin(skin)
	end		
	
	self.BBoxRadius = self.Entity:BoundingRadius()
	
	self.Children = {}
	self.CamData = {}
		
	self.OnRemoveEntities={}
	self.OnRemoveFunctions={}
	self.wheels = {}
	
	self.nextUpdate = 0
	self.LastDamageTaken = 0
	self.hvap_seatswitch = true
	self.LastPhys = 0

	self.FuselageHPMult = hvap.aircraft.cvars.fhealthmul:GetFloat()

	if self.FuselageHPMult > 0 then
		self.FuselageHealth = self.FuselageHealth*self.FuselageHPMult
		self.Unbreakable = false
	else
		self.Unbreakable = true
	end
	
	self.FuselageBaseHealth = self.FuselageHealth
	self.CriticalHealth = self.FuselageBaseHealth*10
	self.CriticalBaseHealth = self.CriticalHealth
	self.FSCL = 1

	self.passengers = {}
	
	self.disabled = false
	self.dead = false
	self.CriticalDeath = false
	
	self:addSounds()

	self:addWeapons()
	self:addCountermeasures()

	self:addSeats()
	self:addNpcTargets()
	self:addTurrets()	
	self:addExtras()
	
	if self.HasDoors and self.DoorFlip then
		self:SetBodygroup(self.DoorBodygroup, 1)	
	end
	self.DoorIsOpen = true
	
	local effectdata = EffectData()
	effectdata:SetEntity( self )
	util.Effect( "hvap_spawn", effectdata, true, true )		
	table.insert(self.Children, self)
end

function ENT:SpawnFunction( ply, tr, ClassName )

	if ( !tr.Hit ) then return end

	local SpawnPos = tr.HitPos + tr.HitNormal * self.SpawnHeight
	local SpawnAng = ply:EyeAngles()
	SpawnAng.p = 0
	SpawnAng.y = SpawnAng.y + 180

	local ent = ents.Create( ClassName )
	ent:SetCreator( ply )
	ent:SetPos( SpawnPos )
	ent:SetAngles( SpawnAng )
	ent:Spawn()
	ent:Activate()
	ent.Owner=ply
	ent.SpawnedBy=ply

	return ent

end

function ENT:addEntity(name, nofx)
	local e = ents.Create(name)
	if !IsValid(e) then return nil end

	if !nofx then
		local effectdata = EffectData()
		effectdata:SetEntity( e )
		util.Effect( "hvap_spawn", effectdata, true, true )
	end

	table.insert(self.Children, e)
	e.Owner = self.Owner
	e:SetNWEntity("hvap_aircraft", self)
	e.aircraft = self
	return e
end

function ENT:UpdateTransmitState() return TRANSMIT_ALWAYS end

function ENT:addNpcTargets()
	for _,s in pairs(self.HatingNPCs) do
		self:Fire("SetRelationShip", s.." D_HT 99")
	end
end

function ENT:addWeapons()
	self.weapons = {}
	self.weapons2 = {}
	for i, w in pairs(self.Weapons) do
		if i != "BaseClass" then
			local pod = ents.Create(w.class)
			pod:SetPos(self:GetPos()+Vector(0,0,32))
			pod:SetAngles(self:GetAngles())
			pod:SetParent(self)
			for index, value in pairs(w.info) do
				pod[index] = value
			end
			pod.aircraft = self
			pod:Spawn()
			pod:Activate()
			pod:SetNoDraw(true)
			pod:SetNWEntity("hvap_aircraft", self)
			pod.podIndex = i
			self.weapons[i] = pod
			self:AddOnRemove(pod)
			table.insert(self.Children, pod)
		end
	end

	for i, w in pairs(self.Weapons2) do
		if i != "BaseClass" then
			local pod2 = ents.Create(w.class)
			pod2:SetPos(self:GetPos()+Vector(0,0,32))
			pod2:SetAngles(self:GetAngles())
			pod2:SetParent(self)
			for index, value in pairs(w.info) do
				pod2[index] = value
			end
			pod2.aircraft = self
			pod2:Spawn()
			pod2:Activate()
			pod2:SetNoDraw(true)
			pod2:SetNWEntity("hvap_aircraft", self)
			pod2.podIndex = i
			self.weapons2[i] = pod2
			self:AddOnRemove(pod2)
			table.insert(self.Children, pod2)
		end
	end
end

function ENT:addSeats()
	self.seats = {}
	local e = self:addEntity("hvap_seat_connector", true)
	e:SetPos(self:LocalToWorld(self.SeatSwitcherPos))
	e:SetNoDraw(true)
	e:Spawn()
	e:Activate()
	e.hvap_ignore = true
	e:SetNotSolid(true)
	e:SetParent(self)
	self:SetSwitcher(e)
	for k, v in pairs(self.Seats) do
		if k != "BaseClass" then
			local ang = self:GetAngles()
			self.seats[k] = self:addEntity("prop_vehicle_prisoner_pod", true)
			self.seats[k].activeProfile = 1
			self.seats[k]:SetModel("models/nova/airboat_seat.mdl")
			self.seats[k]:SetPos(self:LocalToWorld(v.pos))
			self.seats[k]:Spawn()
			self.seats[k]:Activate()
			self.seats[k]:SetNWInt("selectedWeapon", 0)
			if v.ang then
				local a = self:GetAngles()
				a.y = a.y-90
				a:RotateAroundAxis(Vector(0,0,1), v.ang.y)
				self.seats[k]:SetAngles(a)
			else
				ang:RotateAroundAxis(self:GetUp(), -90)
				self.seats[k]:SetAngles(ang)
			end
			self.seats[k]:SetNoDraw(true)
			self.seats[k]:SetNotSolid(true)
			self.seats[k]:SetParent(self)
			self.seats[k]:SetKeyValue( "limitview", 0 )
			self:SetNWInt("seat_"..k.."_actwep", 1)
			self:SetNWInt("seat_"..k.."_actwep2", 1)
			e:addVehicle(self.seats[k])
		end
	end
end

function ENT:addTurrets()
	self.turrets = {}
	
	if !self.Turrets then return end
	for k, v in pairs(self.Turrets) do
		local pods = {}
		local info = {}
		for podk, podv in pairs(v.pods) do
			local part = {}
			for partk, partv in pairs(podv) do
				local t = self:addEntity("hvap_turret")			
				t:SetPos(self:LocalToWorld(partv.pos))
				t:SetAngles(self:GetAngles())
				t:SetModel(partv.model)
				t:SetParent(self)
				for index, value in pairs(partv) do
					t[index] = value
				end	
				t:Spawn()
				t:Activate()
				t.restrictPitch = partv.restrictPitch
				t.restrictYaw = partv.restrictYaw
				t.offset = partv.offset
				t.Turret = k
				self:AddOnRemove(t)
				self:SetNWEntity("hvap_"..k.."_"..podk.."_"..partk, t)
--				print("hvap_"..k.."_"..podk.."_"..partk)
				part[partk] = t
			end
			pods[podk] = part
		end
		self.turrets[k] = pods
		for infok, infov in pairs(v.info) do
			info[infok] = infov
		end
		self.turrets[k].info = info
	end

end
 
function ENT:addExtras()
	if self.Extras then
		for k, v in pairs(self.Extras) do
			local e = self:addEntity("prop_physics")			
			e:SetPos(self:LocalToWorld(v.pos))
			e:SetAngles(self:GetAngles()+v.ang)
			e:SetModel(v.model)
			e:SetNotSolid(true)
			e:SetParent(self)
			e:Spawn()
			local ph = e:GetPhysicsObject()
			ph:SetMass(1)
			ph:EnableDrag(false)
			ph:EnableGravity(false)
			e:Activate()
			self:AddOnRemove(e)
		end
	end
end

function ENT:addCountermeasures()
	for i, w in pairs(self.CounterMeasures) do
		if i != "BaseClass" then
			local pod = ents.Create(w.class)
			pod:SetPos(self:GetPos())
			pod:SetAngles(self:GetAngles())
			pod:SetParent(self)
			for index, value in pairs(w.info) do
				pod[index] = value
			end
			pod.aircraft = self
			pod.entTable = self.OnRemoveEntities
			pod:Spawn()
			pod:Activate()
--			pod:SetNWEntity("hvap_aircraft", self)
			pod:SetNoDraw(true)
			self.countermeasure = pod
			self:AddOnRemove(pod)
		end
	end
end

function ENT:MakeGibs()
	if !self.Gibs then return end
	for k, v in pairs(self.Gibs) do
		if k != "BaseClass" then
			local gib = ents.Create("hvap_entity")
			gib:SetModel(t.mdl)
			gib:SetPos(self:LocalToWorld(t.pos))
			gib:SetAngles(self:GetAngles())
			gib.health = self.FuselageHealth/2
			gib.Unbreakable = false
			gib.Type = "Gib"
			gib:Spawn()
			gib:Activate()
			local ph=gib:GetPhysicsObject()
				ph:SetMass(t.mass)
				ph:EnableDrag(false)
		end
	end
end

function ENT:fireWeapon1(bool, i)
	if !self.Seats[i].weapons then return end
	local pod = self.weapons[self.Seats[i].weapons[self.seats[i].activeProfile]]
	if !pod then return end
	pod.shouldFire = bool
	pod:trigger(bool, self.seats[i])
--	self.Entity:SetPoseParameter("minigun_fire", 12)
end

function ENT:fireWeapon2(bool, i)
	if !self.Seats[i].weapons2 then return end
	local pod = self.weapons2[self.Seats[i].weapons2[self.seats[i].activeProfile]]
	if !pod then return end
	pod.shouldFire = bool
	pod:trigger(bool, self.seats[i])
end

function ENT:fireCounter(bool, i)
	if !self.CounterMeasures then return end
	local pod = self.countermeasure
	if !pod then return end
	pod.shouldFire = bool
	pod:trigger(bool, self.seats[1])
end

function ENT:nextWeapon(i, p)
	if !self.Seats[i].weapons then return end
	local seat = self.seats[i]
	local Seat = self.Seats[i]

	local pod = self.weapons[Seat.weapons[seat.activeProfile]]
	if pod then
		pod:select(false)
		pod.seat = nil
	end
	
	if self.Seats[i].weapons2 then
		local pod2 = self.weapons2[Seat.weapons2[seat.activeProfile]]
		if pod2 then
			pod2:select(false)
			pod2.seat = nil
		end
	end

	if seat.activeProfile == #Seat.weapons then
		seat.activeProfile = 0
	else
		seat.activeProfile = seat.activeProfile + 1
	end
	if Seat.weapons[seat.activeProfile] then
		local weapon = self.weapons[Seat.weapons[seat.activeProfile]]
		weapon:select(true)
		weapon.seat = seat
	end
	
	self:SetNWInt("seat_"..i.."_actwep", seat.activeProfile)
	if self.Seats[i].weapons2 then
		if Seat.weapons2[seat.activeProfile] then
			local weapon = self.weapons2[Seat.weapons2[seat.activeProfile]]
			weapon:select(true)
			weapon.seat = seat
		end
		self:SetNWInt("seat_"..i.."_actwep2", seat.activeProfile)
	end
end

function ENT:EjectPassenger(ply,idx,t)
	if !idx then
		for k,p in pairs(self.passengers) do
			if p==ply then idx=k end
		end
		if !idx then
			return
		end
	end
	ply.LastVehicleEntered = CurTime()+0.5
	ply:ExitVehicle()
	ply:SetPos(self:LocalToWorld(self.Seats[idx].exit))
	ply:SetVelocity(self:GetPhysicsObject():GetVelocity()*1.6)
	ply:SetEyeAngles((self:LocalToWorld(self.Seats[idx].pos-Vector(0,0,40))-ply:GetPos()):Angle())
	self:updateSeats()
end

function ENT:Bail(ply,idx,t)
	self:EjectPassenger(ply,idx,t)
end

function ENT:Use(act, cal)
	if self.disabled then return end
	if act.hvap and act.hvap.lastEnter and act.hvap.lastEnter+0.5 > CurTime() then return end
	local d = self.MaxEnterDistance
	local v
	local num
	for k, veh in pairs(self.seats) do
		if veh and veh:IsValid() then
			local psngr = veh:GetPassenger(0)
			if !psngr or !psngr:IsValid() then
				local dist = veh:GetPos():Distance(util.QuickTrace(act:GetShootPos(),act:GetAimVector()*self.MaxEnterDistance,act).HitPos)
				if dist < d then
					d = dist
					v = veh
					num = k
				end
			end
		end
	end
	act.hvap = act.hvap or {}
	act.hvap.lastEnter = CurTime()
	if v and num < 3 then
		act:EnterVehicle(v)
	elseif v and num >= 3 then
		if self.DoorIsOpen then
			act:EnterVehicle(v)
		else
			sound.Play( "HVAP.Gun.Misc.NoSecondary", act:GetPos() )
		end
	end
	self:updateSeats()
end

function ENT:updateSeats()
	if !self.seats then return end
	for k, veh in pairs(self.seats) do
		if !veh:IsValid() then return end
		local p = veh:GetPassenger(0)
		if self.passengers[k] != p then
			if IsValid(self.passengers[k]) then
				self.passengers[k]:SetNWEntity("hvap_aircraft", NULL)
			end
			self:SetNWEntity("passenger_"..k, p)
			self.passengers[k] = p
			if IsValid(p) then
				p:SetNWInt("hvap_passenger_id",k)
				p.hvap = p.hvap or {}
				p.hvap.mouseInput = true
				p.hvap.viewAngs = Angle()
				net.Start("hvap.aircraft.updateWeapons")
				net.WriteEntity(self)
				net.WriteInt(table.Count(self.weapons), 5)
				for name, weapon in pairs(self.weapons) do
					net.WriteString(name)
					net.WriteEntity(weapon)
				end
				
				net.WriteInt(table.Count(self.weapons2), 5)
				for name, weapon2 in pairs(self.weapons2) do
					net.WriteString(name)
					net.WriteEntity(weapon2)
				end				
				
				net.Send(p)
			end

		end
	end
	self:GetSwitcher():updateSeats()
end

function ENT:StopAllSounds()
	for k, s in pairs(self.sounds) do
		s:Stop()
	end
end

function ENT:RocketAlert()
	if self.active and !self.disabled and !self.Unbreakable then
		local b=false
		local rockets = ents.FindByClass("hvap_bullet_rocket2")
		for _, e in pairs(rockets) do
			if  e:GetPos():Distance(self:GetPos()) < 7680 and e.target == self then b = true break end
		end
		if self.sounds.MissileAlert:IsPlaying() then
			if !b then
				self.sounds.MissileAlert:Stop()
				self.Targeted = false
			end
		elseif b then
			self.sounds.MissileAlert:Play()
			self.Targeted = true
		end
	end
end

function ENT:Think()
	local crt = CurTime()
	local frt = FrameTime()

	local vel = self.phys:GetVelocity()	
--	local spd = math.Round(vel:Length()*0.068796244/2,1)
	local pos = self:GetPos()
	local ang = self:GetAngles()

------------------------------------------------------------------------------------------------	
	self.FSCL = math.Clamp(self.FuselageHealth/self.FuselageBaseHealth,0,1)	
------------------------------------------------------------------------------------------------
	if self.nextUpdate<crt then
		self:RocketAlert()
		self.Refueling = false
		self.nextUpdate = crt+0.2
	end
------------------------------------------------------------------------------------------------
	if !self.dead and self.FSCL == 0 then	
		if hvap.aircraft.cvars.kickdeath:GetInt() == 1 then
			for i = 1, #self.seats do
				if self.passengers[i]:IsValid()	then
					self:Bail(self.passengers[i])
				end
			end
		end	
		local effectdata = EffectData()
			effectdata:SetOrigin(self.Entity:GetPos())
			effectdata:SetScale((self.FuselageBaseHealth/self.FuselageHPMult)/42)
		util.Effect("hvap_explode", effectdata)
		util.BlastDamage(self.Entity, self.Entity, self:GetPos(), (self.FuselageBaseHealth/self.FuselageHPMult)*2, (self.FuselageBaseHealth/self.FuselageHPMult)/4)
		self.dead = true
		self.active = false
	end	
------------------------------------------------------------------------------------------------
	if self.CriticalDeath then
		local effectdata = EffectData()
			effectdata:SetOrigin(self.Entity:GetPos())
			effectdata:SetScale(self.FuselageBaseHealth/28)
		util.Effect("hvap_explode", effectdata)
		util.BlastDamage(self.Entity, self.Entity, self:GetPos(), (self.FuselageBaseHealth/self.FuselageHPMult)*4, (self.FuselageBaseHealth/self.FuselageHPMult))
		self:MakeGibs()
		self:Remove()
	end
------------------------------------------------------------------------------------------------
	if self.skin != self:GetSkin() then
		self.skin = self:GetSkin()
		self:updateSkin(self.skin)
	end	
------------------------------------------------------------------------------------------------
	self:updateSeats()	
	self:TurretThink()
	self:setVar("Targeted", self.Targeted, true)
	self:setVar("fhp", self.FSCL)	
	self:NextThink(crt)
	return true
end

function ENT:TurretThink()
	if !self.Turrets or !self.turrets then return end
	for k, v in pairs(self.turrets) do
		for key, value in pairs(v) do
			local seat = v.info.seat
			if key != "info" then
				for _, t in pairs(value) do
					if IsValid(t) then
						local tr = self:GetViewTarget(seat, pos, ang)
						if tr then 
							local localAng = self:WorldToLocalAngles( ( tr.HitPos - t:GetPos() ):Angle() )
							localAng = Angle(t.pitch and localAng.p or 0, t.yaw and localAng.y or 0, t.angle.r or 0)
							local setangles = LerpAngle(self.RotSPD,t:GetAngles(),self:LocalToWorldAngles(localAng))
							if t.localto and t.offset then
								local localtoent = self.turrets[k][key][t.localto]
								t:SetPos(localtoent:LocalToWorld(t.offset))
							end
							t:SetAngles(setangles)
						end
					end
				end
			end
		end
	end
end

function ENT:setVar(name, var, b)
	if b then
		if self:GetNWBool(name) != var then
			self:SetNWBool(name, var)
		end	
	else
		if self:GetNWFloat(name) != var then
			self:SetNWFloat(name, var)
		end
	end
end

function ENT:receiveInput(name, value, seat)--CONTROLS
	if seat == 1 then
		if name == "Start" and value>0.5 then

		elseif name == "Throttle" then

		elseif name == "Pitch" then

		elseif name == "Yaw" then

		elseif name == "Roll" then

		elseif name == "Hover" and value>0.5 then

		elseif name == "FreeView" then
			self.passengers[seat].hvap.mouseInput = (value < 0.5)
		elseif name == "CounterMeasure" then
			self:fireCounter(value > 0.5)
		elseif name == "Function" and value>0.5 and self.HasDoors then 
			self:Doors(!self.DoorOpen)
		elseif name == "Function2" and value>0.5 then 

		elseif name == "Gear" and value>0.5 and self.HasGear then

		end
	end
	
	if name == "Exit" and value>0.5 and self.passengers[seat].hvap.lastEnter<CurTime()-0.5 then
		self:EjectPassenger(self.passengers[seat])
	elseif name == "Bail" and value>0.5 and self.passengers[seat].hvap.lastEnter<CurTime()-0.5 then
		self:Bail(self.passengers[seat])
	elseif name == "FirstFire" then
		self:fireWeapon1(value > 0.5, seat)
	elseif name == "SecondFire" then
		self:fireWeapon2(value > 0.5, seat)
	elseif name == "NextWeapon" and value > 0.5 then
		self:nextWeapon(seat, self.passengers[seat])
	end
end

function ENT:GetSeat(player)
	for i, p in pairs(self.passengers) do
		if p == player then
			return self.seats[i]
		end
	end
end

function ENT:PhysicsUpdate(ph)
--[[
	local vel = ph:GetVelocity()	
	local vell = math.Round(vel:Length()*0.068796244/2,1)
	local pos = self:GetPos()
	local ang = self:GetAngles()
	local lvel = self:WorldToLocal(pos+vel)
	local up = self:GetUp()
	local phm = FrameTime()*66
	local spinout = Vector(0,0,0)
	local spinoutv = Vector(0,0,0)
]]
end

function ENT:Rearm(amt, b)
	if b then 
		if self.Weapons2 then
			for k, v in pairs(self.weapons2) do
				if v:GetAmmo() < v.Ammo then
					v:takeAmmo( -v.ReloadAmt*amt )
					sound.Play( "HVAP.Reload.Pickup", self:GetPos() )	
				end
			end
		end
		if self.Weapons then
			for k, v in pairs(self.weapons) do
				if v:GetAmmo() < v.Ammo then
					v:takeAmmo( -v.ReloadAmt*amt )
					sound.Play( "HVAP.Reload.Pickup", self:GetPos() )	
				end
			end
		end
	else
		if self.Weapons2 then
			for k, v in pairs(self.weapons2) do
				if v:GetAmmo() != v.Ammo then
					v:SetAmmo(v.Ammo)
				end
			end
		end
		if self.Weapons then
			for k, v in pairs(self.weapons) do
				if v:GetAmmo() != v.Ammo then
					v:SetAmmo(v.Ammo)
				end
			end
		end
	end
end

function ENT:Repair(amt, b)
	if b then
		if self.FuselageHealth < self.FuselageBaseHealth then
			self.FuselageHealth = math.Clamp(self.FuselageHealth + amt, 0, self.FuselageBaseHealth )
			sound.Play( "HVAP.Misc.Repair.Small", self:GetPos() )	
		end
		if self.disabled then
			self.disabled = false
		end
		if self.dead then
			self.dead = false
		end	
	else
		if self.FuselageHealth < self.FuselageBaseHealth then
			self.FuselageHealth = math.Clamp(self.FuselageHealth + self.FuselageBaseHealth/amt, self.FuselageBaseHealth/amt, self.FuselageBaseHealth )
		end
		if self.disabled then
			self.disabled = false
		end
		if self.dead then
			self.dead = false
		end
	end
end

function ENT:PhysicsCollide(cdat, phys)
	if cdat.DeltaTime > 0.5 then
		local mass = cdat.HitObject:GetMass()
		if cdat.HitEntity:GetClass() == "worldspawn" then
			mass = 3200
		end
		local dmg = (math.pow(cdat.Speed, 2)*math.Clamp(mass, 0, 5000))/10000000
		
		if !dmg or dmg <= 32 then return end	
		
		local lasta=(self.LastDamageTaken<CurTime()+6 and self.LastAttacker or self.Entity)
		for k, p in pairs(self.passengers) do
			if p and p:IsValid() then
				p:TakeDamage(dmg/16, lasta, self.Entity)
			end
		end			
		self:DamageFuselage(dmg, lasta)
		sound.Play( "HVAP.Vehicle.Collide", self:GetPos() )		
	end
end

function ENT:OnTakeDamage(dmg)
	if self.Unbreakable then return end
	local crt = CurTime()	
	self.LastAttacker=dmg:GetAttacker()
	self.LastDamageTaken=crt
	
	dmg:ScaleDamage(0.256)	
	
	local pos=self:WorldToLocal(dmg:GetDamagePosition())
	local dmgVal = dmg:GetDamage()
	local driver = self:getPassenger()
	local lasta=(self.LastDamageTaken<crt+6 and self.LastAttacker or self.Entity)	
-------------------------pilot snipe calc
	if hvap.aircraft.cvars.noplayerdamage:GetInt() != 1 then
		for k, p in pairs(self.passengers) do
			local dist = pos:Distance(self.Seats[k].pos)
			if p and p:IsValid() and dist<=(self.PlyDmgDist*1.92) then
				local pdmg = (dmgVal/dist)*self.PlyDmgMult
				p:TakeDamage(pdmg, lasta, self.Entity)
			end
		end
	end
	self:DamageFuselage(dmgVal/2, lasta)
end

function ENT:DamageFuselage(dmg, lasta)
	if self.Unbreakable then return end
	local crt = CurTime()

	self.FuselageHealth = math.Clamp(self.FuselageHealth - dmg, 0, self.FuselageBaseHealth)	

	if dmg > 0.01 then
		util.ScreenShake( self:GetPos(), dmg/2.56, 200, 1.6, self.BBoxRadius*2 )		
	end

	if !self.disabled then
		if dmg > 0.01 then			
			if self.FSCL > 0.60 and crt>self.LastDamageTaken+0.28 then
				sound.Play( self.Sounds.Damaged, self:GetPos() )
			elseif self.FSCL > 0.40 and crt>self.LastDamageTaken+0.4 then
				sound.Play( self.Sounds.Alarm75, self:GetPos() )	
			elseif self.FSCL > 0.20 and crt>self.LastDamageTaken+0.5 then
				sound.Play( self.Sounds.Alarm50, self:GetPos() )		
			elseif self.FSCL > 0.20 and crt>self.LastDamageTaken+0.6 then
				sound.Play( self.Sounds.Alarm25, self:GetPos() )
			end
		end 
		if self.FuselageHealth == 0 then	
			self.disabled = true
		end	
	elseif self.dead and !self.CriticalDeath then
		self.CriticalHealth = math.Clamp( self.CriticalHealth - dmg, 0, self.CriticalBaseHealth )
		if self.CriticalHealth == 0 then
			self.CriticalDeath = true
		end
	end
end

function ENT:CPPIGetOwner()
	return self.SpawnedBy
end

function ENT:AddOnRemove(f)
	if type(f)=="function" then
		table.insert(self.OnRemoveFunctions,f)
	elseif type(f)=="Entity" or type(f)=="Vehicle" then
		table.insert(self.OnRemoveEntities,f)
	end
end

function ENT:OnRemove()
	self:StopAllSounds()
	for _,p in pairs(self.passengers) do
		if IsValid(p) then
			p:SetNWInt("hvap_passenger_id",0)
		end
	end
	for _,f in pairs(self.OnRemoveFunctions) do
		f()
	end
	for _,e in pairs(self.OnRemoveEntities) do
		if IsValid(e) then e:Remove() end
	end
	for _,e in pairs(self.Children) do
		if IsValid(e) then e:Remove() end
	end
end

net.Receive("hvap.aircraft.updateCamera", function(length)
	local aircraft = net.ReadEntity()
	local k = net.ReadInt( 5 )
	local v = net.ReadTable()
	if !IsValid(aircraft) then return end
	aircraft.CamData[k] = v
end)	
