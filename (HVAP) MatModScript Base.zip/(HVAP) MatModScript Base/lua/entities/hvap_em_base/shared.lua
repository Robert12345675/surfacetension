
if !hvap or !hvap.aircraft then
	error("hvap scripts not loaded.")
end

if wac then
	MsgC( Color( 255, 0, 0 ), "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )
	PrintMessage( HUD_PRINTCENTER, "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )
	PrintMessage( HUD_PRINTTALK, "WAC and HVAP are both installed and are incompatable, remove WAC to regain HVAP functionality." )	
return end

ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.PrintName = "Base Emplacement"
ENT.Author = hvap.author
ENT.Category = hvap.aircraft.spawnCategory
ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.RotSPD = 0.0256

ENT.FuselageHealth = 1000

ENT.Weight = 1000

ENT.RotSPD = 0.05

ENT.SeatSwitcherPos = Vector(0,0,50)

ENT.BullsEyePos	= Vector(20,0,50)

ENT.MaxEnterDistance = 50

ENT.Weapons = {}
ENT.Weapons2 = {}
ENT.CounterMeasures = {}

ENT.Doors = {}

ENT.PlyDmgMult = 1 -- player damage multiplier
ENT.PlyDmgDist=50 -- max distance to damage player

ENT.Function = 0
ENT.Function2 = 0

ENT.Scale = 1

ENT.Seats = {
	{
		pos = Vector(68, 0, 48),
		exit = Vector(72,70,0),
	},
}

ENT.IsHVAP = true
ENT.IsHVAPAircraft = false
ENT.IsHVAPPlane = false
ENT.IsHVAPGround = true
ENT.AllowAmmo = true
ENT.AllowFuel = false
ENT.AllowRepair = true
ENT.Submersible = false
ENT.CrRotorWash = false

ENT.DisableCamEffects = true

ENT.thirdPerson = {
	distance = 600,
	angle = 10,
	position = Vector(-50,0,100)
}

--[[
ENT.Turrets = {
	["Main"] = {
		Turret = {
			Gun = {
				model = "",
				pos = Vector(),
				offset = Vector(),
				angle = Angle()
			},
			Barrel = {
				model = "",
				pos = Vector(),
				offset = Vector(),
				angle = Angle()
			},
			Pitch = {
				model = "",
				pos = Vector(),
				offset = Vector(),
				angle = Angle()
			},
			Yaw = {
				model = "",
				pos = Vector(),
				offset = Vector(),
				angle = Angle()
			},
		},
		Camera = {
			View = {
				model = "",
				pos = Vector(),
				offset = Vector(),
				angle = Angle()
			},
			Pitch = {
				model = "",
				pos = Vector(),
				offset = Vector(),
				angle = Angle()
			},
			Yaw = {
				model = "",
				pos = Vector(),
				offset = Vector(),
				angle = Angle()
			},
		},
		ViewPos = Vector(),
		MinAng = Angle(),
		MaxAng = Angle(),
		Seat = 2
	}
}
]]

ENT.HatingNPCs={
	"CombineElite",
	"npc_combinegunship",
	"npc_combine_s",
	"npc_helicopter",
	"npc_manhack",
	"npc_metropolice",
	"CombinePrison",
	"PrisonShotgunner",
	"npc_rollermine",
	"npc_clawscanner",
	"ShotgunSoldier",
	
	"npc_stalker",
	"npc_strider",
	"npc_turret_floor",
	"npc_combine_camera",
	"npc_turret_ceiling",
	"npc_hunter",
	"npc_antlion",
	"PrisonShotgunner",
	"npc_antlion_grub",
	"npc_antlionguard",
	"npc_antlionguardian",
	"npc_antlion_worker",
	"npc_barnacle",
	"npc_headcrab_fast",
	"npc_fastzombie",
	"npc_fastzombie_torso",
	"npc_headcrab",
	"npc_headcrab_black",
	"npc_poisonzombie",
	"npc_zombie",
	"npc_zombie_torso",
	"npc_zombine",
	"npc_cscanner",
	"npc_combinedropship",
}

ENT.Sounds = {

	MissileAlert = "HVAP.Alarm.Missile",
	Alarm25 = "HVAP.Alarm.25",
	Alarm50 = "HVAP.Alarm.50",
	Alarm75 = "HVAP.Alarm.75",
	Burning = "HVAP.Vehicle.Burn",
	Damaged = "HVAP.Alarm.Damaged",

}

function ENT:addSounds()
	self.sounds = {}
	for k, v in pairs(self.Sounds) do
		if k != "BaseClass" then
			self.sounds[k] = CreateSound(self, v)
		end
	end
end

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "Switcher")
end

function ENT:base(name)
	local current = self
	while current do
		if current.ClassName == name then
			return current
		end
		current = current.BaseClass
	end
	error("No base class with name \"" .. name .. "\"", 2)
end

function ENT:updateSkin(n)
	if SERVER then
		for _, e in pairs(self.Children) do
			if IsValid(e) then
				e:SetSkin(n)
			end
		end
	end
end

function ENT:getPassenger(seat)
	if !IsValid(self:GetSwitcher()) then return end
	local s = self:GetSwitcher().seats[seat]
	if IsValid(s) then
		return s:GetDriver()
	end
end

function ENT:GetViewTarget(k)
	if !IsValid(self.seats[k]) or !self.CamData[k] or !IsValid(self:getPassenger(k)) then return end
	
	local minAng = self.Turrets[self.Seats[k].Turret].info.minAng
	local maxAng = self.Turrets[self.Seats[k].Turret].info.maxAng
	local ang = self:WorldToLocalAngles(self.CamData[k].angles)
	local pos = self.CamData[k].origin
--	print(ang)
--[[	
	if minAng then
		ang.p = (ang.p > minAng.p and ang.p or minAng.p)
		ang.y = (ang.y > minAng.y and ang.y or minAng.y)
	end
	if maxAng then
		ang.p = (ang.p < maxAng.p and ang.p or maxAng.p)
		ang.y = (ang.y < maxAng.y and ang.y or maxAng.y)
	end	
]]
	local tr = util.QuickTrace(pos, self:LocalToWorldAngles(ang):Forward()*999999999, self.Children)
	
	return tr

end

