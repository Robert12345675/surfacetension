AddCSLuaFile()

ENT.Base = "hvap_pod_gun_base"
ENT.Type = "point"

ENT.PrintName = "M61"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "M61"
ENT.Ammo = 1000
ENT.FireRate = 6000
ENT.Force = 9999999999

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.CoolDown = 5//ammount taken from heat every sec
ENT.HeatMult = 9//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 2//time it takes for unoverheat
ENT.Caliber = 20
ENT.Spread = 0.64
ENT.SndPitch = 100

ENT.Punch = 15

ENT.AmmoBelt = {
	{
		"heit",
		"saphei",
		"heit",

		"heit",		
		"api",
		"heit",
	},
	{
		"hei",
		"saphei",
		"hei",

		"hei",		
		"saphei",
		"hei",
		
		"api",
		"saphei",
		"api",
		
		"heit",		
	},
}

ENT.AmmoData = {
	["api"] = {
		class = "hvap_bullet_api",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=1030,--velocity m/s
			Radius=30,--caliber
			Penetrate= 6.3,--caliber
			BallisticDrag = 20,
			Drift=0.64,
			Mass=102,--g
			TissueDamage = math.Rand(80,90),
			EffectSize = 9,
			Size=20--caliber
		}
	},	
	["hei"] = {
		class = "hvap_bullet_he",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=1030,--velocity m/s
			Radius=200,--caliber
			Penetrate= 10,--caliber
			BallisticDrag = 20,
			Drift=1.5,
			Mass=102,--g
			TissueDamage = math.Rand(105,128),
			EffectSize = 14,
			Size=20--caliber
		}
	},
	["heit"] = {
		class = "hvap_bullet_he",
		info = {
			Large=false,
			SelfDestr=true,
			Flak=false,
			Tracer=true,--tracer?
			Timer=0.768,-- time to remove bullet or to explode if SelfDestr
			col=Color(200, 200, 120),
			Speed=1030,--velocity m/s
			Radius=200,--caliber
			Penetrate= 8,--caliber
			BallisticDrag = 20,
			Drift=1.1,
			Mass=102,--g
			TissueDamage = math.Rand(100,112),
			EffectSize = 14,
			Size=20--caliber
		}
	},
	["saphei"] = {
		class = "hvap_bullet_api",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=1050,--velocity m/s
			Radius=30,--caliber
			Penetrate= 38,--caliber
			BallisticDrag = 20,
			Drift=0.32,
			Mass=102,--g
			TissueDamage = math.Rand(80,100),
			EffectSize = 11,
			Size=20--caliber
		}
	},
}


ENT.Sounds = {
	shoot = "HVAP.Gun.M61.Loop", -- sound played when firing
	stop = "HVAP.Gun.M61.End", -- sound played when stop firing
	blank = "", -- sound played when stop firing but hammed 
	clickstop = "", -- sound plaed when near overheat
	clickshoot = "", -- sound plaed when near overheat stop
	Jam = "", -- sound to play when gun jams
	GunReady = "HVAP.Gun.Jam.Ready"
}
