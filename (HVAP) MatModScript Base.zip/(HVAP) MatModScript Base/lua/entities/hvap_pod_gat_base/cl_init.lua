
include ("shared.lua")

function ENT:Initialize()
	self.smoothHeat = 0
	self.LastThink = CurTime()
	self:addSounds()
	self.ReadyPlay = self.ReadyPlay or 192	
end

function ENT:Think()

	local e = LocalPlayer():GetViewEntity()
	if !IsValid(e) then e = LocalPlayer() end
	
	local overheated = self:GetNWBool("overheated")
	local shooting = self:GetNWBool("shooting")
	
	local heatscl = self:GetSecondary()/1000
	local crt = CurTime()
	local pos = e:GetPos()
	local spos = self:GetPos()
	local doppler = (pos:Distance(spos+e:GetVelocity())-pos:Distance(spos+self:GetVelocity()))/128
	local vehicle = LocalPlayer():GetVehicle()
	local inVehicle = false
	if IsValid(vehicle) then
		if !vehicle:GetThirdPersonMode() then
			inVehicle = true
		end
		doppler = 0
	end

	local mod = (doppler+self:GetVelocity():Length()/80)
	
	if overheated then
		if shooting then
			if !self.sounds.blankshoot:IsPlaying() then
				self.sounds.blankshoot:Play()
			end		
			if self.sounds.start:IsPlaying() then
				self.sounds.start:Stop()
			end
			if self.sounds.loop:IsPlaying() then
				self.sounds.loop:Stop()
				self.sounds.stop:PlayEx((inVehicle and 0.5 or 1), self.SndPitch)		
			end	
		else
			if self:GetSecondary() < self.ReadyPlay and !self.sounds.GunReady:IsPlaying() then
				self.sounds.GunReady:Play()	
			end			
		end
		if !self.sounds.Jam:IsPlaying() then
			self.sounds.Jam:Play()	
		end	
	else
		if shooting then
			if self.sounds.stop:IsPlaying() then
				self.sounds.stop:Stop()
			end
			if !self.sounds.start:IsPlaying() then
				self.sounds.start:PlayEx((inVehicle and 0.5 or 1),math.Clamp(self.SndPitch-2+(10*heatscl^3)+mod,0,255))
			end
			if self.sounds.loop:IsPlaying() then
				self.sounds.loop:ChangeVolume((inVehicle and 0.5 or 1), 0.1)
			else
				self.sounds.loop:PlayEx((inVehicle and 0.5 or 1),math.Clamp(self.SndPitch-2+(10*heatscl^3)+mod,0,255))
			end
			if self.sounds.GunReady:IsPlaying() then
				self.sounds.GunReady:Stop()	
			end
		end
		
		if self.sounds.Jam:IsPlaying() then
			self.sounds.Jam:Stop()	
		end	
		if self:GetSecondary() > 600 then
			if !self.sounds.clickshoot:IsPlaying() then
				self.sounds.clickshoot:Play()
			end
		end		
	end

	if !shooting then
		if self.sounds.blankshoot:IsPlaying() then
			self.sounds.blankshoot:Stop()
		end		
		if self.sounds.start:IsPlaying() then
			self.sounds.start:Stop()
		end
		if self.sounds.loop:IsPlaying() then
			self.sounds.loop:Stop()
			self.sounds.stop:PlayEx((inVehicle and 0.5 or 1), self.SndPitch)		
		end		
	end
	
	if self:GetSecondary() <= 600 then
		if self.sounds.clickshoot:IsPlaying() then
			self.sounds.clickshoot:Stop()
		end
	end
	
	self:NextThink(crt)
	return true
end

function ENT:drawCrosshair()
	surface.SetDrawColor(255,255,255,150)
	local center = {x=ScrW()/2, y=ScrH()/2}
	surface.DrawLine(center.x+10, center.y, center.x+30, center.y)
	surface.DrawLine(center.x-30, center.y, center.x-10, center.y)
	surface.DrawLine(center.x, center.y+10, center.x, center.y+30)
	surface.DrawLine(center.x, center.y-30, center.x, center.y-10)
	surface.DrawOutlinedRect(center.x-10, center.y-10, 20, 20)
	surface.DrawOutlinedRect(center.x-11, center.y-11, 22, 22)
end

function ENT:OnRemove()
	for _, s in pairs(self.sounds) do
		s:Stop()
	end
end
