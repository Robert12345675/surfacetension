
AddCSLuaFile()

ENT.Type 			= "anim"  
ENT.Base 			= "base_anim"     
ENT.PrintName			= "Bullet"  
ENT.Author			= "The_HAVOK"  
ENT.Contact			= "The_HAVOK"  
ENT.Purpose			= ""  
ENT.Instructions		= ""  
 
ENT.Spawnable			= false

ENT.HVAP_ENTITY = true
ENT.valid = false

if CLIENT then

function ENT:Draw()

end

elseif SERVER then

function ENT:Initialize()  
	self:SetRenderMode( RENDERMODE_NONE )
	self:DrawShadow(false)
	self:SetNoDraw(true) 
	math.randomseed(CurTime())
	self.Flightvector 	= self:GetForward()*(self.Speed*52.459*FrameTime())+self.airvel/self.Speed
	self.Timeleft 		= CurTime() + self.Timer
	self.Wait = CurTime() + 0.32	
	self.Impacted 		= false
	self:SetColor(col)
	self:SetModel( "models/led.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_NONE )
	self:GetPhysicsObject():SetMass(self.Mass)
	self.Ricochet=0
	self.Penetrated=0
	
	self.IsTracer = false
	if hvap.aircraft.cvars.tracers:GetFloat() == 1 then
		if self.Tracer then
			local colmod=math.random(-24,24)
			local col2=Color(math.Clamp((self.col.r)+math.random(-8,8)-colmod, 0, 255),math.Clamp((self.col.g)+math.random(-8,8)-colmod, 0, 255),math.Clamp((self.col.b)+math.random(-8,8)-colmod, 0, 255),255)
			local startWidth = math.Clamp(self.Size/2, 1, 100)
			local length = math.Clamp(1/self.Size, 0.064, 0.1)/2 + 0.06
			local scl = 1/startWidth*0.5
			self.trail=util.SpriteTrail(self, 0, col2, true, startWidth, 0, length, scl, "trails/hvap_tracer.vmt")
			Shine = ents.Create("env_sprite")
			Shine:SetPos(self.Entity:GetPos())
			Shine:SetKeyValue("renderfx", "0")
			Shine:SetKeyValue("rendermode", "5")
			Shine:SetKeyValue("renderamt", "255")
			Shine:SetKeyValue("rendercolor", tostring(col2) )
			Shine:SetKeyValue("framerate12", "20")
			Shine:SetKeyValue("model", "light_glow03.spr")
			Shine:SetKeyValue("scale", tostring(self.Size/100))
			Shine:SetKeyValue("GlowProxySize", "16")
			Shine:SetParent(self.Entity)
			Shine:Spawn()
			Shine:Activate()
			self.IsTracer = true
		end
	end
	self.valid = true
end

function ENT:Think()
	if !self:IsValid() or !self.valid then return end
	
	local crt = CurTime()

	if self.SelfDestr then
		if crt > self.Timeleft+math.Rand(-0.32,0.32) then
			self:Airburst()
		end
	elseif crt > self.Timeleft then
		self:Remove()		
	end

	if self.Flak and crt > self.Wait then
		ent = ents.FindInSphere(self:GetPos(), self.Radius/2)
		for k, v in pairs(ent) do 
			if v.IsHVAP and !table.HasValue( self.EntFilter, v ) and v != self.AircraftFiring then 
				print(v)
				self:Airburst()
			end
		end
	end	
	
	local tr = util.TraceLine({
		start 	= self:GetPos(),
		endpos 	= self:GetPos() + self.Flightvector,
		filter 	= self.EntFilter,
		mask 	= CONTENTS_WATER+MASK_SHOT+CONTENTS_EMPTY
	})
	
	if tr.Hit and !table.HasValue( self.EntFilter, tr.Entity ) then
		self.Mat = math.ceil(tr.MatType)	
		
		if tr.HitSky then
			self:Remove()
			return true
		end
		
		if self.Mat==83 and !self.Entity:WaterLevel() > 0 then
			local effectdata = EffectData()
			effectdata:SetOrigin( tr.HitPos )
			effectdata:SetNormal( tr.HitNormal )
			effectdata:SetScale( self.Size^2 )
			util.Effect( "watersplash", effectdata )
		end

		self:Impact(tr)
		
	else
		self.Flightvector = self.Flightvector - ((self.Flightvector/self.BallisticDrag) + (VectorRand():GetNormalized()*self.Drift))*.512 + Vector(0,0,-30)/self.Flightvector:Length()
		
		if !self.Impacted then
			self:SetPos(self:GetPos() + self.Flightvector)
			self:SetAngles(self.Flightvector:Angle() + Angle(90,0,0))	
		else
			self.Impacted = false
		end
	end
	
	self:NextThink( crt )
	return true
end

function ENT:Impact(tr)
	local effectdata = EffectData()
		effectdata:SetEntity(tr.Entity)
		effectdata:SetMagnitude(self.EffectSize)
		effectdata:SetNormal(tr.HitNormal)
		effectdata:SetOrigin(tr.HitPos)
		effectdata:SetScale(self.Size)
		effectdata:SetStart(self.Flightvector:GetNormalized())
		effectdata:SetSurfaceProp(tr.MatType or 1)
	util.Effect("hvap_bullet_impact_he", effectdata )
	
	self:ApplyDamage(tr, 1)
	self:Remove()
end

function ENT:Airburst()
	local effectdata = EffectData()
		effectdata:SetMagnitude(self.EffectSize)
		effectdata:SetNormal(-self.Flightvector:GetNormalized())
		effectdata:SetOrigin(self:GetPos())
		effectdata:SetScale(self.Size)
		effectdata:SetRadius(1)
	util.Effect("hvap_bullet_airburst", effectdata )

	self:ApplyDamage(tr, 1, true)
	self:Remove()
end

function ENT:ApplyDamage(trd, div, b)
	if trd and IsValid(trd.Entity) and !b then
		local dmginfo = DamageInfo()
		if (trd.Entity:IsPlayer() or trd.Entity:IsNPC()) then
			util.Decal("blood", trd.HitPos + trd.HitNormal, trd.HitPos - trd.HitNormal)
			if trd.Entity:IsNPC() then
				trd.Entity:SetEnemy( self.AircraftFiring )
				trd.Entity:SetTarget( self.Owner )
			end
		end
		dmginfo:ScaleDamage( div ) 
		dmginfo:SetAttacker( self.Owner )
		dmginfo:SetDamage( self.TissueDamage ) 
		dmginfo:SetDamageForce( self.Flightvector:GetNormalized()*self.Size*8 )
		dmginfo:SetDamagePosition(trd.HitPos)
		dmginfo:SetDamageType( DMG_BLAST )
		dmginfo:SetInflictor( self.AircraftFiring or self.Owner )
		dmginfo:SetReportedPosition( trd.HitPos )
		trd.Entity:TakeDamageInfo( dmginfo )
	end
	util.BlastDamage( self.AircraftFiring, self.Owner, self:GetPos() + self:GetForward()*64, self.Size+self.Radius+63, self.TissueDamage )
	util.ScreenShake( IsValid(trd) and trd.HitPos or self:GetPos(), self.Size*2, self.Size, 1, self.Size*4+self.Radius+128 )
end

end

function ENT:UpdateTransmitState() return TRANSMIT_PVS end -- TRANSMIT_ALWAYS
