AddCSLuaFile()

ENT.Base = "hvap_pod_gun_base"
ENT.Type = "point"

ENT.PrintName = "BK.75"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "BK.75"
ENT.Ammo = 24
ENT.FireRate = 30
ENT.Force = 9999999999

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.CoolDown = 80//ammount taken from heat every sec
ENT.HeatMult = 250//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 8//time it takes for unoverheat
ENT.Caliber = 75
ENT.Spread = 0.512
ENT.SndPitch = 100
ENT.SingleFire = true

ENT.Punch = 150

ENT.AmmoBelt = {--A165 Belt
	{
		"ap",
	},
	{
		"he",
	},
	{
		"apcr",
	},
}

ENT.AmmoData = {
	["ap"] = {
		class = "hvap_bullet_api",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=true,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 255, 255),
			Speed=740,--velocity m/s
			Radius=128,--caliber
			Penetrate= 40,--caliber
			BallisticDrag	= 16,
			Drift=2,
			Mass=200,--g
			TissueDamage = math.Rand(700,800),--
			EffectSize = 32,
			Size=75--caliber
		}
	},
	["he"] = {
		class = "hvap_bullet_he",
		info = {
			Large=false,
			SelfDestr=true,
			Flak=true,
			Tracer=false,--tracer?
			Timer=0.9,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 110, 110),
			Speed=570,--velocity m/s
			Radius=512,--caliber
			Penetrate= 1,--caliber
			BallisticDrag	= 16,
			Drift=2,
			Mass=200,--g
			TissueDamage = math.Rand(400,512),--
			EffectSize = 32,
			Size=75--caliber
		}
	},
	["apcr"] = {
		class = "hvap_bullet_ap",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=true,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(255, 44, 44),
			Speed=919,--velocity m/s
			Radius=100,--caliber
			Penetrate= 55,--caliber
			BallisticDrag	= 16,
			Drift=2,
			Mass=200,--g
			TissueDamage = math.Rand(800,700),--
			EffectSize = 32,
			Size=75--caliber
		}
	},
}

ENT.Sounds = {
	fire = "HVAP.Gun.BK75.Fire", -- sound played when firing
	blank = "HVAP.Gun.Misc.BlankFire", -- sound played when stop firing but hammed 
	clickstop = "HVAP.Gun.Jam.Click.End", -- sound plaed when near overheat
	clickshoot = "HVAP.Gun.Jam.Click.Loop", -- sound plaed when near overheat stop
	Jam = "HVAP.Gun.Jam.Start", -- sound to play when gun jams
	GunReady = "HVAP.Gun.Jam.Finish"
}