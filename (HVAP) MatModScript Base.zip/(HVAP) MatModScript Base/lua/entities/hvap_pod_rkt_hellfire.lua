
AddCSLuaFile()

ENT.Base = "hvap_pod_rkt2_base"
ENT.Type = "point"

ENT.PrintName = "Hellfire"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategory
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""
ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Ammo = 16
ENT.FireRate = 100
ENT.ReloadAmt = 1
ENT.Caliber = 152
ENT.CoolDown = 0//ammount taken from heat every sec
ENT.HeatMult = 500//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 4.95//time it takes for unoverheat

ENT.Belt = 1

ENT.Sounds = {
	fire = "HVAP.Rocket.ATGM",
	reload = "HVAP.Reload.Modern"
}

ENT.AmmoBelt = {
	{
		"he",
	},
	{
		"he2",
	},
}

ENT.AmmoData = {
	["he"] = {
		class = "hvap_bullet_rocket2",
		info = {
			mdl = "models/missiles/agm_114.mdl",
			col=Color(220,170,170),
			Speed=50,--velocity m/s
			Radius=math.Rand(819.2,1024),
			BallisticDrag	= 20,
			Drift=2,
			Mass=102,--g
			Damage	= math.Rand(1600,2560),
			EffectSize = 16,
			Size=152
		}
	},
	["he2"] = {
		class = "hvap_bullet_rocket2",
		info = {
			mdl = "models/missiles/agm_114.mdl",
			col=Color(220,170,170),
			Speed=200,--velocity m/s
			Radius=math.Rand(819.2,1024),
			BallisticDrag	= 20,
			Drift=2,
			Mass=102,--g
			Damage	= math.Rand(1600,2560),
			EffectSize = 16,
			Size=152
		}
	}
}
