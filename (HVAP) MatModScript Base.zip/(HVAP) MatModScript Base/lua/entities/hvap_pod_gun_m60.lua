AddCSLuaFile()

ENT.Base = "hvap_pod_gun_base"
ENT.Type = "point"

ENT.PrintName = "M60"
ENT.Author = "The_HAVOK"
ENT.Category = hvap.aircraft.spawnCategoryC
ENT.Contact = ""
ENT.Purpose = ""
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.Name = "M60"
ENT.Ammo = 750
ENT.FireRate = 650
ENT.Force = 9999999999

ENT.Belt = 1
ENT.IsAimed = false// false=(gun), true=(aimedgun)

ENT.CoolDown = 10//ammount taken from heat every sec
ENT.HeatMult = 20//ammount added per bullet fired  1000 threshold
ENT.HeatTime = 4//time it takes for unoverheat
ENT.Caliber = 7.62
ENT.Spread = 0.128
ENT.SndPitch = 90
ENT.ReadyPlay = 92
ENT.DisableOverShoot = true

ENT.AmmoBelt = {
	{
		"ball",
		"ball",
		"ball",
		"ball",
		"ball",
		"apt",
	},
	{
		"ball",
		"ball",
		"ball",
		"ball",
		"ball",
		"ball",
		"ball",
		"ball",
		"ball",
		"ball",
		"apt",
		"apt",
	}	
}

ENT.AmmoData = {
	["apt"] = {
		class = "hvap_bullet_ap",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=true,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 255, 0),
			Speed=850,--velocity m/s
			Radius=7.62,--caliber
			Penetrate= 7,--caliber
			BallisticDrag	= 16,
			Drift=0.512,
			Mass=9.5,--g
			TissueDamage = math.Rand(20,39),
			EffectSize=5,
			Size=7.62--caliber	
		}
	},
	["ball"] = {
		class = "hvap_bullet_ap",
		info = {
			Large=false,
			SelfDestr=false,
			Flak=false,
			Tracer=false,--tracer?
			Timer=1.92,-- time to remove bullet or to explode if SelfDestr
			col=Color(0, 0, 0),
			Speed=853,--velocity m/s
			Radius=7.62,--caliber
			Penetrate= 7.62,--caliber
			BallisticDrag = 32,
			Drift=0.768,
			Mass=9.5,--g
			TissueDamage = math.Rand(20,39),
			EffectSize=5,
			Size=7.62--caliber	
		}
	},	
}

ENT.Sounds = {
	shoot = "HVAP.Gun.M60.Loop", -- sound played when firing
	stop = "HVAP.Gun.M60.End", -- sound played when stop firing
	blank = "HVAP.Gun.Misc.BlankFire", -- sound played when stop firing but hammed 
	Jam = "HVAP.Gun.Misc.NoSecondary", -- sound to play when gun jams
	GunReady = "HVAP.Reload.Small"
}
