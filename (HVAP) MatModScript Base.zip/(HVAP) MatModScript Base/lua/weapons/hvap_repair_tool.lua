
if SERVER then

	AddCSLuaFile( "hvap_repair_tool.lua" )	
	SWEP.Weight				= 1
	SWEP.AutoSwitchTo		= false
	SWEP.AutoSwitchFrom		= false

end

if CLIENT then

	SWEP.DrawAmmo			= false
	SWEP.DrawCrosshair		= true
	SWEP.ViewModelFOV		= 70
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= false

	SWEP.PrintName			= "Repair Tool"			
	SWEP.Author				= "HAVOK"
	SWEP.Category			= "(HVAP)Tools"
	SWEP.Slot				= 1
	SWEP.SlotPos			= 1
	
end

SWEP.Author				= "HAVOK"
SWEP.Contact		= "The_HAVOK"
SWEP.Purpose		= "Repair stuff"
SWEP.Instructions	= ""
SWEP.HoldType = "melee"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true

SWEP.Primary.Recoil			= 1
SWEP.Primary.Delay			= 0.64

SWEP.Primary.ClipSize		= 1
SWEP.Primary.DefaultClip	= 1
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.ViewModel			= "models/weapons/v_crowbar.mdl"
SWEP.WorldModel			= "models/weapons/w_crowbar.mdl"

SWEP.Weight				= 1
SWEP.AutoSwitchTo		= true
SWEP.AutoSwitchFrom		= false

SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "none"

function SWEP:Initialize()
	self:SetWeaponHoldType( self.HoldType )
end

function SWEP:Reload()

	self.Weapon:DefaultReload( ACT_VM_RELOAD );
	
end

function SWEP:Think()
	if CLIENT then return end
end

function SWEP:PrimaryAttack()
	if CLIENT then return end
	
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
	
	if !self:CanPrimaryAttack() then return end
	
	local tr,trace = {},{}
	tr.start = self.Owner:GetShootPos()
	tr.endpos = tr.start + self.Owner:GetAimVector() * 100
	tr.filter = { self, self.Owner }
	trace = util.TraceLine( tr )
	
	
	if( trace.Hit and IsValid( trace.Entity ) and trace.Entity.IsHVAP ) then
	self.Owner:EmitSound( "weapons/crowbar/crowbar_impact"..math.random(1,2)..".wav" )
	self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
		
		local fx = EffectData()
		fx:SetOrigin( trace.HitPos )
		fx:SetStart( trace.HitPos )
		fx:SetScale( 0.4 )
		fx:SetNormal( trace.HitNormal )
		util.Effect( "inflator_magic", fx )		
		
	else
		self.Weapon:EmitSound("weapons/iceaxe/iceaxe_swing1.wav")
		self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
	end
	self.Owner:SetAnimation(PLAYER_ATTACK1)
		if trace.Entity:IsNPC() or trace.Entity:IsPlayer() then
			bullet = {}
			bullet.Num    = 1
			bullet.Src    = self.Owner:GetShootPos()
			bullet.Dir    = self.Owner:GetAimVector()
			bullet.Spread = Vector(0, 0, 0)
			bullet.Tracer = 0
			bullet.Force  = 5
			bullet.Damage = math.random(20,55)
			self.Owner:FireBullets(bullet)
		end
	
	if SERVER then

		if( trace.Hit and IsValid( trace.Entity ) and trace.Entity.IsHVAP and trace.Entity.AllowRepair ) then
			trace.Entity:Repair(math.random(2,4),true, true)
		end
		
	end

end

function SWEP:SecondaryAttack()

end

function SWEP:Holster( wep )	
	return true 
end

function SWEP:OnRestore()
	self.NextSecondaryAttack = 0
end
